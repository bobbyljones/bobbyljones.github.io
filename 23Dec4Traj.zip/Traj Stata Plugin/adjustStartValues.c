/* 
	Check and adjust start values	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"

void adjustStartValues(int *ns, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		i, j, k, os, os2, outcSigmaOs;
	double	temp;
	char	buf[80];

	os = 0;
	if (ts->modelType[0] == m_cnorm) 
	{
		os2 = ts->ar1 ? 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[0] - 1) :
					    1 + ts->sigmaByGroup * (ts->nOrders[0] - 1 - ts->all0Group[0]);			
		os = (ts->rorderStmt[0]) ? ts->rorderOffset : ts->riskOffset[0];
		os -= os2;
		if (ts->sigmaByGroup) 
		{
			for (i = 0; i < ts->nOrders[0] - ts->all0Group[0]; i++) 
			{
				ts->initVal[os] = ts->initVal[os] > DBL_MIN ? log(ts->initVal[os]) : 0.;
				os++;
			}
		} 
		else 
		{
			ts->initVal[os] = ts->initVal[os] > DBL_MIN ? log(ts->initVal[os]) : 0.;
			os++;
		}
		if (ts->ar1)
		{
			if (ts->rhoByGroup)
			{
				for (i = 0; i < ts->nOrders[0]; i++)
				{
					ts->initVal[os] = ts->initVal[os] > DBL_MIN ? logit(ts->initVal[os]) : 0.;
					os++;
				}
			} 
			else 
				ts->initVal[os] = ts->initVal[os] > DBL_MIN ? logit(ts->initVal[os]) : 0.;
		}
	}
	if (ts->modelType[0] == m_zibeta) 
	{
		os = ts->riskOffset[0] - ts->nOrders[0];
		for (i = 0; i < ts->nOrders[0]; i++) 
		{
			ts->initVal[os] = ts->initVal[os] > DBL_MIN ? log(ts->initVal[os]) : 0.;
			os++;
		}
	}
	if (ts->rorderStmt[0]) 
	{
		os = ts->rorderOffset;
		for (i = 0; i < ts->rorder[0][0] + 1; i++) 
			ts->initVal[os + i] = ts->initVal[os + i] > DBL_MIN ? log(ts->initVal[os + i]) : 0.;
		os += (int)ts->rorder[0][0] + 1;
		for (j = 1; j < ts->nOrders[0]; j++) 
		{
			for (i = 0; i < ts->rorder[0][j] + 1; i++)
				ts->initVal[os + i] = ts->initVal[os + i] > DBL_MIN ? log(ts->initVal[os + i]) : 0.;
			os += (int)ts->rorder[0][j] + 1;
		}
	}
	if (ts->nOrders[0] > 1 && ts->nRisk[0] == 0) 
	{
		os = ts->riskOffset[0] + 1;
		for (i = 0; i < ts->nOrders[0]; i++) 
		{
			if (ts->initVal[os - 1 + i] <= 0. || ts->initVal[os - 1 + i] >= 100.)
				WRITELOG("Starting pct = %12.6f is not 0-100.\n", ts->initVal[os - 1 + i]);
			ts->group_percent[i] = ts->initVal[os - 1 + i];
		}
		temp = 1. - ts->initVal[os] / 100.;
		for (i = 0; i < ts->nOrders[0] - 2; i++) 
		{
			os++;
			temp -= ts->initVal[os] / 100.;
		}
		os = ts->riskOffset[0];
		ts->initVal[os] = log(ts->initVal[os + 1] / temp / 100.); 
		for (i = 0; i < ts->nOrders[0] - 2; i++) 
		{
			os++;
			ts->initVal[os] = log(ts->initVal[os + 1] / temp / 100.);
		}	
		for (i = os + 1; i < *ns - 1; i++) 
			ts->initVal[i] = ts->initVal[i + 1];
		os++;
	}
	if (ts->outcModelType[0] == m_cnorm) 
	{
		outcSigmaOs = ts->nOrders[0] + ts->nOcov[0];
		ts->initVal[os + outcSigmaOs] = 
			ts->initVal[os + outcSigmaOs] > DBL_MIN ? log(ts->initVal[os + outcSigmaOs]) : 0.;
	}
	if (ts->nOrders[1] > 1 && ts->nRisk[1] == 0) 
	{
		os = os2 = ts->riskOffset[1];
		for (k = 0; k < ts->nOrders[0]; k++) 
		{
			for (i = 0; i < ts->nOrders[1]; i++) 
			{
				if (ts->initVal[os + i] < 0. || ts->initVal[os + i] >= 100.)
					WRITELOG("Starting pct = %12.6f is not 0-100.\n", ts->initVal[os + i]);
			}
			temp = 1. - ts->initVal[os + 1] / 100;
			for (i = 0; i < ts->nOrders[1] - 2; i++) 
			{
				os++;
				temp -= ts->initVal[os + 1] / 100.;
			}
			os = os - ts->nOrders[1] + 2;
			if (ts->initVal[os + 1] == 0.)
				ts->initVal[os + 1] = DBL_EPSILON;
			ts->initVal[os2] = log(ts->initVal[os + 1] / temp / 100.);
			os++;	
			os2++;
			for (i = 0; i < ts->nOrders[1] - 2; i++) 
			{
				if (ts->initVal[os + 1] == 0.)
					ts->initVal[os + 1] = DBL_EPSILON;
				ts->initVal[os2] = log(ts->initVal[os + 1] / temp / 100.);
				os++;
				os2++;
			}
			os++;
		}
	}
	if (ts->modelType[1] == m_cnorm) 
	{
		os = ts->riskOffset[1] - 1;
		ts->initVal[os] = ts->initVal[os] > DBL_MIN ? log(ts->initVal[os]) : 0.;
		os++;
	}
}
