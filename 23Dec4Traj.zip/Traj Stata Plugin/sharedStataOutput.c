/* 
	Stata output processing for outcome and joint models

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.
*/

#include	 "ctraj.h"

int sharedStataOutput(int parmListPtr, void *qinfo)
{
	struct	TRAJSTRUCT *ts = qinfo;
	char	buf[100], hdr[100], l_str[33], parmLabel[13], w1_str[13], w2_str[13], w3_str[13];
	int		i, j, L, r;
	double	d1, temp, temp2, temp3;

	if (ts->outcStmt[0])
	{
		if (!ts->noprint)
		{
			WRITELOG("Outcome ");
//			WRITELOG("Outcome: %7s ", ts->outcModel[0]);
			if (ts->twoStep) {
				WRITELOG(" - two-step modeling\n\n");
			}
			else WRITELOG("\n\n");
		}
		if (ts->nOcov[0] > 0 && ts->outcModelType[0] != m_mlogit)
		{
			for (i = 0; i < ts->nOrders[0]; i++)
			{
				sprintf(parmLabel, "Group%-d     ", i + 1);
				writeParmLine(i + 1, ts->outc_iflt, ts->nData, ts->start[parmListPtr],
					ts->stdErr[parmListPtr], parmLabel);
				sprintf(l_str, "Group%-d", i + 1);
				strcat(ts->outestVarName, l_str);
				strcat(ts->outestVarName, " ");
				parmListPtr++;
			}
			for (r = 0; r < ts->nOcov[0]; r++)
			{
				writeParmLine(0, ts->outc_iflt, ts->nData, ts->start[parmListPtr],
					ts->stdErr[parmListPtr], ts->ocovNames[0][r]);
				sprintf(l_str, "%s", ts->ocovNames[0][r]);
				strcat(ts->outestVarName, l_str);
				strcat(ts->outestVarName, " ");
				parmListPtr++;
			}
		}
		if (ts->nOcov[0] > 0 && ts->outcModelType[0] == m_mlogit)
		{
			WRITELOG(" Level\n");
			for (L = 0; L < ts->nOutcLevels[0]; L++)
			{
				if ((int)ts->mlogitOutcLevel[0][L] == (int)ts->baseOutc[0])
				{
					sprintf(parmLabel, "%-d", (int)ts->baseOutc[0]);
					sprintf(hdr,
						" %-7s baseline level                       .               .            . \n",
						parmLabel);
					SF_display(hdr);
				}
				else
				{
					for (i = 0; i < ts->nOrders[0]; i++)
					{
						sprintf(parmLabel, "Group%-dL%-d  ", i + 1, (int)ts->mlogitOutcLevel[0][L]);
						writeParmLine((int)ts->mlogitOutcLevel[0][L], ts->outc_iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], parmLabel);
						sprintf(l_str, "Group%-dL%-d", i + 1, (int)ts->mlogitOutcLevel[0][L]);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
					for (j = 0; j < ts->nOcov[0]; j++)
					{
						writeParmLine((int)ts->mlogitOutcLevel[0][L], ts->outc_iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], ts->ocovNames[0][j]);
						sprintf(l_str, "O%sL%-d", ts->ocovNames[0][j], (int)ts->mlogitOutcLevel[0][L]);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
				}
				WRITELOG("\n");
			}
		}
		if (ts->nOcov[0] == 0 && ts->outcModelType[0] != m_mlogit)
		{
			for (i = 0; i < ts->nOrders[0]; i++)
			{
				if (!ts->noprint)
				{
					sprintf(parmLabel, "Group %-d     ", i + 1);
					switch (ts->outcModelType[0])
					{
					case m_cnorm:
					case m_zip:
						writeParmLine(0, ts->outc_iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], parmLabel);
						if (ts->outc_iflt == 0 && ts->iflt == 0)
							snprintf(hdr, 90, "95%% CI (Mean): (%12.3f, %12.3f, %12.3f)\n",
								ts->meanOutcL95[i], ts->meanOutc[i], ts->meanOutcU95[i]);
						break;
					case m_logit:
						writeParmLine(0, ts->outc_iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], parmLabel);
						if (ts->outc_iflt == 0 && ts->iflt == 0)
							snprintf(hdr, 90, "95%% CI (Mean): (%5.3f, %5.3f, %5.3f)\n",
								ts->meanOutcL95[i], ts->meanOutc[i], ts->meanOutcU95[i]);
						break;
					}
					SF_display(hdr);
					sprintf(l_str, "Group%-d", i + 1);
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					parmListPtr++;
					sprintf(hdr, " \n");
					SF_display(hdr);
				}
			}
		}
		if (ts->nOcov[0] == 0 && ts->outcModelType[0] == m_mlogit)
		{
			WRITELOG(" Group   Level\n");
			if (ts->outc_iflt == 0 && ts->iflt == 0)
			{
				//mlogitDeltaMethod(parmListPtr, ts->nOrders[0], ts);
				for (r = 0; r < ts->nOutcLevels[0]; r++)
				{
					for (i = 0; i < ts->nOrders[0]; i++)
					{
						d1 = 0.;
						for (j = 0; j < ts->nOutcLevels[0] - 1; j++)
						{
							ts->start[parmListPtr + j] = ts->start[parmListPtr + j] > MAXEXP ?
								MAXEXP : ts->start[parmListPtr + j];
							ts->start[parmListPtr + j] = ts->start[parmListPtr + j] < -MAXEXP ?
								-MAXEXP : ts->start[parmListPtr + j];
							d1 += exp(ts->start[parmListPtr + j]);
						}
						ts->meanMlogitOutcL95[i][r] = ts->meanMlogitOutc[i][r] - 1.96 *
							sqrt(fabs(ts->hpi[r * (int)ts->nOutcLevels[0] + r]));
						if (ts->meanMlogitOutcL95[i][r] < 0.) ts->meanMlogitOutcL95[i][r] = 0.;
						ts->meanMlogitOutcU95[i][r] = ts->meanMlogitOutc[i][r] + 1.96 *
							sqrt(fabs(ts->hpi[r * (int)ts->nOutcLevels[0] + r]));
						if (ts->meanMlogitOutcU95[i][r] > 1.) ts->meanMlogitOutcU95[i][r] = 1.;
						sprintf(parmLabel, "%-d", (int)ts->mlogitOutcLevel[0][r]);
						if ((int)ts->mlogitOutcLevel[0][r] == (int)ts->baseOutc[0])
						{
							sprintf(hdr,
								" %-d       %-d      baseline level              .               .            . \n",
								i + 1, (int)ts->baseOutc[0]);
							SF_display(hdr);
							if (ts->outc_iflt == 0 && ts->iflt == 0)
							{
								snprintf(hdr, 90, "     95%% CI: (%5.3f, %5.3f, %5.3f)\n",
									ts->meanMlogitOutcL95[i][r],
									ts->meanMlogitOutc[i][r], ts->meanMlogitOutcU95[i][r]);
							}
							SF_display(hdr);
						}
						else
						{
							writeParmLine(i + 1, ts->outc_iflt, ts->nData, ts->start[parmListPtr],
								ts->stdErr[parmListPtr], parmLabel);
							sprintf(l_str, " %-d     %-d", i + 1, (int)ts->mlogitOutcLevel[0][r]);
							sprintf(l_str, "Group%-dL%-d", i + 1,
								(int)ts->mlogitOutcLevel[0][r]);
							strcat(ts->outestVarName, l_str);
							strcat(ts->outestVarName, " ");
							if (ts->outc_iflt == 0 && ts->iflt == 0)
							{
								snprintf(hdr, 90, "     95%% CI: (%5.3f, %5.3f, %5.3f)\n",
									ts->meanMlogitOutcL95[i][r],
									ts->meanMlogitOutc[i][r], ts->meanMlogitOutcU95[i][r]);
							}
							SF_display(hdr);
							parmListPtr++;
						}
					}
					WRITELOG("\n");
				}
			}
		}
		if (ts->outcModelType[0] == m_cnorm)
		{
			writeParmLine(0, ts->outc_iflt, ts->nData, exp(ts->start[parmListPtr]),
				ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "oSigma      ");
			if (ts->outc_iflt == 0 && ts->iflt == 0)
			{
				for (i = 0; i < ts->totalParms; i++)
				{
					ts->hessian[i * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
					ts->hessian[parmListPtr * ts->totalParms + i] *= exp(ts->start[parmListPtr]);
				}
			}
			sprintf(l_str, "oSigma");
			strcat(ts->outestVarName, l_str);
			strcat(ts->outestVarName, " ");
			parmListPtr++;
		}
		if (ts->twoStep)
		{
			sprintf(buf, "Outcome Model        ");
			SF_display(buf);
			snprintf(buf, 35, "    BIC= %11.2f (N=%d)", ts->outcMdlfit[0], ts->bicnobs);
			SF_display(buf);
			snprintf(buf, 20, "  AIC= %11.2f", ts->outcMdlfit[1]);
			SF_display(buf);
			snprintf(buf, 20, "  ll= %11.2f\n", ts->outcMdlfit[2]);
			SF_display(buf);
		}
	}
	if (ts->likelihoodType == JOINT)
	{
		if (!ts->noprint)
		{
			sprintf(hdr, " \n");
			SF_display(hdr);
			switch (ts->modelType[1])
			{
			case m_cnorm:
				sprintf(hdr, "Model 2: Censored Normal (cnorm)\n");
				break;
			case m_logit:
				sprintf(hdr, "Model 2: Logistic (logit)\n");
				break;
			case m_zip:
				sprintf(hdr, "Model 2: Zero Inflated Poisson (zip)\n");
				break;
			}
			SF_display(hdr);
			sprintf(hdr, " \n");
			SF_display(hdr);
			for (i = 0; i < ts->nOrders[1]; i++)
			{
				for (j = 0; j <= ts->order[1][i]; j++)
				{
					switch (j)
					{
					case 0:
						writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Intercept   ");
						sprintf(l_str, "m2intr%-d", i + 1);
						break;
					case 1:
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Linear      ");
						sprintf(l_str, "m2linr%-d", i + 1);
						break;
					case 2:
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Quadratic   ");
						sprintf(l_str, "m2quad%-d", i + 1);
						break;
					case 3:
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Cubic       ");
						sprintf(l_str, "m2cubc%-d", i + 1);
						break;
					case 4:
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Quartic     ");
						sprintf(l_str, "m2quart%-d", i + 1);
						break;
					case 5:
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Quintic     ");
						sprintf(l_str, "m2quint%-d", i + 1);
						break;
					}
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					parmListPtr++;
				}
				sprintf(hdr, " \n");
				SF_display(hdr);
				for (j = 0; j < ((int)ts->order[1][i] + 1 > 0) * ts->nTcovParms[1]; j++)
				{
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
						ts->stdErr[parmListPtr], ts->tcovNames[1][j * ts->nIndep[1]]);
					sprintf(l_str, "%sG%-d", ts->tcovNames[1][j * ts->nIndep[1]], i + 1);
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					parmListPtr++;
				}
			}
			sprintf(hdr, " \n"); SF_display(hdr);
			if (ts->modelStmt[1] && ts->modelType[1] == m_cnorm)
			{
				if (ts->sigmaByGroup)
				{
					for (i = 0; i < ts->nOrders[1]; i++)
					{
						writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[parmListPtr]),
							ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "Sigma       ");
						for (r = 0; r < ts->totalParms; r++)
						{
							ts->hessian[r * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
							ts->hessian[parmListPtr * ts->totalParms + r] *= exp(ts->start[parmListPtr]);
						}
						sprintf(l_str, "m2sigma%-d", i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
				}
				else
				{
					writeParmLine(0, ts->iflt, ts->nData, exp(ts->start[parmListPtr]),
						ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "Sigma       ");
					for (i = 0; i < ts->totalParms; i++)
					{
						ts->hessian[i * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
						ts->hessian[parmListPtr * ts->totalParms + i] *= exp(ts->start[parmListPtr]);
					}
					sprintf(l_str, "m2sigma");
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					parmListPtr++;
				}
			}
			if (ts->modelStmt[1] && ts->dropoutStmt[1])
			{
				for (i = 0; i < ts->nDropout[1]; i++)
				{
					if (ts->nDropout[1] == 1)
					{
						writeParmLine(0, ts->iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], "Drop0       ");
						sprintf(l_str, "m2drop0");
						parmListPtr++;
					}
					else
					{
						if (ts->dOrd[1][i] != -1.)
						{
							writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[parmListPtr],
								ts->stdErr[parmListPtr], "Drop0       ");
							sprintf(l_str, "m2drop0G%-d", i + 1);
							parmListPtr++;
						}
					}
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					for (j = 1; j <= (int)ts->dOrd[1][i]; j++)
					{
						sprintf(parmLabel, "Drop%-d       ", j);
						writeParmLine(0, ts->iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], parmLabel);
						sprintf(l_str, "m2drop%-dG%-d", j, i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
					for (r = 0; r < ts->nDcovPrm[1]; r++)
					{
						writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], ts->dcovNames[1][r * ts->nIndep[1]]);
						sprintf(l_str, "%sG%-d", ts->dcovNames[1][r * ts->nIndep[1]], i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
					sprintf(hdr, " \n"); SF_display(hdr);
				}
			}
			if (ts->iorderStmt[1])
			{
				for (i = 0; i < MAX(1, ts->nIorder[1]); i++)
				{
					if (ts->commonIorder[1])
					{
						writeParmLine(0, ts->iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], "Alpha0      ");
						sprintf(l_str, "m2alpha0");
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
					else
					{
						if (ts->iorder[1][i] != -1.)
						{
							writeParmLine(i + 1, ts->iflt, ts->nData,
								ts->start[parmListPtr], ts->stdErr[parmListPtr], "Alpha0      ");
							sprintf(l_str, "m2alpha0%-d", i + 1);
							strcat(ts->outestVarName, l_str);
							strcat(ts->outestVarName, " ");
							parmListPtr++;
						}
					}
					for (j = 1; j <= (int)ts->iorder[1][i]; j++)
					{
						sprintf(parmLabel, "Alpha%-d      ", j);
						writeParmLine(0, ts->iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], parmLabel);
						sprintf(l_str, "m2alpha%-d", i + 1);
						if (!ts->commonIorder[1]) sprintf(l_str, "m2alpha%-dG%-d", j, i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
				}
				sprintf(hdr, " \n"); SF_display(hdr);
			}
			sprintf(hdr, "  Group membership (model 2 group | model 1 group) \n");
			SF_display(hdr);
			sprintf(hdr, " \n"); SF_display(hdr);
			for (i = 0; i < ts->nOrders[1]; i++) ts->pv_2[i] = 0.;
			for (j = 0; j < ts->nOrders[0]; j++)
			{
				d1 = 1.;
				for (i = 0; i < ts->nOrders[1] - 1; i++) d1 += exp(ts->start[parmListPtr + i]);
				temp3 = 100. / d1;
				ts->pv_jk[j * ts->nOrders[1]] = temp3;
				if (ts->nRisk[1] == 0)
					ts->pv_2[0] += temp3 * ts->group_percent[j] / 100.;
				else ts->pv_2[0] = MACMISSING;
				/* delta mthd for group percents */
				if (ts->nRisk[1] == 0 && ts->iflt == 0)
					mlogitDeltaMethod(parmListPtr, ts->nOrders[1], ts);
				if (ts->nRisk[1] > 0)
				{
					for (i = 0; i < ts->nOrders[1]; i++)
					{
						if (i == (int)ts->referenceGroup[1])
						{
							sprintf(hdr,
								" %-d|%-d     Baseline         (0.00000)           .               .            . \n",
								(int)ts->referenceGroup[1] + 1, j + 1);
							SF_display(hdr);
						}
						else
						{
							if (ts->iflt == 0)
							{
								temp = ts->stdErr[parmListPtr] > MACEPS ?
									ts->start[parmListPtr] / ts->stdErr[parmListPtr] :
									MACMISSING;
								tprob(fabs(temp), ts->nData, &temp2);
								temp2 = 2. * (1. - temp2);
							}
							else temp = temp2 = MACMISSING;
							ts->pv_2[i + 1] = MACMISSING;
							sprintf(w1_str, ".");
							if (!IS_MISSING(temp)) sprintf(w1_str, "%12.3f", temp);
							sprintf(w2_str, ".");
							if (!IS_MISSING(temp2)) sprintf(w2_str, "%8.4f", temp2);
							sprintf(w3_str, ".");
							if (!IS_MISSING(ts->stdErr[parmListPtr]))
								sprintf(w3_str, "%11.5f", ts->stdErr[parmListPtr]);
							sprintf(hdr, " %-d|%-d     Constant       %10.5f  %s    %s     %s\n",
								i + 1, j + 1, ts->start[parmListPtr], w3_str, w1_str, w2_str);
							SF_display(hdr);
							sprintf(l_str, "m2const%-dG%-d", i + 1, j + 1);
							strcat(ts->outestVarName, l_str);
							strcat(ts->outestVarName, " ");
							parmListPtr++;
						}
					}
					sprintf(hdr, " \n");
					SF_display(hdr);
				}
				else
				{
					for (i = 0; i < ts->nOrders[1]; i++)
					{
						ts->hpi[i * ts->nOrders[1] + i] = fabs(ts->hpi[i * ts->nOrders[1] + i]);
						ts->prdw[i] = 100. * sqrt(ts->hpi[i * ts->nOrders[1] + i]);
						if (i > 0)
						{
							ts->start[parmListPtr] = ts->start[parmListPtr] > MAXEXP ?
								MAXEXP : ts->start[parmListPtr];
							ts->start[parmListPtr] = ts->start[parmListPtr] < -MAXEXP ?
								-MAXEXP : ts->start[parmListPtr];
							ts->pv_jk[j * ts->nOrders[1] + i] = exp(ts->start[parmListPtr]) / d1 * 100.;
						}
						if (ts->iflt == 0)
						{
							temp = ts->prdw[i] > MACEPS ?
								ts->pv_jk[j * ts->nOrders[1] + i] / ts->prdw[i] : MACMISSING;
							tprob(fabs(temp), ts->nData, &temp2);
							temp2 = 2. * (1. - temp2);
						}
						else
							temp = temp2 = ts->prdw[i] = MACMISSING;
						if (i > 0)
						{
							temp3 = exp(ts->start[parmListPtr]) / d1 * 100.;
							ts->pv_jk[j * ts->nOrders[1] + i] = temp3;
							ts->pv_2[i] += temp3 * ts->group_percent[j] / 100.;
						}
						sprintf(w1_str, ".");
						if (!IS_MISSING(temp)) sprintf(w1_str, "%12.3f", temp);
						sprintf(w2_str, ".");
						if (!IS_MISSING(temp2)) sprintf(w2_str, "%8.4f", temp2);
						sprintf(w3_str, ".");
						if (!IS_MISSING(ts->prdw[i])) sprintf(w3_str, "%11.5f", ts->prdw[i]);
						sprintf(hdr, " %-d|%-d     (%%)            %10.5f  %s    %s     %s\n",
							i + 1, j + 1, temp3, w3_str, w1_str, w2_str);
						SF_display(hdr);
						if (i > 0)
						{
							sprintf(l_str, "m2theta%-dG%-d", i + 1, j + 1);
							strcat(ts->outestVarName, l_str);
							strcat(ts->outestVarName, " ");
							parmListPtr++;
						}
					}
				}
			}
			if (ts->nRisk[1] == 0 && ts->nRisk[0] == 0)
			{
				if (!ts->noprint)
				{
					sprintf(hdr, " \n"); SF_display(hdr);
					sprintf(hdr, "  Group membership (model 1 group | model 2 group) \n");
					SF_display(hdr);
					sprintf(hdr, " \n"); SF_display(hdr);
				}
				for (i = 0; i < ts->nOrders[1]; i++)
				{
					for (j = 0; j < ts->nOrders[0]; j++)
					{
						temp3 = ts->pv_jk[j * ts->nOrders[1] + i] * ts->group_percent[j] / ts->pv_2[i];
						if (!ts->noprint)
						{
							sprintf(hdr, " %-d|%-d    (%4.1f%%)\n", j + 1, i + 1, temp3);
							SF_display(hdr);
						}
					}
				}
				if (!ts->noprint)
				{
					sprintf(hdr, " \n");
					SF_display(hdr);
					sprintf(hdr, "  Group membership (model 1 group and model 2 group) \n");
					SF_display(hdr);
					sprintf(hdr, " \n");
					SF_display(hdr);
				}
				for (i = 0; i < ts->nOrders[1]; i++)
				{
					for (j = 0; j < ts->nOrders[0]; j++)
					{
						temp3 = ts->pv_jk[j * ts->nOrders[1] + i] * ts->group_percent[j] / 100.;
						if (!ts->noprint)
						{
							sprintf(hdr, " %-d %-d    (%4.1f%%) \n", j + 1, i + 1, temp3);
							SF_display(hdr);
						}
					}
				}
				if (!ts->noprint)
				{
					sprintf(hdr, " \n");
					SF_display(hdr);
					sprintf(hdr, "  Group membership (model 2 group) \n");
					SF_display(hdr);
					sprintf(hdr, " \n");
					SF_display(hdr);
				}
				for (i = 0; i < ts->nOrders[1]; i++)
				{
					temp3 = ts->pv_2[i];
					if (!ts->noprint)
					{
						sprintf(hdr, " %-d (%4.1f%%) \n", i + 1, temp3);
						SF_display(hdr);
					}
				}
				sprintf(hdr, " \n");
				SF_display(hdr);
			}
			if (ts->nRisk[1] > 0)
			{
				for (i = 0; i < (ts->nOrders[1] - 1); i++)
				{
					for (r = 0; r < ts->nRisk[1]; r++)
					{
						writeParmLine(i + 2, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], ts->riskNames[1][r]);
						sprintf(l_str, "%sG%-d", ts->riskNames[1][r], i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");
						parmListPtr++;
					}
				}
			}
		}
	}
	snprintf(buf, 34, " BIC(N=%d): %-11.2f ", ts->nData, ts->mdlFit[1]);
	SF_display(buf);
	snprintf(buf, 33, "BIC(N=%d): %-11.2f ", ts->bicnobs, ts->mdlFit[0]);
	SF_display(buf);
	snprintf(buf, 17, "AIC: %-11.2f", ts->mdlFit[2]);
	SF_display(buf);
	snprintf(buf, 16, "ll: %-11.2f\n", ts->mdlFit[4]);
	SF_display(buf);
	SF_macro_save("_outvars", ts->outestVarName); 
	return 0;
}

