/* 
	Posterior probabilies and group classifications

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.

	input:  Count - observation number
			traj likelihood (single, multi, joint)
			number of groups (single, multi, joint)
	output: ts->classifiedGroup[0], ts->classifiedGroup[1], 
			ts->posteriorProb[0][j], ts->posteriorProb[1][j]: j = 1...K
*/

#include "ctraj.h"

void calcClassifications(int *Count, void *qi) {
	
	struct	TRAJSTRUCT *ts = qi;
	int		j, k;
	double	**modelLk, highProb;

	modelLk = ts->obsTrajLk[0];
	if (ts->likelihoodType == MULTI) modelLk = ts->obsMultTrajLk;
	if (ts->likelihoodType == JOINT)
	{
		highProb = 0.;
		ts->classifiedGroup[1] = 1.;
		for (j = 0; j < ts->nOrders[1]; j++) 
		{
			ts->posteriorProb[1][j] = 0;
			for (k = 0; k < ts->nOrders[0]; k++) 
				ts->posteriorProb[1][j] += ts->obsJointTrajLk[k][j][*Count];
			if (ts->posteriorProb[1][j] > highProb) 
			{
				ts->classifiedGroup[1] = j + 1.;
				highProb = ts->posteriorProb[1][j];
			}
		}
	}
	ts->classifiedGroup[0] = 1.;		
	highProb = 0.;
	for (j = 0; j < ts->nOrders[0]; j++) 
	{
		ts->posteriorProb[0][j] = modelLk[j][*Count];
		if (ts->nOrders[1] > 0 && !ts->multModel) 
		{
			ts->posteriorProb[0][j] = 0.;
			for (k = 0; k < ts->nOrders[1]; k++) 
				ts->posteriorProb[0][j] += ts->obsJointTrajLk[j][k][*Count];
		}
		if (ts->posteriorProb[0][j] > highProb) 
		{
			ts->classifiedGroup[0] = j + 1.;
			highProb = ts->posteriorProb[0][j];
		}
	}
}
