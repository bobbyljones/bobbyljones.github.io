/* 	
	Calculate parameter positions

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.	
*/

#include "ctraj.h"

void parmPositions(void *qinfo) {

	struct TRAJSTRUCT *ts = qinfo;
	int	i, m, os;

	os = 0;

	for (m = 0; m < ts->nModels; m++)
	{
		ts->riskOffset[m] = os;	

		for (i = 0; i < ts->nOrders[m]; i++)
		{
			ts->riskOffset[m] += (int)ts->order[m][i] + 1 + ((int)ts->order[m][i] + 1 > 0) * ts->nTcovParms[m];
		}

		if (ts->dropoutStmt[m])												
		{		
 			ts->dLoc[m] = ts->riskOffset[m];		
			ts->riskOffset[m] += (int)ts->dOrd[m][0] + 1;			
			if (ts->dcovStmt[m] && (int)ts->dOrd[m][0] != -1) ts->riskOffset[m] += ts->nDcovPrm[m];
			
			if (ts->nDropout[m] > 1)
			{
				for (i = 1; i < ts->nOrders[m]; i++)
				{
					ts->riskOffset[m] += (int)ts->dOrd[m][i] + 1;			
					if (ts->dcovStmt[m] && (int)ts->dOrd[m][i] != -1) ts->riskOffset[m] += ts->nDcovPrm[m];
				}
			}
		}
		
		if (ts->modelType[m] == m_cnorm) 
		{
			ts->riskOffset[m] += ts->ar1 ? 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[m] - 1) :
				                           1 + ts->sigmaByGroup * (ts->nOrders[m] - 1 - ts->all0Group[m]);
		}

		if (ts->modelType[m] == m_zibeta) ts->riskOffset[m] += ts->nOrders[m];										

		if (m == 0 && ts->rorderStmt[0])
		{
			ts->modelSubtype[0] = MIXEDMODEL;
			ts->rorderOffset = ts->riskOffset[0];		
			ts->riskOffset[0] += ts->nRorderPrm;
		}
					
		if (ts->iorderStmt[m])												
		{		
			ts->zipParmOffset[m] = ts->riskOffset[m];			
			ts->riskOffset[m] += (int)ts->iorder[m][0] + 1; 
			if (!ts->commonIorder[m])
				for (i = 1; i < ts->nOrders[m]; i++) 
					ts->riskOffset[m] += (int)ts->iorder[m][i] + 1;
		}

		os += ts->nModelParm[m];
	}

	return;
}
