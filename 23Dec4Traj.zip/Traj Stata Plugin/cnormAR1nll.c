/* 	
	cnorm AR1 model

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>

	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"

void cnormAR1nll(double* prm, void* qi) {

	struct	TRAJSTRUCT* ts = qi;
	char	buf[90], ta, tb = 'N';
	int		dLoc, dOrd, gp, i_1 = 1, iC, iNC, i2C, i2M, i2NC, iseed = 123, j, l, r, r2, iflt, itp, im,
			nc, nrep, nv, obs, os;
	double	aeps = ABSEPS, d_1 = 1., d_0 = 0., det2[2], dtr2, err, pr, rlp = 0., sgi, sgsqi, *tcovPtr,
			x, xb;

	nv = (ts->probupdates && ts->nPrUpdt > 0) ? ts->nPrUpdt : ts->nIndep[0];
	nrep = 5000 * (int)pow((double)ts->nIndep[0], 3.);
	os = 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[0] - 1);
	os = ts->riskOffset[ts->mdl] - os;
	if (ts->dropoutStmt[0] && ts->mdl == 0) dLoc = ts->dLoc[0];
	if (ts->sigmaByGroup)
	{
		for (gp = 0; gp < ts->nOrders[0]; gp++)
		{
			ts->sigmaSq[0][gp] = pow(exp(prm[os]), 2.);
			os++;
		}
	} 
	else 
	{
		for (gp = 0; gp < ts->nOrders[0]; gp++) ts->sigmaSq[0][gp] = pow(exp(prm[os]), 2.);
		os++;
	}
	if (ts->rhoByGroup)
	{
		for (gp = 0; gp < ts->nOrders[0]; gp++)
		{
			ts->rho[0][gp] = invlogit(prm[os]);
			os++;
		}
	} 
	else 
	{
		for (gp = 0; gp < ts->nOrders[0]; gp++) ts->rho[0][gp] = invlogit(prm[os]);
		os++;
	}
	/* variance matrix for shared-group sigma/rho */
	if (!ts->sigmaByGroup && !ts->rhoByGroup)
	{
		sgsqi = pow(ts->sigmaSq[0][0], -1.);
		sgi = pow(sgsqi, .5);
		for (r = 0; r < nv; r++)
		{
			for (j = 0; j < nv; j++)
			{
				ts->smtrx[r * nv + j] = ts->sigmaSq[0][0] * pow(ts->rho[0][0], abs(j - r));
			}
		}
	}
	for (obs = 0; obs < ts->nObs; obs++)
	{
		os = 0;
		tcovPtr = 0;
		if (ts->nTcov[ts->mdl] > 0) tcovPtr = ts->tcov[ts->mdl][obs];
		if (ts->dropoutStmt[0] && ts->mdl == 0) dLoc = ts->dLoc[0];
		for (gp = 0; gp < ts->nOrders[0]; gp++)
		{
			ts->obsTrajLk[ts->mdl][gp][obs] = 1.;
			if (ts->dropoutStmt[0] && ts->mdl == 0)	ts->obsDropoutLk[0][gp][obs] = 1.;
			if (ts->probupdates && ts->nPrUpdt > 0) ts->obsTrajLk_T[ts->mdl][gp][obs][nv] = 1.;
			if (ts->skip[obs] || ts->allMissV[ts->mdl][obs]) continue;
			/* variance matrix for by-group sigma/rho */
			if (ts->sigmaByGroup || ts->rhoByGroup)
			{
				sgsqi = pow(ts->sigmaSq[0][gp], -1.);
				sgi = pow(sgsqi, .5);
				for (r = 0; r < nv; r++)
					for (j = 0; j < nv; j++)
						ts->smtrx[r * nv + j] = ts->sigmaSq[0][gp] * pow(ts->rho[0][gp], abs(j - r));
			}
			if (ts->dropoutStmt[0] && ts->mdl == 0)
			{
				dOrd = (int)ts->dOrd[0][0];
				if (ts->nDropout[0] > 1) dOrd = (int)ts->dOrd[0][gp];
				for (j = 0; j < nv; j++)
				{
					ts->varDropoutLk[0][gp][obs][j] = dropoutLk(&obs, &gp, &j, prm, &dOrd, &dLoc, qi);
					ts->obsDropoutLk[0][gp][obs] *= ts->varDropoutLk[0][gp][obs][j];
				}
			}
			/* censored data(ymxb1), uncensored(ymxb2)	*/
			iC = iNC = 0;
			/* ***** iC indexes censored data (ymxb1), iNC indexes uncensored data (ymxb2) */
			for (j = 0; j < nv; j++)
			{
				/* skip if missing data at a timepoint (missV from get data routine) */
				if (ts->missV[ts->mdl][obs][j]) continue;
				/* calc lin pred xb, subtract from data	*/
				xb = linPred(prm, &ts->indep[ts->mdl][obs][j], &os, &j, &ts->nIndep[ts->mdl],
							 &ts->order[ts->mdl][gp], &ts->nTcovParms[ts->mdl], tcovPtr);
				if (ts->dep[ts->mdl][obs][j] <= ts->varMin[ts->mdl])
				{
					ts->ymxb1[iC] = ts->varMin[ts->mdl] - xb;
					ts->intlimit[iC] = 0;
					iC++;
				}
				else if (ts->dep[ts->mdl][obs][j] < ts->varMax[ts->mdl])
				{
					ts->ymxb2[iNC] = ts->dep[ts->mdl][obs][j] - xb;
					iNC++;
				}
				else
				{
					ts->ymxb1[iC] = ts->varMax[ts->mdl] - xb;
					ts->intlimit[iC] = 1;
					iC++;
				}
			}
			nc = iC + iNC;
			/* ***** data count = nc, ymxb1 <- any censored then uncensored */
			for (r = iC; r < nc; r++) ts->ymxb1[r] = ts->ymxb2[r - iC];
			if (nc < nv || (iC > 0 && iNC > 0))
			{
				i2C = 0;
				i2NC = iC;
				i2M = nv - 1;
				/* ***** permutation matrix (smtrxC) to reorder	sigma	*/
				/* ***** for missing data or censor/uncensored mix		*/
				for (j = 0; j < nv; j++)
				{
					for (r = 0; r < nc; r++) ts->smtrxC[j * nv + r] = 0.;
					if (ts->missV[ts->mdl][obs][j] == 1)
					{
						ts->smtrxC[j * nv + i2M] = 1.;
						i2M--;
					}
					else if (ts->dep[ts->mdl][obs][j] <= ts->varMin[ts->mdl] ||
							 ts->dep[ts->mdl][obs][j] >= ts->varMax[ts->mdl])
					{
						ts->smtrxC[j * nv + i2C] = 1.;
						i2C++;
					}
					else
					{
						ts->smtrxC[j * nv + i2NC] = 1.;
						i2NC++;
					}
				}
				/* V = t(smtrxC)*smtrx*smtrxC */
				ta = 'N';
				dgemm_(&ta, &tb, &nv, &nv, &nv, &d_1, ts->smtrxC,
					   &nv, ts->smtrx, &nv, &d_0, ts->simtrx2, &nv);
				tb = 'T';
				dgemm_(&ta, &tb, &nv, &nv, &nv, &d_1, ts->simtrx2, &nv,
					   ts->smtrxC, &nv, &d_0, ts->smtrx21, &nv);
				for (r2 = 0; r2 < nc; r2++)
				{
					for (r = 0; r < nc; r++)
					{
						ts->V[r * nc + r2] = ts->smtrx21[r * nv + r2];
					}
				}
			}
			else
			{	/* no missing data/reordering, V = smtrx */
				for (r2 = 0; r2 < nc; r2++)
					for (r = 0; r < nc; r++)
						ts->V[r * nc + r2] = ts->smtrx[r * nc + r2];
			}
			/* uncensored, smitrx2=sigma inverse, dtr2=|S|, ymxb2 is work */
			if (iNC > 0)
			{
				/* factor uncensored S-inv into upper tri ts->simtrx2 for dgedi */
				for (r = iC; r < nc; r++)
					for (r2 = iC; r2 < nc; r2++)
						ts->simtrx2[(r2 - iC) * iNC + (r - iC)] = ts->V[r2 * nc + r];
				dgefa_(ts->simtrx2, &iNC, &iNC, ts->iwork, &iflt);
				if (iflt != 0)
				{
					WRITELOG("Obs %d cnorm AR1 Problem factoring: %d\n", obs + 1, iflt);
					goto  L100;

				}
				else 
				{
					/* sigma inverse = ts->simtrx2 */
					itp = 11;
					dgedi_(ts->simtrx2, &iNC, &iNC, ts->iwork, det2, ts->ymxb2, &itp);
				}
				dtr2 = det2[0] * pow(10., det2[1]);
				if (dtr2 <= 0.)
				{
					WRITELOG("%d cnorm AR1 problem inverting: %f\n", obs + 1, dtr2);
					goto  L100;
				}
			}
			/* f_censored(y=min,y=max | min<y<max) 1=C, 2=NC
			conditional mean		sg12*sg22 inv -> sm11, sg12*sg22 inv*(y-xb)[NC] -> ymxb2
			conditional variance    sg12*sg22 inv * sg21 -> smitrx1, subtract from sg11 (-> sm11) */
			if (iC > 0 && iNC > 0)
			{
				for (l = iC; l < nc; l++)
					for (r = 0; r < iC; r++)
						ts->smtrx21[(l - iC) * iC + r] = ts->V[l * nc + r];
				for (l = 0; l < iC; l++)
				{
					for (r = 0; r < iNC; r++)
					{
						ts->smtrx11[l * iNC + r] = 0.;
						for (r2 = 0; r2 < iNC; r2++)
						{
							ts->smtrx11[l * iNC + r] += 
								ts->smtrx21[r2 * iC + l] * ts->simtrx2[r * iNC + r2];
						}
					}
				}
				for (l = 0; l < iC; l++)
				{
					ts->ymxb2[l] = -ts->ymxb1[l];
					for (r2 = 0; r2 < iNC; r2++)
					{
						ts->ymxb2[l] += ts->smtrx11[l * iNC + r2] * ts->ymxb1[iC + r2];
					}
				}
				for (l = 0; l < iC; l++)
				{
					for (r = 0; r < iC; r++)
					{
						ts->simtrx1[l * iC + r] = 0.;
						for (r2 = 0; r2 < iNC; r2++)
						{
							ts->simtrx1[l * iC + r] +=
								ts->smtrx11[r * iNC + r2] * ts->smtrx21[r2 * iC + l];
						}
					}
				}
				for (l = 0; l < iC; l++)
					for (r = 0; r < iC; r++)
						ts->smtrx11[l * iC + r] = ts->V[l * nc + r] - ts->simtrx1[l * iC + r];
				/* smtrxC = correlation matrix	*/
				for (l = 0; l < iC; l++)
					for (r = 0; r < iC; r++)
						ts->smtrxC[l * iC + r] = (l == r) ? pow(ts->smtrx11[l * iC + r], -.5) : 0.;
				/* ymxb2 = conditional mean	*/
				for (r = 0; r < iC; r++) 
					ts->ymxb2[r] = -ts->ymxb2[r] * pow(ts->smtrx11[r * iC + r], -.5);
				ta = 'N';
				dgemm_(&ta, &tb, &iC, &iC, &iC, &d_1, ts->smtrxC,
					   &iC, ts->smtrx11, &iC, &d_0, ts->smtrx12, &iC);
				ta = 'N';
				dgemm_(&ta, &tb, &iC, &iC, &iC, &d_1, ts->smtrx12,
					   &iC, ts->smtrxC, &iC, &d_0, ts->smtrx11, &iC);
				for (r = iC - 1; r > 0; r--)
					for (r2 = 0; r2 < r; r2++)
						ts->smtrx12[r2 + (r - 1) * r / 2] = ts->smtrx11[r * iC + r2];
				/* pr = conditional censored | uncensored */
				MVN_Pr_(&iC, ts->ymxb2, ts->ymxb2, ts->intlimit, ts->smtrx12, &nrep, &aeps,
						&rlp, &err, &pr, &im, &iseed, qi);
				if (im != 0)
				{
					WRITELOG("cnorm AR1 mvn prob error obs %d \n", obs + 1);
					goto  L100;
				}
				else ts->obsTrajLk[ts->mdl][gp][obs] = pr;
			}
			/* all censored */
			if (iC > 0 && iNC == 0)
			{
				/* smtrx12 = correlation for MVN_Pr */
				for (r = nc - 1; r > 0; r--)
					for (r2 = 0; r2 < r; r2++)
						ts->smtrx12[r2 + (r - 1) * r / 2] = ts->V[r * nc + r2] * sgsqi;
				/* standardize (y[C] - xb) / sigma */
				for (r = 0; r < iC; r++) ts->ymxb2[r] = ts->ymxb1[r] * sgi;
				MVN_Pr_(&iC, ts->ymxb2, ts->ymxb2, ts->intlimit, ts->smtrx12, &nrep, &aeps, &rlp,
						&err, &pr, &im, &iseed, qi);
				if (im != 0)
				{
					WRITELOG("cnorm AR1 MVN problem obs %d %d \n", obs + 1, im);
					goto  L100;
				}
				else ts->obsTrajLk[ts->mdl][gp][obs] = pr;
			}
			/* all uncensored, pr = unconditional probability */
			/* mixed, pr = conditional pr(C|NC) from above * unconditional pr */
			if (iNC > 0)
			{
				ta = 'N';
				tb = 'N';
				/* ymxb2 = S-inv * (y[NC] - xb) */
				dgemm_(&ta, &tb, &iNC, &i_1, &iNC, &d_1, ts->simtrx2, &iNC, ts->ymxb1 + iC, &iNC,
					   &d_0, ts->ymxb2, &iNC);
				/* x = t(y[NC] - xb) * ymxb2 */
				x = sdot_(&iNC, ts->ymxb1 + iC, &i_1, ts->ymxb2, &i_1);
				pr = pow(RSQRT2PI, iNC) * pow(dtr2, -.5) * exp(-.5 * x);
				ts->obsTrajLk[ts->mdl][gp][obs] *= pr;
			}
		L100:;
			if (ts->probupdates && ts->nPrUpdt > 0)
				ts->obsTrajLk_T[ts->mdl][gp][obs][nv] = ts->obsTrajLk[ts->mdl][gp][obs];
			/* advance pointers to next group and dropout parameters */
			os += (int)ts->order[0][gp] + 1 + ((int)ts->order[0][gp] + 1 > 0) * ts->nTcovParms[0];
			if (ts->dropoutStmt[0] && ts->mdl == 0)
				if (ts->nDropout[0] > 1) dLoc += (int)ts->dOrd[0][gp] + 1 + ts->nDcovPrm[0];
		}
	}
}
