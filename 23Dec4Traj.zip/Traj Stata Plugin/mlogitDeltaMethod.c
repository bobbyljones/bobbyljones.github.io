/* 	
	Multinomial logit delta method

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include	 "ctraj.h"

void mlogitDeltaMethod(int os, int np, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		i, j, k, ofs, r, r2;
	double	d1;

	ofs = os;
	d1 = 1.;

	for (i = 0; i < np - 1; i++)
	{
		ts->start[ofs + i] = ts->start[ofs + i] > MAXEXP ? MAXEXP : ts->start[ofs + i];
		ts->start[ofs + i] = ts->start[ofs + i] < -MAXEXP ? -MAXEXP : ts->start[ofs + i];
		d1 += exp(ts->start[ofs + i]);
	}
	for (j = 0; j < np - 1; j++) ts->hw2[j] = -exp(ts->start[ofs + j]) * pow(d1, -2.);
	for (i = 0; i < np - 1; i++)
	{
		for (j = 0; j < np - 1; j++)
		{
			if (i == j)
				ts->hw2[(i + 1) * (np - 1) + j] = 
					exp(ts->start[ofs + i]) * (d1 - exp(ts->start[ofs + i])) * pow(d1, -2.);
			else
				ts->hw2[(i + 1) * (np - 1) + j] = -exp(ts->start[ofs + i] + 
					ts->start[ofs + j]) * pow(d1, -2.);
		}
		for (k = 0; k < np; k++)
		{
			for (r = 0; r < np - 1; r++)
			{
				ts->hw[k * (np - 1) + r] = 0.;
				for (r2 = ofs; r2 < ofs + np - 1; r2++) 
					ts->hw[k * (np - 1) + r] += ts->hessian[(r + ofs) *
						(ts->totalParms) + r2] * ts->hw2[k * (np - 1) + r2 - ofs];
			}
		}
		for (k = 0; k < np; k++)
		{
			for (r = 0; r < np; r++)
			{
				ts->hpi[k * np + r] = 0.;
				for (r2 = 0; r2 < np - 1; r2++) 
					ts->hpi[k * np + r] += ts->hw2[k * (np - 1) + r2] * ts->hw[r *(np - 1) + r2];
			} 
		} 
	}
}