/* 	
	linear predictor

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.

	-- tcovType tcov[mdl][obs] or plotTcov[mdl]
*/

