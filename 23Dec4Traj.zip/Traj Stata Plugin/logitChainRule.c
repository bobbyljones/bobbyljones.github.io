/* 
	chain rule logit model

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 	
*/

#include "ctraj.h"

void logitChainRule(int n, int* mdl, int* obs, int* gp, int* wv, double* prm, int* os, double* w, void* qi)
{
	struct	TRAJSTRUCT* ts = qi;
	int		j, ofs;
	double	sign, x;

	ofs = *os;
	if (ts->likelihoodType == JOINT)
	{
		ofs = *mdl == 1 ? ts->jointOffset : 0;
		for (j = 0; j < *gp; j++)
		{
			ofs += (int)ts->order[*mdl][j] + 1 +
				((int)ts->order[*mdl][j] + 1 > 0) * ts->nTcovParms[*mdl];
		}
	}
	for (j = 0; j < n; j++) w[j] = 0.;
	if ((int)ts->order[*mdl][*gp] == -1 && *gp == 0) return; /* ts->all0Group */
	sign = ts->dep[*mdl][*obs][*wv] <= 0 ? -1. : 1.;
	x = sign * ts->varTrajLk[*mdl][*gp][*obs][*wv] * (1. - ts->varTrajLk[*mdl][*gp][*obs][*wv]); 
	if (ts->nTcov[*mdl] > 0)
		for (j = 0; j < ts->nTcovParms[*mdl]; j++)
			w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = x * ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]];
	for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++)
		w[ofs + j] = x * pow(ts->indep[*mdl][*obs][*wv], j);
	return;
}
