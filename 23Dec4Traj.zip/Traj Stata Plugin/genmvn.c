#include "ctraj.h"

int genmvn(int p, double *tchol, double *work, int *iseed, double *x)
{

int		i, j;
double	rslt;

for (i = 0; i < p; i++)
{ 
	ciOpt_snorm(iseed, &rslt);
	work[i] = rslt;
} 

for (i = 0; i < p; i++)
{
	x[i] = 0.;
	for (j = 0; j < p; j++) 
	{
		x[i] += tchol[i * p + j] * work[j];
	}
}
	return(0);
}

		