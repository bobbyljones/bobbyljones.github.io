/* 	negative log-likelihood for joint trajectory model	
	
	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  */

#include	 "ctraj.h"

int jointModelnll(int n, double *prm, double *fx, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		dLoc, dOrd, dLoc1, dOrd1, i, ifault, j, k, k_2, m,
			os, os_2, os3_2, z_os, z_os_2, zo, zo_2;
	double	*tcovPtr, tmp, rho, lmb, x, xb;
	char	buf[80];

	if (ts->trace) traceOutput("jointModelnll", n, prm);

	*fx = 0.;

	for (m = 0; m < 2; m++) 
	{
		if (ts->modelType[m] == m_cnorm) 
			for (k = 0; k < ts->nOrders[m]; k++)
				ts->sigma[m][k] = ts->sigmaByGroup == 1 ? 
					exp(prm[ts->riskOffset[m] - ts->nOrders[m] + k]) : 
						exp(prm[ts->riskOffset[m] - 1]);
		if (ts->modelType[m] == m_zibeta)
			for (k = 0; k < ts->nOrders[m]; k++) 
				ts->phi[m][k] = 
					exp(prm[ts->riskOffset[m] - ts->nOrders[m] + k]);
		ts->mdl = m;
		if (ts->nRisk[m] < 1) 
			calcGroupProb(0, ts->riskOffset[m], ts->risk[m], prm, qi);
	}
	for (i = 0; i < ts->nObs; i++)
	{
		ts->obsModelLk[i] = 0.;
		os_2 = ts->jointOffset;
		z_os_2 = ts->zipParmOffset[1];
		z_os = ts->zipParmOffset[0];
		zo_2 = 0;
		dLoc1 = ts->dLoc[1];
		if (ts->skip[i]) continue;
		for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
		{
			if (ts->dropoutStmt[1])
			{
				dOrd1 = (int)ts->dOrd[1][0];	
				if (ts->nDropout[1] > 1) dOrd1 = (int)ts->dOrd[1][k_2];
			}
			ts->obsTrajLk[1][k_2][i] = 1.;
			if (ts->dropoutStmt[1]) ts->obsDropoutLk[1][k_2][i] = 1.;
			if (ts->iorderStmt[1])
			{
				zo_2 = (int)ts->iorder[1][0];
				if (!ts->commonIorder[1]) zo_2 = (int)ts->iorder[1][k_2];
			}
			for (j = 0; j < ts->nIndep[1]; j++)
			{
				ts->varTrajLk[1][k_2][i][j] = 1.;
				if (ts->probupdates) ts->obsTrajLk_T[1][k_2][i][j] = 1.;		
				if (ts->missV[1][i][j]) goto L100; 
				rho = 0.;
				if (ts->iorderStmt[1] && zo_2 != -1)
				{
					xb = prm[z_os_2];
					for (m = 1; m <= zo_2; m++) xb += prm[z_os_2 + m] * pow(ts->indep[1][i][j], m);
					rho = invlogit(xb);
				}
				ts->mdl = 1;
				tcovPtr = 0;
				if (ts->nTcov[ts->mdl] > 0) tcovPtr = ts->tcov[ts->mdl][i];
				xb = linPred(prm, &ts->indep[ts->mdl][i][j], &os_2, &j, &ts->nIndep[ts->mdl],
							 &ts->order[ts->mdl][k_2], &ts->nTcovParms[ts->mdl], tcovPtr);
				if (ts->modelType[1] == m_logit)
				{
					xb	= invlogit(xb);
					ts->varTrajLk[1][k_2][i][j] = ts->dep[1][i][j] == 0 ? 1. - xb : xb;
				}
				if (ts->modelType[1] == m_zip)
				{
					xb = xb < -MAXEXP ? -MAXEXP : xb;
					xb = xb > MAXEXP ? MAXEXP : xb;
					lmb = exp(xb);
					if (ts->nExpos[1] > 0) lmb = lmb * ts->exposure[1][i][j];
					if (ts->dep[1][i][j] == 0.)
					{
						lmb = lmb < -MAXEXP ? -MAXEXP : lmb;
						lmb = lmb > MAXEXP ? MAXEXP : lmb;
						ts->varTrajLk[1][k_2][i][j] = (rho + (1. - rho) * exp(-lmb));
					}
					else
						if (lmb <= DBL_MIN)
						{
							ts->obsTrajLk[1][k_2][i] = 0.;
						} 
						else 
						{
							tmp = -lmb + ts->dep[1][i][j] * log(lmb) - alogam(ts->dep[1][i][j] + 1, &ifault);
							tmp = tmp < -MAXEXP ? -MAXEXP : tmp;
							tmp = tmp > MAXEXP ? MAXEXP : tmp;
							ts->varTrajLk[1][k_2][i][j] = (1. - rho) * exp(tmp);
						}
				}
				if (ts->modelType[1] == m_cnorm)
				{
					if (ts->dep[1][i][j] <= ts->varMin[1])
					{
						x = (ts->varMin[1] - xb) * pow(ts->sigma[1][k_2], -1.);
						ts->varTrajLk[1][k_2][i][j]  = mvnphi_(&x);
					}
					else
						if (ts->dep[1][i][j] < ts->varMax[1])
						{
							x = (ts->dep[1][i][j] - xb) * pow(ts->sigma[1][k_2], -1.);
							ts->varTrajLk[1][k_2][i][j] =
								exp(-.5 * x * x) * RSQRT2PI * pow(ts->sigma[1][k_2], -1.);
						}
						else
						{
							x = (ts->varMax[1] - xb) * pow(ts->sigma[1][k_2], -1.);
							ts->varTrajLk[1][k_2][i][j] = 1. - mvnphi_(&x);
						}
				}
				ts->obsTrajLk[1][k_2][i] *= ts->varTrajLk[1][k_2][i][j];
L100:; 
				if (ts->probupdates  && ts->nPrUpdt > 0) ts->obsTrajLk_T[1][k_2][i][j] *= j > 0 ? 
					ts->obsTrajLk_T[1][k_2][i][j - 1] * 
					ts->varTrajLk[1][k_2][i][j] : ts->varTrajLk[1][k_2][i][j];
				if (ts->dropoutStmt[1]) 
				{ 
					ts->varDropoutLk[ts->mdl][k_2][i][j] = dropoutLk(&i, &k_2, &j, prm, &dOrd1, &dLoc1, qi);
					ts->obsDropoutLk[ts->mdl][k_2][i] *= ts->varDropoutLk[ts->mdl][k_2][i][j];
				}
			}
			os_2 += (int)ts->order[1][k_2] + 1 + ((int)ts->order[1][k_2] + 1 > 0) * ts->nTcovParms[1];
			if (ts->dropoutStmt[1])
				if (ts->nDropout[1] > 1) 
					dLoc1 += (int)ts->dOrd[1][k_2] + 1 + ts->nDcovPrm[1];
			if (ts->iorderStmt[1])
				if (!ts->commonIorder[1])
					z_os_2 += (int)ts->iorder[1][k_2] + 1;
		}														
		ts->mdl = 0;
		if (ts->nRisk[0] > 0) calcGroupProb(i, ts->riskOffset[0], ts->risk[0], prm, qi);
		os = zo = 0;
		os3_2 = ts->riskOffset[1];
		dLoc = ts->dLoc[0];
		for (k = 0; k < ts->nOrders[0]; k++)
		{
			if (ts->iorderStmt[0])
			{
				zo = (int)ts->iorder[0][0];
				if (!ts->commonIorder[0]) zo = (int)ts->iorder[0][k];
			}
			if (ts->dropoutStmt[0])
			{
				dOrd = (int)ts->dOrd[0][0];
				if (ts->nDropout[0] > 1) dOrd = (int)ts->dOrd[0][k];
			}
			ts->obsTrajLk[0][k][i] = 1.;
			if (ts->dropoutStmt[0]) ts->obsDropoutLk[0][k][i] = 1.;
			for (j = 0; j < ts->nIndep[0]; j++)
			{
				ts->varTrajLk[0][k][i][j] = 1.;
				if (ts->probupdates) ts->obsTrajLk_T[0][k][i][j] = 1.;		
				if (ts->skip[i]) goto L500;
				if (ts->missV[0][i][j]) goto L500;
				rho = 0.;
				if (ts->iorderStmt[0] && zo != -1)
				{
					xb = prm[z_os];
					for (m = 1; m <= zo; m++) xb += prm[z_os + m] * pow(ts->indep[0][i][j], m);
					rho = invlogit(xb);
				}
				ts->mdl = 0;
				tcovPtr = 0;
				if (ts->nTcov[ts->mdl] > 0) tcovPtr = ts->tcov[ts->mdl][i];
				xb = linPred(prm, &ts->indep[ts->mdl][i][j], &os, &j, &ts->nIndep[ts->mdl],
							 &ts->order[ts->mdl][k], &ts->nTcovParms[ts->mdl], tcovPtr);
				if (ts->modelType[0] == m_cnorm)
				{
					if (ts->dep[0][i][j] <= ts->varMin[0])
					{
						x = (ts->varMin[0] - xb) * pow(ts->sigma[0][k], -1.);
						ts->varTrajLk[0][k][i][j]  = mvnphi_(&x);
					}
					else
						if (ts->dep[0][i][j] < ts->varMax[0])
						{
							x = (ts->dep[0][i][j] - xb) * pow(ts->sigma[0][k], -1.);
							ts->varTrajLk[0][k][i][j] = exp(-.5 * x * x) * RSQRT2PI * pow(ts->sigma[0][k], -1.);
						}
						else
						{
							x = (ts->varMax[0] - xb) * pow(ts->sigma[0][k], -1.);
							ts->varTrajLk[0][k][i][j]  = 1. - mvnphi_(&x);
						}
				}
				if (ts->modelType[0] == m_logit)
				{				
					xb = invlogit(xb);
					ts->varTrajLk[0][k][i][j] = ts->dep[0][i][j] == 0 ? 1. - xb : xb;
				}
				if (ts->modelType[0] == m_zip)
				{
					xb = xb < -MAXEXP ? -MAXEXP : xb;				
					xb = xb > MAXEXP ? MAXEXP : xb;
					lmb = exp(xb);
					if (ts->nExpos[0] > 0)
						lmb = !IS_MISSING(ts->exposure[0][i][j]) ? 
							lmb * ts->exposure[0][i][j] : lmb;
					if (ts->dep[0][i][j] == 0.)
					{
						lmb = lmb < -MAXEXP ? -MAXEXP : lmb;
						lmb = lmb > MAXEXP ? MAXEXP : lmb;
						ts->varTrajLk[0][k][i][j] = rho + (1. - rho) * exp(-lmb);
					}
					else
						if (lmb <= DBL_MIN) ts->obsTrajLk[0][k][i] = 0.;
						else
						{
							tmp = -lmb + ts->dep[0][i][j] * log(lmb) - alogam(ts->dep[0][i][j] + 1, &ifault);
							tmp = tmp < -MAXEXP ? -MAXEXP : tmp;										
							tmp = tmp > MAXEXP ? MAXEXP : tmp;
							ts->varTrajLk[0][k][i][j] = (1. - rho) * exp(tmp);
						}
				}
				ts->obsTrajLk[0][k][i] *= ts->varTrajLk[0][k][i][j];
L500:;
				if (ts->probupdates  && ts->nPrUpdt > 0) ts->obsTrajLk_T[0][k][i][j] *= j > 0 ? 
					ts->obsTrajLk_T[0][k][i][j - 1] * 
					ts->varTrajLk[0][k][i][j] : ts->varTrajLk[0][k][i][j];
				if (ts->dropoutStmt[0])
				{
					ts->varDropoutLk[ts->mdl][k][i][j] = dropoutLk(&i, &k, &j, prm, &dOrd, &dLoc, qi);
					ts->obsDropoutLk[ts->mdl][k][i] *= ts->varDropoutLk[ts->mdl][k][i][j];
				}
			}
			ts->obsTrajLk[0][k][i] *= ts->groupProb[0][k];
			if (ts->dropoutStmt[0])
				if (!IS_MISSING(ts->obsDropoutLk[0][k][i])) 
					ts->obsTrajLk[0][k][i] *= ts->obsDropoutLk[0][k][i];
			if (ts->probupdates && ts->nPrUpdt > 0 && !ts->skip[i]) 
			{
				for (j = 0; j < ts->nIndep[0]; j++) 
				{
					ts->obsTrajLk_T[0][k][i][j] *= ts->groupProb[0][k];
					if (ts->dropoutStmt[0])
						if (!IS_MISSING(ts->obsDropoutLk[0][k][i])) 
							ts->obsTrajLk_T[0][k][i][j] *= ts->obsDropoutLk[0][k][i];
				}
			}
			ts->mdl = 1;
			calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
			for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
			{
				if (ts->dropoutStmt[1])
					if (!IS_MISSING(ts->obsDropoutLk[1][k_2][i])) 
						ts->obsTrajLk[1][k_2][i] *= ts->obsDropoutLk[1][k_2][i];
				ts->obsJointTrajLk[k][k_2][i] = ts->obsTrajLk[0][k][i] * ts->groupProb[1][k_2] *
												ts->obsTrajLk[1][k_2][i];
				ts->obsModelLk[i] += ts->obsJointTrajLk[k][k_2][i];
				if (ts->probupdates && ts->nPrUpdt > 0 && !ts->skip[i])
				{
					for (j = 0; j < ts->nIndep[1]; j++)
					{
						ts->obsTrajLk_T[1][k_2][i][j] *= ts->groupProb[1][k_2];
						if (ts->dropoutStmt[1])
							if (!IS_MISSING(ts->obsDropoutLk[1][k_2][i]))
								ts->obsTrajLk_T[1][k_2][i][j] *= ts->obsDropoutLk[1][k_2][i];
					}
				}
			}
			os += (int)ts->order[0][k] + 1 + ((int)ts->order[0][k] + 1 > 0) * ts->nTcovParms[0];
			if (ts->dropoutStmt[0])
				if (ts->nDropout[0] > 1)
					dLoc += (int)ts->dOrd[0][k] + 1 + ts->nDcovPrm[0];
			if (ts->iorderStmt[0])
				if (!ts->commonIorder[0])
					z_os += (int)ts->iorder[0][k] + 1;
			os3_2 += ts->nOrders[1] - 1;
		}								
		if (ts->obsModelLk[i] <= DBL_MIN) 
		{
			*fx = DBL_MAX; 
			goto L999;
		}
		for (k = 0; k < ts->nOrders[0]; k++)
			for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
				ts->obsJointTrajLk[k][k_2][i] *= pow(ts->obsModelLk[i], -1.);
	}
	for (i = 0; i < ts->nObs; i++) 
	{
		if (ts->oos[i] || ts->skip[i]) 
		{ /* continue */
		} 
		else if (ts->obsModelLk[i] > DBL_MIN) 
		{
			*fx -= log(ts->obsModelLk[i]) * ts->weight[i];
		} 
		else 
		{
			*fx = DBL_MAX;
			if (ts->trace) WRITELOG("joint model: obs %d likelihood problem\n", i+1);
			goto L999;
		}
	}
L999:
	if (ts->trace) WRITELOG("nll = %14.8e\n", *fx);
	return 0;
}

