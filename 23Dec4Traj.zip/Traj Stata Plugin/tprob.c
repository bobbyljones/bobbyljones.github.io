#include "ctraj.h"

int tprob(double t, int dof, double *probability)

/* Arguments:
	t : wanna evaluate integral from t to +infinity.
	dof: degrees of freedom of this t distribution.
	probability : computed value might be returned.

	function returns error code 1 if something is wrong,
	0 if all is well.

	This functional interface is not exactly what AS 3 used to be.
*/

{
	double d_dof, s, c, f, a, b;
	int fk, ks, im2, ioe, k;

	if (dof < 1) return 1;
	d_dof = (double) dof;	

	a = t / sqrt(d_dof);
	b = d_dof/(d_dof + (t*t));
	im2 = dof - 2;
	ioe = dof % 2;
	s = c = f = 1.0;
	fk = ks = 2 + ioe;
	if (im2 > 2)
		for (k=ks; k<=im2; k+=2) {
			c = c*b*(fk - 1.0)/fk;
			s += c;
			if (s == f) break;	/* == ? */
			f = s;
			fk += 2;
		}

	if (ioe != 1) {	
		*probability = 0.5 + (0.5*a*sqrt(b)*s);
		if (*probability > 1.) *probability = 1.;
		return 0;
	}
	else {	
		if (dof == 1) s = 0.0;
		*probability = 0.5 + ((a*b*s + atan(a)) * M_1_PI);
		if (*probability > 1.) *probability = 1.;
		return 0;
	}
}
