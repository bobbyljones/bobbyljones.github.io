/* 
	Calculate confidence interval for binomial outcome

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

void logitCI(double n, double p, double rslt[2])
{
	double lo, hi, q1, zc, z2;

	zc = 1.96;
	z2 = zc * zc;
	q1 = zc * sqrt((p * (1. - p) + z2 / 4. / n) / n);
	lo = (p + z2 / 2. / n - q1) / (1. + z2 / n);
	hi = (p + z2 / 2. / n + q1) / (1. + z2 / n);
	if (lo < 0.) lo = 0.;
	if (hi > 1.) hi = 1.;
	rslt[0] = lo;
	rslt[1] = hi;
	return;
}