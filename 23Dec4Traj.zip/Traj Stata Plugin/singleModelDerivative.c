/* 
	derivative - single trajectory model

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

int singleModelDerivative(int n, double *prm, int *nf, double *g, void *qi) {
	
	struct	TRAJSTRUCT *ts = qi;
	int		dLoc, dOrd, group, i, j, jj, k, logPhiPrm, lSig,
			m, os, os3, r, zo;
	double	x, tmp, L1, W;

	if (ts->trace) traceOutput("nllderiv", n, prm);
	lSig = ts->riskOffset[0] - 1;
	if (ts->sigmaByGroup) lSig = ts->riskOffset[0] - ts->nOrders[0] + ts->all0Group[0];
	logPhiPrm = ts->riskOffset[0] - ts->nOrders[0]; /* beta model */
	for (i = 0; i < n; i++) g[i] = 0.;
	if (ts->weightStmt) 
		for (i = 0; i < n * n; i++) 
			ts->xprod[i] = 0.;
	if (ts->nRisk[0] < 1) calcGroupProb(0, ts->riskOffset[0], 0, prm, qi);
	for (i = 0; i < ts->nObs; i++)
	{
		if (ts->obsModelLk[i] <= 0. || ts->skip[i] || ts->oos[i]) continue;
		L1 = ts->obsModelLk[i];
		W = ts->weight[i];
		if (ts->nRisk[0] > 0) calcGroupProb(i, ts->riskOffset[0], ts->risk[0], prm, qi);
		if (ts->weightStmt) 
			for (jj = 0; jj < n; jj++) 
				ts->score[jj] = 0.;
		for (j = 0; j < ts->nIndep[0]; j++)
		{	
			if (ts->missV[0][i][j]) goto L100;
			os = 0;
			if (ts->iorderStmt[0])
			{
				os3 = ts->zipParmOffset[0];
				zo = (int)ts->iorder[0][0];
			}
			for (k = 0; k < ts->nOrders[0]; k++) 
			{
				m = 0;
				switch(ts->modelType[0])
				{
					case m_cnorm: 
						cnormChainRule(n, &m, &i, &k, &j, prm, &os, ts->workrslt, qi);
						break;
					case m_logit: 
						logitChainRule(n, &m, &i, &k, &j, prm, &os, ts->workrslt, qi); 
						break;
					case m_zibeta: 
						betaChainRule(n, &m, &i, &k, &j, prm, &os, ts->workrslt, qi);
						break;
					case m_zip: 
						zipChainRule(n, &m, &i, &k, &j, prm, &os, ts->workrslt, qi);
				}
				for (jj = 0; 
					 jj <= (int)ts->order[0][k] + ((int)ts->order[0][k] + 1 > 0) * ts->nTcovParms[0];
					 jj++)
				{
					x = 1.;
					for (m = 0; m < ts->nIndep[0]; m++) 
					{
						if (j == m) 
						{
							x *= (ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
								  ts->varDropoutLk[0][k][i][m] : 1.) * ts->workrslt[os + jj];
						} 
						else 
						{
							x *= (ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
								  ts->varDropoutLk[0][k][i][m] : 1.) * ts->varTrajLk[0][k][i][m];
						}
					}
					tmp = W * ts->groupProb[0][k] * pow(L1, -1.) * x;
					g[os + jj] -= tmp;
					if (ts->weightStmt) ts->score[os + jj] -= tmp;
				}
				os += (int) ts->order[0][k] + 1 + ((int)ts->order[0][k] + 1 > 0) * ts->nTcovParms[0];		
				if (ts->modelType[0] == m_cnorm && !ts->sigmaByGroup)
				{
					x = 1.;

					for (m = 0; m < ts->nIndep[0]; m++) 
					{
						if (j == m) 
							x *= (ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
								ts->varDropoutLk[0][k][i][m] : 1.) * ts->workrslt[lSig];
						else 
							x *= (ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
								ts->varDropoutLk[0][k][i][m] : 1.) * ts->varTrajLk[0][k][i][m];
					}
					tmp = W * ts->sigma[0][0] * ts->groupProb[0][k] * pow(L1, -1.) * x;
					g[lSig] -= tmp;
					if (ts->weightStmt) ts->score[lSig] -= tmp;
				}				
				if (ts->modelType[0] == m_cnorm && ts->sigmaByGroup)
				{	
					/* ts->all0Group */
					if (!((int)ts->order[0][k] == -1 && k == 0)) 				
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[0]; m++)
							if (j == m) x *= 
								(ts->dropoutStmt[0] &&
								!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
								ts->varDropoutLk[0][k][i][m] : 1.) * 
								ts->workrslt[lSig + k - ts->all0Group[0]];
							else x *= ts->varTrajLk[0][k][i][m] * (ts->dropoutStmt[0] && 
								!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
								ts->varDropoutLk[0][k][i][m] : 1.);
						tmp = W * ts->sigma[0][k] * ts->groupProb[0][k] * pow(L1, -1.) * x;
						g[lSig + k - ts->all0Group[0]] -= tmp;
						if (ts->weightStmt) ts->score[lSig + k - ts->all0Group[0]] -= tmp;
					}
				}				
				if (ts->modelType[0] == m_zibeta)
				{
					x = 1.;
					for (m = 0; m < ts->nIndep[0]; m++)
					{
						if (j == m) x *= ts->workrslt[logPhiPrm + k] *
							(ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
							ts->varDropoutLk[0][k][i][m] : 1.);
						else x *= ts->varTrajLk[0][k][i][m] * 
							(ts->dropoutStmt[0] && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
							ts->varDropoutLk[0][k][i][m] : 1.);
					}
					tmp = W * ts->phi[0][k] * ts->groupProb[0][k] * pow(L1, -1.) * x;
					g[logPhiPrm + k] -= tmp;
					if (ts->weightStmt) ts->score[logPhiPrm + k] -= tmp;
				}
				if (ts->iorderStmt[0])
				{
					if (!ts->commonIorder[0]) zo = (int)ts->iorder[0][k];
					for (jj = 0; jj <= zo; jj++)
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[0]; m++)
						{
							if (j == m) x *=
								(ts->dropoutStmt[0] &&
								!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
								ts->varDropoutLk[0][k][i][m] : 1.) * 
								ts->workrslt[os3 + jj];
							else x *= (ts->dropoutStmt[0] &&
								!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
								ts->varDropoutLk[0][k][i][m] : 1.) * 
								ts->varTrajLk[0][k][i][m];
						}
						tmp = W * ts->groupProb[0][k] * pow(L1, -1.) * x;							
						g[os3 + jj] -= tmp;							
						if (ts->weightStmt) ts->score[os3 + jj] -= tmp;
					}
					if (!ts->commonIorder[0]) os3 += (int) ts->iorder[0][k] + 1;
				}				
			}
L100:;		
			if (ts->dropoutStmt[0] && j > ts->dataStartTime[0][i]) 
			{
				dOrd = (int)ts->dOrd[0][0];	
				dLoc = ts->dLoc[0];
				if (ts->nDcov[0] > 0)	
				{
					for (jj = 0; jj < ts->nDcov[0] / ts->nIndep[0]; jj++) 
					{
						if (IS_MISSING(ts->dcov[0][i][j + jj * ts->nIndep[0] - 1])) 
						{
							goto L200;
						}
					}
				}
				if (dOrd > 0) 
				{
					if (j >= ts->dataStartTime[0][i] + dOrd &&
						j <= ts->dropoutTime[0][i])
					{
						for (jj = 1; jj <= dOrd; jj++) 
						{
							if (IS_MISSING(ts->dep[0][i][j - jj])) goto L200;
						}
					}
				}
				for (k = 0; k < ts->nOrders[0]; k++) 
				{
					if (ts->nDropout[0] > 1) dOrd = (int)ts->dOrd[0][k];
					if (dOrd != -1 && j >= ts->dataStartTime[0][i] + dOrd &&
						j <= ts->dropoutTime[0][i]) 
					{
						dropoutChainRule(n, &i, &k, &j, prm, &dOrd, &dLoc, ts->workrslt, qi);
						for (jj = 0; jj <= dOrd + ts->nDcovPrm[0]; jj++) 
						{
							x = 1.;
							for (m = 0; m < ts->nIndep[0]; m++) 
							{
								if (j == m) 
								{
									x *= ts->varTrajLk[0][k][i][m] *
									ts->workrslt[dLoc + jj];
								} 
								else 
								{
									x *= ts->varTrajLk[0][k][i][m] *
									(!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
									ts->varDropoutLk[0][k][i][m] : 1.);
								}
							}
							tmp = W * ts->groupProb[0][k] * pow(L1, -1.) * x;							
							g[dLoc + jj] -= tmp;							
							if (ts->weightStmt) ts->score[dLoc + jj] -= tmp;
						}
					}
					if (ts->nDropout[0] > 1)
						dLoc += (int)ts->dOrd[0][k] + 1 + ts->nDcovPrm[0];
				}
L200:;		
			}
		}
		group = 1;
		for (k = 0; k < ts->nOrders[0];  k++)
		{
			if (k != (int)ts->referenceGroup[0]) 
			{
				for (jj = 0; jj < ts->nOrders[0]; jj++)
				{
					if (ts->obsTrajLk[0][jj][i] > 0.)
					{
						tmp = W * ts->groupProb[0][k] * ts->obsTrajLk[0][jj][i] * pow(L1, -1.);
						g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] += tmp;
						if (ts->weightStmt) 
							ts->score[ts->riskOffset[0] + 
							(group - 1) * (ts->nRisk[0] + 1)] += tmp;
						for (r = 1; r <= ts->nRisk[0]; r++)
						{
							tmp = W * ts->risk[0][i][r - 1] * ts->groupProb[0][k] *
								ts->obsTrajLk[0][jj][i] * pow(L1, -1.);
							g[ts->riskOffset[0] + (group - 1) *
								(ts->nRisk[0] + 1) + r] += tmp;
							if (ts->weightStmt) ts->score[ts->riskOffset[0] +
								(group - 1) * (ts->nRisk[0] + 1) + r] += tmp;
						}			
					}
				}
				tmp = W * ts->obsTrajLk[0][k][i] * pow(L1, -1.);
				g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] -= tmp;
				if (ts->weightStmt) 
					ts->score[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] -= tmp;
				for (r = 1; r <= ts->nRisk[0]; r++)
				{
					tmp = W * ts->risk[0][i][r - 1] * ts->obsTrajLk[0][k][i] * pow(L1, -1.);
					g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1) + r] -= tmp;
					if (ts->weightStmt) 
						ts->score[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1) + r] -= tmp;
				}
				group++;
			}
		}
		if (ts->weightStmt) 
			for (k = 0; k < n; k++) 
				for (r = 0; r < n; r++) 
					ts->xprod[k * n + r] += ts->score[k] * ts->score[r];
	}
	if (ts->trace) traceOutput("Gradient", n, g);
	return 0;
}