/* Tues, Feb 17 2015 
 * Stephen Becker, stephen.becker@colorado.edu
 * */

#ifndef lbfgsb_h
#define lbfgsb_h


#define TRUE_ (1)
#define FALSE_ (0)

#include <stdio.h>

/* Modified L-BFGS-B to use ints instead
 * of strings, for testing the "task". Way
 * simpler this way. For ease-of-use, use
 * these aliases. For each class of task,
 * make sure numbering is contiguous
 * so that I have easy tests for class
 * membership */

#define START 1 
#define NEW_X 2
#define ABNORMAL 3 /* message: ABNORMAL_TERMINATION_IN_LNSRCH. */
#define RESTART 4 /* message: RESTART_FROM_LNSRCH. */

#define FG      10
#define FG_END  15
#define IS_FG(x) (((x)>=FG) ?  (((x)<=FG_END) ? 1 : 0) : 0)
#define FG_LN   11
#define FG_LNSRCH FG_LN
#define FG_ST   12
#define FG_START FG_ST

#define CONVERGENCE 20
#define CONVERGENCE_END  25
#define IS_CONVERGED(x) (((x)>=CONVERGENCE) ?  (((x)<=CONVERGENCE_END) ? 1 : 0) : 0)
#define CONV_GRAD   21 /* message: CONVERGENCE: NORM_OF_PROJECTED_GRADIENT_<=_PGTOL. */
#define CONV_F      22 /* message: CONVERGENCE: REL_REDUCTION_OF_F_<=_FACTR*EPSMCH. */

#define STOP  30  
#define STOP_END 40
#define IS_STOP(x) (((x)>=STOP) ?  (((x)<=STOP_END) ? 1 : 0) : 0)
#define STOP_CPU  31 /* message: STOP: CPU EXCEEDING THE TIME LIMIT. */
#define STOP_ITER 32 /* message: STOP: TOTAL NO. of f AND g EVALUATIONS EXCEEDS LIM.  */
#define STOP_GRAD 33 /* message: STOP: THE PROJECTED GRADIENT IS SUFFICIENTLY SMALL. */

#define WARNING 100
#define WARNING_END 110
#define IS_WARNING(x) (((x)>=WARNING) ?  (((x)<=WARNING_END) ? 1 : 0) : 0)
#define WARNING_ROUND 101  /* WARNING: ROUNDING ERRORS PREVENT PROGRESS */
#define WARNING_XTOL  102  /* WARNING: XTOL TEST SATISIED */
#define WARNING_STPMAX 103 /* WARNING: STP = STPMAX */
#define WARNING_STPMIN 104 /* WARNING: STP = STPMIN */

#define ERROR 200
#define ERROR_END 240
#define IS_ERROR(x) (((x)>=ERROR) ?  (((x)<=ERROR_END) ? 1 : 0) : 0)
/* More specific conditions below */
#define ERROR_SMALLSTP 201 /* message: ERROR: STP .LT. STPMIN  */
#define ERROR_LARGESTP 202 /* message: ERROR: STP .GT. STPMAX  */
#define ERROR_INITIAL  203 /* message: ERROR: INITIAL G .GE. ZERO */
#define ERROR_FTOL     204 /* message: ERROR: FTOL .LT. ZERO   */
#define ERROR_GTOL     205 /* message: ERROR: GTOL .LT. ZERO   */
#define ERROR_XTOL     206 /* message: ERROR: XTOL .LT. ZERO   */
#define ERROR_STP0     207 /* message: ERROR: STPMIN .LT. ZERO */
#define ERROR_STP1     208 /* message: ERROR: STPMAX .LT. STPMIN */
#define ERROR_N0       209 /* ERROR: N .LE. 0 */
#define ERROR_M0       210 /* ERROR: M .LE. 0 */
#define ERROR_FACTR    211 /* ERROR: FACTR .LT. 0 */
#define ERROR_NBD      212 /* ERROR: INVALID NBD */
#define ERROR_FEAS     213 /* ERROR: NO FEASIBLE SOLUTION */


/* and "word" was a char that was one fo these: */
#define WORD_DEFAULT 0 /* aka "---".  */
#define WORD_CON 1 /*  the subspace minimization converged. */
#define WORD_BND 2 /* the subspace minimization stopped at a bound. */
#define WORD_TNT 3 /*  the truncated Newton step has been used. */


/* If we are linking with fortran code,
 * then use gfortran to compile, not gcc,
 * and it will expect function names to have
 * underscores.
 * With gcc, if we execute the following,
 * it will complain _daxpy_ is undefined ... */
#if defined(_WIN32) || defined(__hpux) || !defined(__GFORTRAN__)
#define FORTRAN_WRAPPER(x) x
#else
#define FORTRAN_WRAPPER(x) x ## _
/* if we're not WIN32 or HPUX, then if we are linking
 * with gfortran (instead of gcc or g++), we need to mangle
 * names appropriately */
#endif


/* First decision: use the included BLAS code
 * (un-optimized version taken from Netlib;
 * this is the "reference" implementation, or
 * "Ref" for short; this is your best option
 * since these routines should not be a bottleneck
 * in your computation);
 * or, use your own BLAS library, such 
 * as Intel MKL, ATLAS, GotoBLAS, etc.
 * (For example, you could use libmwblas
 * or libmwblas_compat32, which are included
 * with Mathworks and usually based on Intel MKL).
 *
 * The reason not to use your own BLAS library
 * is that (1) it may be faster but it won't be
 * a bottleneck, and (2) some BLAS libraries
 * use 32-bit/4byte ints, and others use 64-bit/
 * 8byte ints, and you pass by reference,
 * so if you get it wrong, you crash.
 * In Matlab, useing -lmwblascompat32
 *   uses names like ddot32
 *
 * In short, use the Ref version unless you feel
 * lucky.
 * */
#if !defined(_USE_OPTIMIZED_BLAS)
/* make alias to our reference implementation */
#define daxpy FORTRAN_WRAPPER(daxpyRef)
#define dcopy FORTRAN_WRAPPER(dcopyRef)
#define ddot  FORTRAN_WRAPPER(ddotRef)
#define dscal FORTRAN_WRAPPER(dscalRef)
#else
#if defined(_USE_32_BIT_BLAS)
#define daxpy FORTRAN_WRAPPER(daxpy32)
#define dcopy FORTRAN_WRAPPER(dcopy32)
#define ddot  FORTRAN_WRAPPER(ddot32)
#define dscal FORTRAN_WRAPPER(dscal32)
#else
#define daxpy FORTRAN_WRAPPER(daxpy)
#define dcopy FORTRAN_WRAPPER(dcopy)
#define ddot  FORTRAN_WRAPPER(ddot)
#define dscal FORTRAN_WRAPPER(dscal)
#endif
#endif

typedef FILE* fileType; 

/* Some linesearch parameters. The default
 * values are the same as the FORTRAN code,
 * but you could conceivably change these
 * at compile time; they are used in
 * dcsrch()  */
#ifndef FTOL
#define FTOL .001
#endif
#ifndef GTOL
#define GTOL .9
#endif
#ifndef XTOL
#define XTOL .1
#endif
#ifndef STEPMIN
#define STEPMIN 0.
#endif


/* If we want machine precision in a nice fashion, do this: */
#include <float.h>
#ifndef DBL_EPSILON
#define DBL_EPSILON 2.2e-16
#endif

#ifdef __cplusplus
    extern "C" {
#endif


extern double ddot(int *, double *, int *, double *, 
        int *);

extern  int daxpy(int *, double *, double *, 
        int *, double *, int *);

extern  int dscal(int *, double *, double *, 
        int *);

extern  int dcopy(int *, double *, int *, 
	    double *, int *);

#define setulb FORTRAN_WRAPPER(setulb)
extern int setulb(int *n, int *m, double *x, 
	double *l, double *u, int *nbd, double *f, double 
	*g, double *factr, double *pgtol, double *wa, int *
	iwa, int *task, int *iprint, int *csave, int *lsave, 
	int *isave, double *dsave); /* int task_len, int csave_len); */

#define mainlb FORTRAN_WRAPPER(mainlb)
extern int mainlb(int *n, int *m, double *x, 
        double *l, double *u, int *nbd, double *f, double 
        *g, double *factr, double *pgtol, double *ws, double *
        wy, double *sy, double *ss, double *wt, double *wn, 
        double *snd, double *z__, double *r__, double *d__, 
        double *t, double *xp, double *wa, int *index, 
        int *iwhere, int *indx2, int *task, int *iprint, 
        int *csave, int *lsave, int *isave, double *dsave);


#define freev FORTRAN_WRAPPER(freev) 
extern  int freev(int *, int *, int *, 
        int *, int *, int *, int *, int *, int *, 
        int *, int *, int *);

#define timer FORTRAN_WRAPPER(timer) 
extern  int timer(double *);
#define formk FORTRAN_WRAPPER(formk) 
extern int formk(int *, 
        int *, int *, int *, int *, int *, int *, 
        int *, double *, double *, int *, double *, 
        double *, double *, double *, int *, int *, 
        int *);
#define formt FORTRAN_WRAPPER(formt) 
extern  int formt(int *, double *, double *, 
        double *, int *, double *, int *);
#define subsm FORTRAN_WRAPPER(subsm) 
extern int subsm(int *, int *, int *, int *, double *, double *, 
        int *, double *, double *, double *, double *,
        double *, double *, double *, double *, int *
        , int *, int *, double *, double *, int *, 
        int *);
#define prn1lb FORTRAN_WRAPPER(prn1lb) 
extern int prn1lb(int *n, int *m, double *l, 
        double *u, double *x, int *iprint, fileType itfile, double *epsmch); 

#define prn2lb FORTRAN_WRAPPER(prn2lb) 
extern int prn2lb(int *n, double *x, double *f, double *g, 
        int *iprint, fileType itfile, int *iter, int *nfgv, int *nact, double 
        * sbgnrm, int *nseg, int * word, int * iword, int * iback, double * stp, 
        double * xstep, int);

#define prn3lb FORTRAN_WRAPPER(prn3lb) 
extern int prn3lb(int *n, double *x, double *f, int *
	task, int *iprint, int *info, fileType itfile, int *iter, 
	int *nfgv, int *nintol, int *nskip, int *nact, 
	double *sbgnrm, double *time, int *nseg, int *word, 
	int *iback, double *stp, double *xstep, int *k, 
	double *cachyt, double *sbtime, double *lnscht, int 
	task_len, int word_len);

#define errclb FORTRAN_WRAPPER(errclb) 
extern int errclb(int *n, int *m, double *factr, 
        double *l, double *u, int *nbd, int *task, int *info,
        int *k, int task_len);

#define active FORTRAN_WRAPPER(active) 
extern  int active(int *, double *, double *,
        int *, double *, int *, int *, int *, 
        int *, int *);
#define cauchy FORTRAN_WRAPPER(cauchy) 
extern int cauchy(int *, double *, 
        double *, double *, int *, double *, int *, 
        int *, double *, double *, double *, int *, 
        double *, double *, double *, double *, 
        double *, int *, int *, double *, double *, 
        double *, double *, int *, int *, double *, 
        int *, double *);
#define cmprlb FORTRAN_WRAPPER(cmprlb) 
extern  int cmprlb(int *, int *, double *, 
        double *, double *, double *, double *, 
        double *, double *, double *, double *, int *,
        double *, int *, int *, int *, int *, 
        int *);
#define matupd FORTRAN_WRAPPER(matupd) 
extern  int matupd(int *, int *, double *, 
        double *, double *, double *, double *, 
        double *, int *, int *, int *, int *, 
        double *, double *, double *, double *, 
        double *);
#define lnsrlb FORTRAN_WRAPPER(lnsrlb) 
extern int lnsrlb(int *n, double *l, double *u, 
        int *nbd, double *x, double *f, double *fold, 
        double *gd, double *gdold, double *g, double *d__, 
        double *r__, double *t, double *z__, double *stp, 
        double *dnorm, double *dtd, double *xstep, double *
        stpmx, int *iter, int *ifun, int *iback, int *nfgv, 
        int *info, int *task, int *boxed, int *cnstnd, int *
        csave, int *isave, double *dsave); 

#define projgr FORTRAN_WRAPPER(projgr) 
extern  int projgr(int *, double *, double *,
        int *, double *, double *, double *);

/* in linesearch.c */
#define dcsrch FORTRAN_WRAPPER(dcsrch) 
extern int dcsrch(double *f, double *g, double *stp, 
        double *ftol, double *gtol, double *xtol, double *
        stpmin, double *stpmax, int *task, int *isave, double *
        dsave);
#define dcstep FORTRAN_WRAPPER(dcstep) 
extern  int dcstep(double *, double *,
        double *, double *, double *, double *,
        double *, double *, double *, int *, double *,
        double *);

#define dpofa FORTRAN_WRAPPER(dpofa)
extern int dpofa(double *, int *, int *, 
		int *);
#define dtrsl FORTRAN_WRAPPER(dtrsl)
extern int  dtrsl(double *, int *, int *, 
		double *, int *, int *);

#ifdef __cplusplus
    }   /* extern "C" */
#endif

#endif 