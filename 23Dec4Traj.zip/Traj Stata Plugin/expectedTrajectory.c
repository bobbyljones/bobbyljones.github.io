/* 	
	Expected trajectory

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"

void expectedTraj(int *wv, double *x, double *expos, double *r, double *vr, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	double	dh, dl, hi, lmb, low, *tcovPtr, rho, sigma = 1., xb;
	int		gp, j, jj, r2, os, zos, zo, rp_os;

	zos = ts->zipParmOffset[0];
	rp_os = ts->riskOffset[0];
	if (ts->modelType[ts->mdl] == m_cnorm) 
	{
		os = ts->ar1 ? 
				2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[ts->mdl] - 1) :
				1 + ts->sigmaByGroup * (ts->nOrders[ts->mdl] - 1 - ts->all0Group[ts->mdl]);	
		os = ts->riskOffset[ts->mdl] - os;
		if (ts->sigmaByGroup) 
		{
			for (gp = 0; gp < ts->nOrders[ts->mdl]; gp++) 
			{
				ts->sigma[0][gp] = exp(ts->start[os]);
				os++;
			}
		} 
		else 
			for (gp = 0; gp < ts->nOrders[ts->mdl]; gp++) ts->sigma[0][gp] = exp(ts->start[os]);

		if (ts->ar1)
		{
			if (ts->rhoByGroup)
			{
				for (gp = 0; gp < ts->nOrders[ts->mdl]; gp++)
				{
					ts->rho[0][gp] = invlogit(ts->start[os]);
					os++;
				}
			} 
			else 
				for (gp = 0; gp < ts->nOrders[ts->mdl]; gp++)ts->rho[0][gp] = invlogit(ts->start[os]);
		}
	}
	if (ts->modelType[ts->mdl] == m_zibeta) 
	{
		os = ts->nOrders[ts->mdl];		
		os = ts->riskOffset[ts->mdl] - os;
		for (gp = 0; gp < ts->nOrders[ts->mdl]; gp++) 
		{
			ts->phi[0][gp] = exp(ts->start[os]);
			os++;
		}
	}
	os = 0;
	if (ts->multModel) 
	{
		for (j = 0; j < ts->mdl; j++) os += ts->nModelParm[j];
		zos = ts->riskOffset[ts->mdl] - ts->nZipParms[ts->mdl];
	}
	if (ts->mdl == 1 && ts->likelihoodType == JOINT) 
	{
		rp_os = ts->riskOffset[1];
		zos = ts->zipParmOffset[1];
		os = ts->jointOffset;
	}
	for (j = 0; j < ts->nOrders[ts->mdl]; j++) 
	{
		sigma = ts->sigma[0][j];
		for (jj = 0; jj < ts->totalParms; jj++) ts->workrslt[jj] = 0.;
		xb = 0.;
		r[j] = vr[j] = 0.;
		if (!IS_MISSING(*x)) 
		{
			tcovPtr = 0;
			if (ts->nTcov[ts->mdl] > 0) tcovPtr = ts->plotTcov[ts->mdl];
			xb = linPred(ts->start, x, &os, &j, &ts->nIndep[ts->mdl], &ts->order[ts->mdl][j],
						 &ts->nTcovParms[ts->mdl], tcovPtr);
		}		 
		switch (ts->modelType[ts->mdl]) 
		{
		case m_cnorm: 
			low = (ts->varMin[ts->mdl] - xb) / sigma;
			hi = (ts->varMax[ts->mdl] - xb) / sigma;
			dh = exp(-.5 * hi * hi) * RSQRT2PI;
			dl = exp(-.5 * low * low) * RSQRT2PI;
			r[j] = ts->varMin[ts->mdl] * mvnphi_(&low) + ts->varMax[ts->mdl] * (1 - mvnphi_(&hi));
			r[j] += xb * (mvnphi_(&hi) - mvnphi_(&low)) + sigma * (dl - dh);
			ts->workrslt[os] = ts->varMax[ts->mdl] * dh / sigma - ts->varMin[ts->mdl] * dl / sigma + 
							   dh * hi - dl * low + mvnphi_(&hi) - mvnphi_(&low) + (dl - dh) * xb / sigma;
			break;
		case m_logit:
			r[j] = invlogit(xb);
			ts->workrslt[os] = r[j] - r[j] * r[j];
			break;
		case m_zibeta:
			r[j] = invlogit(xb);
			ts->workrslt[os] = r[j] * (1. - r[j]) / (1. + ts->phi[0][j]);	
			break;
		case m_zip:
			rho = 0.;
			lmb = exp(xb);
			if (ts->nExpos[ts->mdl] > 0) lmb *= *expos;
			if (ts->iorderStmt[ts->mdl]) 
			{
				zo = (int)ts->iorder[ts->mdl][0];
				if (!ts->commonIorder[ts->mdl]) zo = (int)ts->iorder[ts->mdl][j];
				xb = 0.;
				for (jj = 0; jj <= zo; jj++) xb += ts->start[zos + jj] * pow(*x, jj);
				rho = zo == -1 ? 0. : invlogit(xb);
				if (zo > -1) ts->workrslt[zos] = rho * rho - rho;
				for (jj = 1; jj <= zo; jj++) ts->workrslt[zos + jj] = ts->workrslt[zos] * pow(*x, jj);
				if (!ts->commonIorder[ts->mdl]) zos += (int)ts->iorder[ts->mdl][j] + 1;
			}
			r[j] = (1. - rho) * lmb;
			ts->workrslt[os] = r[j];
			break;
		}
		for (jj = 1; jj <= (int)ts->order[ts->mdl][j]; jj++) 
			ts->workrslt[os + jj] = ts->workrslt[os] * pow(*x, jj);
		if (ts->nTcov[ts->mdl] > 0) 
		{
			for (jj = 0; jj < ts->nTcovParms[ts->mdl]; jj++) 
			{
				if (!IS_MISSING(ts->plotTcov[ts->mdl][*wv + jj * ts->nIndep[ts->mdl]])) 
				{
					ts->workrslt[os + 1 + (int)ts->order[ts->mdl][j] + jj] = 
						ts->workrslt[os] * ts->plotTcov[ts->mdl][*wv + jj * ts->nIndep[ts->mdl]];
				}
			}
		}
		vr[j] = 0.;
		for (jj = 0; jj < ts->totalParms; jj++) 
		{
			ts->worknp[jj] = 0.;
			for (r2 = 0; r2 < ts->totalParms; r2++) 
				ts->worknp[jj] += ts->hessian[r2 * ts->totalParms + jj] * ts->workrslt[r2];
			vr[j] += ts->worknp[jj] * ts->workrslt[jj];
		} 

		if ((int)ts->order[ts->mdl][j] == -1 && j == 0) r[j] = vr[j] = 0.;
		os += (int)ts->order[ts->mdl][j] + 1 + 
			  ((int)ts->order[ts->mdl][j] + 1 > 0) * ts->nTcovParms[ts->mdl];
	}	
}
