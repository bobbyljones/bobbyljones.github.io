/* 
	Transform parms to print and return in e(b) 
	e.g. log(sigma), log(phi), theta to percentages

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/
#include	 "ctraj.h"

void parmTransform(void *qinfo) {

	struct	TRAJSTRUCT *ts = qinfo;
	int		i, j, m, os, os2;

	for (i = 0; i < ts->totalParms; i++) ts->outestStart[i] = ts->start[i];
	switch (ts->likelihoodType) 
	{
		case MULTI: 
			for (m = 0; m < ts->nModels; m++)
			{
				if (ts->modelType[m] == m_cnorm) 
				{
					os = ts->riskOffset[m] - 1;
					if (ts->sigmaByGroup) os -= (ts->nOrders[m] - ts->all0Group[m] - 1);
					if (!ts->sigmaByGroup) ts->outestStart[os] = exp(ts->outestStart[os]);
					else
						for (j = 0; j < ts->nOrders[m] - ts->all0Group[m]; j++)
							ts->outestStart[os + j] = exp(ts->outestStart[os + j]);
				}
				if (ts->modelType[m] == m_zibeta)
					for (j = 0; j < ts->nOrders[m]; j++) 
						ts->outestStart[ts->riskOffset[m] - ts->nOrders[m] + j] = 
							exp(ts->outestStart[ts->riskOffset[m] - ts->nOrders[m] + j]);
			}
			break;		
		case JOINT: 	
			if (ts->modelType[1] == m_cnorm)
				ts->outestStart[ts->riskOffset[1] - 1] = exp(ts->outestStart[ts->riskOffset[1] - 1]);
		case SINGLE: 
			if (ts->modelType[0] == m_cnorm)
			{
				os2 = ts->ar1 ? 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[0] - 1) :
							    1 + ts->sigmaByGroup * (ts->nOrders[0] - 1 - ts->all0Group[0]);
				os = (ts->rorderStmt[0]) ? ts->rorderOffset : ts->riskOffset[0];
				os -= os2;
				if (ts->sigmaByGroup) 
				{
					for (j = 0; j < ts->nOrders[0] - ts->all0Group[0]; j++)
					{
						ts->outestStart[os] = exp(ts->outestStart[os]);
						os++;
					}
				} 
				else 
				{
					ts->outestStart[os] = exp(ts->outestStart[os]);
					os++;
				}
				if (ts->ar1)
				{
					if (ts->rhoByGroup)
					{
						for (j = 0; j < ts->nOrders[0]; j++)
						{
							ts->outestStart[os] = invlogit(ts->outestStart[os]);
							os++;
						}
					} 
					else 
					{
						ts->outestStart[os] = invlogit(ts->outestStart[os]);
						os++;
					}
				}
				if (ts->rorderStmt[0])
				{
					ts->outestStart[os] = exp(ts->outestStart[os]);
					os++;
					for (i = 0; i < (int)ts->rorder[0][0] + 1;  i++) 
						ts->outestStart[os + i] = exp(ts->outestStart[os + i]);
					os += (int)ts->rorder[0][0] + 1;
					if (!ts->commonRorder[0])
					{
						for (j = 1; j < ts->nOrders[0]; j++)
						{
							for (i = 0; i < (int)ts->rorder[0][j] + 1; i++) 
								ts->outestStart[os + i] = exp(ts->outestStart[os + i]);
							os += (int)ts->rorder[0][j] + 1;
						}
					}
				}
			}
			if (ts->modelType[0] == m_zibeta)
				for (j = 0; j < ts->nOrders[0]; j++) 
					ts->outestStart[ts->riskOffset[0] - ts->nOrders[0] + j] = 
						exp(ts->outestStart[ts->riskOffset[0] - ts->nOrders[0] + j]);
			if (ts->outcStmt[0] && ts->outcModelType[0] == m_cnorm)
			{
				os = ts->outcOffset + ts->nOutcPrm[0] - 1;
				ts->outestStart[os] = exp(ts->outestStart[os]);
			}	
	}
}