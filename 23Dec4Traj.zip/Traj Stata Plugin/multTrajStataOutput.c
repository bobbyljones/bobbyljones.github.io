/* 
	Stata output processing for multi-trajectory models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 	
*/
#include	 "ctraj.h"

int multTrajStataOutput(void *qinfo)
{
	struct	TRAJSTRUCT *ts = qinfo;
	char	hdr[100], l_str[33], parmLabel[13];
	int		i, j, jj, m, parmListPtr, r, r2;
	double	d1, temp, temp2;

	parmListPtr = 0;
	sprintf(hdr, "\t\t\tMaximum Likelihood Estimates\n");
	SF_display(hdr);
	for (m = 0; m < ts->nModels; m++)
	{
		sprintf(hdr, " \n");  
		SF_display(hdr);
		if (ts->modelType[m] == m_zip) 
			sprintf(hdr, "\t\t\tModel: Zero Inflated Poisson (zip)\n");	
		else if (ts->modelType[m] == m_cnorm)
			sprintf(hdr, "\t\t\tModel: Censored Normal (cnorm)\n");
		else if (ts->modelType[m] == m_logit)
			sprintf(hdr,  "\t\t\tModel: Logistic (logit)\n");
		else if (ts->modelType[m] == m_zibeta)
			sprintf(hdr,  "\t\t\tModel: Beta (beta)\n");
		else
		{/* no match */}
		SF_display(hdr);
		if (ts->no_var)
		{
			sprintf(hdr, "Standard error calculations omitted by NOVAR option.\n");
			SF_display(hdr);
		}
		else if (ts->iflt != 0)
		{
			sprintf(hdr, "Unable to calculate standard errors.  Check model.\n");
			SF_display(hdr);
		}
		sprintf(hdr, "\n\t\t\t       Standard       T for H0:\n");  
		SF_display(hdr);
		sprintf(hdr, " Group   Parameter        Estimate        Error     Parameter=0   Prob > |T|\n");
		SF_display(hdr);
		sprintf(hdr, " \n");  
		SF_display(hdr);
		for (i = 0; i < ts->nOrders[m]; i++)
		{
			if (ts->order[m][i] == -1)
				sprintf(hdr, "\n %d %s %s %s %s %s", i + 1, "N/A", ".", ".", ".", ".");
			for (j = 0; j <= (int)ts->order[m][i]; j++)
			{	
				switch (j)
				{
				case 0:
					writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[parmListPtr],
								  ts->stdErr[parmListPtr], "Intercept   ");
					sprintf(l_str, "intercG%-dM%-d", i + 1, m + 1);
					break;
				case 1:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], 
								  ts->stdErr[parmListPtr], "Linear      ");
					sprintf(l_str, "linearG%-dM%-d", i + 1, m + 1);
					break;
				case 2:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], 
								  ts->stdErr[parmListPtr], "Quadratic   ");
					sprintf(l_str, "quadraG%-dM%-d", i + 1, m + 1);
					break;
				case 3:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], 
								  ts->stdErr[parmListPtr], "Cubic       ");
					sprintf(l_str, "cubicG%-dM%-d", i + 1, m + 1);
					break;
				case 4:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], 
						ts->stdErr[parmListPtr], "Quartic     ");

					sprintf(l_str, "quartiG%-dM%-d", i + 1, m + 1);
					break;
				case 5:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], 
						ts->stdErr[parmListPtr], "Quintic     ");
					sprintf(l_str, "quintiG%-dM%-d", i + 1, m + 1);					
					break;
				}							
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++;
			}
			
			for (j = 0; j < ((int)ts->order[m][i] + 1 > 0) * ts->nTcovParms[m]; j++)
			{
				sprintf(parmLabel, ts->tcovNames[m][j * ts->nIndep[m]]);
				writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], ts->stdErr[parmListPtr], parmLabel);
				sprintf(l_str, "%sG%-dM%-d", ts->tcovNames[m][j * ts->nIndep[m]], i + 1, m + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++;
			}
			sprintf(hdr, " \n");  SF_display(hdr);
		}
		if (ts->dropoutStmt[0] && m == 0)
		{	
			for (i = 0; i < ts->nDropout[0]; i++)
			{
				if (ts->nDropout[0] == 1)
				{
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
						ts->stdErr[parmListPtr], "Drop0       ");
					sprintf(l_str, "drop0");
					parmListPtr++;
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");	
				}
				else
				{
					if (ts->dOrd[0][i] != -1.)
					{
						writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[parmListPtr],
							ts->stdErr[parmListPtr], "Drop0       ");
						sprintf(l_str, "drop0G%-d", i + 1);
						strcat(ts->outestVarName, l_str);
						strcat(ts->outestVarName, " ");	
						parmListPtr++;
					}
				}
				for (j = 1; j <= (int)ts->dOrd[0][i]; j++)
				{
					sprintf(parmLabel, "Drop%d       ", j);
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr], ts->stdErr[parmListPtr],
						parmLabel);
					sprintf(l_str, "drop%dG%d", j, i + 1);
					parmListPtr++;
					strcat(ts->outestVarName, l_str);	
					strcat(ts->outestVarName, " ");	
				}

				for (r = 0; r < ts->nDcovPrm[0]; r++)
				{
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
						ts->stdErr[parmListPtr], ts->dcovNames[0][r * ts->nIndep[0]]);
					sprintf(l_str, "%sG%-d", ts->dcovNames[0][r * ts->nIndep[0]], i + 1);
					strcat(ts->outestVarName, l_str);	
					strcat(ts->outestVarName, " ");	
					parmListPtr++;
				}
				sprintf(hdr, " \n");  
				SF_display(hdr);
			}
		}
		if (ts->modelType[m] == m_zibeta)
		{
			for (i = 0; i < ts->nMultGroups; i++)
			{	
				writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[parmListPtr]), 
							ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "Phi         ");
				for (r = 0; r < ts->totalParms; r++)
				{
					ts->hessian[r * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
					ts->hessian[parmListPtr * ts->totalParms + r] *= exp(ts->start[parmListPtr]);
				}
				sprintf(l_str, "phiG%-dM%-d", i + 1, m + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++; 
			}
		}		
		if (ts->modelType[m] == m_cnorm)
		{
			if (ts->sigmaByGroup)
			{
				for (i = 0; i < ts->nMultGroups; i++)
				{
					if (!((int)ts->order[m][i] == -1 && i == 0)) /* ts->all0Group */
					{
						writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[parmListPtr]), 
								ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "Sigma       ");
						for (r = 0; r < ts->totalParms; r++)
						{
							ts->hessian[r * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
							ts->hessian[parmListPtr * ts->totalParms + r] *= exp(ts->start[parmListPtr]);
						}
						sprintf(l_str, "sigmaG%-dM%-d", i + 1, m + 1);
						strcat(ts->outestVarName, l_str) ;	
						strcat(ts->outestVarName, " ") ;	
						parmListPtr++; 
					}
				}
			}
			else
			{
				writeParmLine(0, ts->iflt, ts->nData, exp(ts->start[parmListPtr]), 
					ts->stdErr[parmListPtr] * exp(ts->start[parmListPtr]), "Sigma       ");
				for (i = 0; i < ts->totalParms; i++)
				{
					ts->hessian[i * ts->totalParms + parmListPtr] *= exp(ts->start[parmListPtr]);
					ts->hessian[parmListPtr * ts->totalParms + i] *= exp(ts->start[parmListPtr]);
				}
				sprintf(l_str, "sigmaM%-d", m + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++; 
			}
		}
		if (ts->iorderStmt[m])
		{
			for (i = 0; i < MAX(1, ts->nIorder[m]); i++)
			{
				if (ts->commonIorder[m])
				{
					if (ts->iorder[m][i] != -1.)
					{
						writeParmLine(0, ts->iflt, ts->nData, 
							ts->start[parmListPtr], ts->stdErr[parmListPtr], "Alpha0      ");
						sprintf(l_str, "alpha0M%-d", m + 1);
						parmListPtr++;
						strcat(ts->outestVarName, l_str) ;	
						strcat(ts->outestVarName, " ") ;	
					}
				}
				else
				{
					if (ts->iorder[m][i] != -1.)
					{						
						writeParmLine(i + 1, ts->iflt, ts->nData,
							ts->start[parmListPtr], ts->stdErr[parmListPtr], "Alpha0      ");
						sprintf(l_str, "alpha0G%-dM%-d", i + 1, m + 1);
						parmListPtr++;
						strcat(ts->outestVarName, l_str) ;	
						strcat(ts->outestVarName, " ") ;	
					}
				}
				for (j = 1; j <= (int)ts->iorder[m][i]; j++)
				{
					sprintf(parmLabel, "Alpha%-d     ", j);
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
						ts->stdErr[parmListPtr], parmLabel);
					sprintf(l_str, "alpha%dM%-d", j, m + 1);
					if (!ts->commonIorder[0]) sprintf(l_str, "alpha%dG%-dM%-d", j, i + 1, m + 1);
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
					parmListPtr++;
				}
				if (ts->iorder[m][i] != -1.)
				{
					sprintf(hdr, " \n");
					SF_display(hdr);
				}
			}
		}
	}
	for (i = 0; i < ts->nMultGroups; i++) ts->group_percent[i] = MACMISSING;
	sprintf(hdr, " \n");  
	SF_display(hdr);	
	SF_display("  Group membership\n");  
	sprintf(hdr, " \n");  
	SF_display(hdr);
 	if (ts->nMultRisk != 0.)
	{
		for (i = 0; i < ts->nMultGroups; i++)
		{
			if (i == (int)ts->referenceGroup[0]) 
			{
				if (!ts->noprint)
				{			
					sprintf(hdr, " \n");  SF_display(hdr);	
					sprintf(hdr, " %d       Constant         (0.00000)           .               .            . \n", 
						   (int)ts->referenceGroup[0] + 1); SF_display(hdr);				
				}
			}
			else
			{
				sprintf(hdr, " \n");  SF_display(hdr);	
				writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[parmListPtr],
							  ts->stdErr[parmListPtr], "Constant    ");
				sprintf(l_str, "constG%d", i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++;
				for (r = 0; r < ts->nMultRisk; r++)
				{
					sprintf(parmLabel, ts->multRiskNames[r]);
					writeParmLine(0, ts->iflt, ts->nData, ts->start[parmListPtr],
								  ts->stdErr[parmListPtr], parmLabel);
					sprintf(l_str, "%sG%-d", ts->multRiskNames[r], i + 1);
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
					parmListPtr++;
				}
			}
		}
		sprintf(hdr, " \n");  
		SF_display(hdr);
	}
	else
	{								
		d1 = 1.;
		for (i = 0; i < ts->nMultGroups - 1; i++)
		{
			ts->start[parmListPtr + i] = ts->start[parmListPtr + i] > MAXEXP ? MAXEXP : 
																	  ts->start[parmListPtr + i];
			ts->start[parmListPtr + i] = ts->start[parmListPtr + i] < -MAXEXP ? -MAXEXP :
																	  ts->start[parmListPtr + i];
			d1 += exp(ts->start[parmListPtr + i]);
		}
		if (ts->iflt == 0)
		{
			for (j = 0; j < ts->nMultGroups - 1; j++) 
				ts->hw2[j] = -exp(ts->start[parmListPtr + j]) / d1 / d1;
			for (i = 0; i < ts->nMultGroups - 1; i++)
			{
				for (j = 0; j < ts->nMultGroups - 1; j++)
				{
					if (i == j)
						ts->hw2[(i + 1) * (ts->nMultGroups - 1) + j] = 
							exp(ts->start[parmListPtr + i]) *
							(d1 - exp(ts->start[parmListPtr + i])) / d1 / d1;
					else
						ts->hw2[(i + 1) * (ts->nMultGroups - 1) + j] = 
							-exp(ts->start[parmListPtr + i] +
							ts->start[parmListPtr + j]) / d1 / d1;
				}
			}
			for (jj = 0; jj < ts->nMultGroups; jj++)
			{
				for (r = 0; r < ts->nMultGroups - 1; r++)
				{
					ts->hw[jj * (ts->nMultGroups - 1) + r] = 0.;
					for (r2 = parmListPtr; r2 < parmListPtr + ts->nMultGroups - 1; r2++)
						ts->hw[jj * (ts->nMultGroups - 1) + r] += 
							ts->hessian[(r + parmListPtr) * ts->totalParms + r2] *
							ts->hw2[jj * (ts->nMultGroups - 1) + r2 - parmListPtr];
				}
			}
			for (jj = 0; jj < ts->nMultGroups; jj++)
			{
				for (r = 0; r < ts->nMultGroups; r++)
				{
					ts->hpi[jj * ts->nMultGroups + r] = 0.;
					for (r2 = 0; r2 < ts->nMultGroups - 1; r2++) 
						ts->hpi[jj * ts->nMultGroups + r] += 
							ts->hw2[jj * (ts->nMultGroups - 1) + r2] *
							ts->hw[r * (ts->nMultGroups - 1) + r2];
				} 
			} 
		}
		for (i = 0; i < ts->nMultGroups; i++)
		{
			ts->hpi[i * ts->nMultGroups + i] = fabs(ts->hpi[i * ts->nMultGroups + i]);
			ts->prdw[i] = 100. * sqrt(ts->hpi[i * ts->nMultGroups + i]);
			if (i == 0)
				ts->group_percent[i] = 100. / d1;
			else
			{
				ts->start[parmListPtr] = ts->start[parmListPtr] > MAXEXP ? MAXEXP : 
																  ts->start[parmListPtr];
				ts->start[parmListPtr] = ts->start[parmListPtr] < -MAXEXP ? -MAXEXP : 
																  ts->start[parmListPtr];
				ts->group_percent[i] = exp(ts->start[parmListPtr]) / d1 * 100.;
			}
			if (ts->iflt == 0)
			{
				temp = ts->prdw[i] > MACEPS ? ts->group_percent[i] / ts->prdw[i] : MACMISSING;
				tprob(fabs(temp), ts->nData, &temp2);
				temp2 = 2. * (1. - temp2); 
			}
			else ts->prdw[i] = MACMISSING;
			writeParmLine(i + 1, ts->iflt, ts->nData, ts->group_percent[i], ts->prdw[i],
						  "(%)         ");
			if (i > 0)
			{
				sprintf(l_str, "mthetaG%-d", i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				parmListPtr++;
			}
		}
		sprintf(hdr, " \n");  
		SF_display(hdr);
	}
	sharedStataOutput(parmListPtr, ts);
	return 0;
}

