/* 
	Read Stata data for trajectory models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

int getStataData(void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		allModelsHaveData, i, j, m, modelOffset[MAXMODELS+1], multRiskMissing, noc, noTrajData,
			noWriteCount, num_T1_T2[MAXMODELS], obs, obsDataLen[MAXMODELS], ocovMissing, outcMissing,
			oosCount, os, riskMissing[MAXMODELS], weightMissing;
	double	d, d2, dataSum[MAXMODELS], dataSqSum[MAXMODELS], dataSum_T1[MAXMODELS], dataSq_T1[MAXMODELS], 
			dataSum_T1_T2[MAXMODELS], dataSum_T2[MAXMODELS], dataSq_T2[MAXMODELS],
			dropoutTime, dwork, meanData[MAXMODELS], numDat[MAXMODELS], obsDataMean[MAXMODELS], odataSum,
			odataSqSum, weightSum;
	char	buf[90];

	/*	`var1' `indep1' `expos1' `tcov1' `risk1' `weight1' 
		`outc1' `ocov1' `dcov1' `obsmar1' `oos' `multrisk' 			
		`var2' `indep2' `expos2' `tcov2' `risk2'
		`var3' `indep3' `expos3' `tcov3' `
		 var4' `indep4' `expos4' `tcov4'
		`var5' `indep5' `expos5' `tcov5' 
		`var6' `indep6' `expos6' `tcov6'  */

	weightSum = odataSum = odataSqSum = 0.;
	modelOffset[0] = ts->nData = ts->omittedCaseCount = ts->completeDataLen[0] = ts->bicnobs =
		ts->completeDataLen[1] = noc = noWriteCount = noTrajData = oosCount = 0;
	modelOffset[1] = 2 * ts->nIndep[0] + ts->nExpos[0] + ts->nTcov[0] + ts->nRisk[0] + ts->weightStmt + 
		ts->outcStmt[0] + ts->nOcov[0] + ts->nDcov[0] + ts->obsmarStmt + ts->oosStmt + ts->nMultRisk;
	modelOffset[2] = modelOffset[1] + 2 * ts->nIndep[1] + ts->nExpos[1] + ts->nTcov[1] + ts->nRisk[1]; 
	switch (ts->likelihoodType)
	{
		case SINGLE: 
			ts->stataOutputVarsPtr = modelOffset[1] + 1; 		
			break;
		case JOINT:
			ts->stataOutputVarsPtr = modelOffset[2] + 1; 
			break;
		case MULTI: 
			for (m = 2; m < ts->nModels; m++)
				modelOffset[m + 1] = modelOffset[m] + 2 * ts->nIndep[m] +	ts->nExpos[m] + ts->nTcov[m];
			ts->stataOutputVarsPtr = modelOffset[ts->nModels] + 1;			
			break;
	}
	for (m = 0; m < ts->nModels; m++) 
	{
		dataSum[m] = dataSqSum[m] = numDat[m] = meanData[m] = 0.;
		dataSum_T1[m] = dataSum_T2[m] = dataSum_T1_T2[m] = dataSq_T1[m] = dataSq_T2[m] = 0.;
		num_T1_T2[m] = 0;
		ts->varMaxObserved[m] = -DBL_MAX;
		ts->varMinObserved[m] = DBL_MAX;
		for (i = 0; i < ts->nIndep[m]; i++)
		{
			ts->averageIndep[m][i] = 0.;
			ts->indepCount[m][i] = 0;
		}
	}
	for (obs = 0; obs < SF_nobs(); obs++)
	{
		if (ts->likelihoodType == JOINT) ts->dataStartTime[1][obs] = -1;
		ts->dataStartTime[0][obs] = -1;
		allModelsHaveData = 1;
		for (m = 0; m < ts->nModels; m++)
		{
			os = modelOffset[m];
			for (i = 0; i < ts->nIndep[m]; i++)
			{			
				SF_vdata(i + 1 + os, obs + 1, &d);
				ts->dep[m][obs][i] = d;
				SF_vdata(i + 1 + ts->nIndep[m] + os, obs + 1, &d2);
				ts->indep[m][obs][i] = d2;
			}
			os += 2 * ts->nIndep[m];	/* offset to exposure */
			getStataVar(ts->nExpos[m], obs, &os, NULL, NULL, ts->exposure[m], NULL);
			getStataVar(ts->nTcov[m], obs, &os, NULL, NULL, ts->tcov[m], NULL);
		}
		os = 2 * ts->nIndep[0] + ts->nExpos[0] + ts->nTcov[0]; /* offset to risk1 */
		riskMissing[0] = 0;
		if (!ts->multModel) getStataVar(ts->nRisk[0], obs, &os, &riskMissing[0], NULL, ts->risk[0], NULL);
		getStataVar(ts->weightStmt, obs, &os, &weightMissing, ts->weight, NULL, NULL);
		if (!IS_MISSING(ts->weight[obs]) && ts->weight[obs] > 0.) weightSum += ts->weight[obs];
		getStataVar(ts->outcStmt[0], obs, &os, &outcMissing, ts->outc, NULL, NULL);
		getStataVar(ts->nOcov[0], obs, &os, &ocovMissing, NULL, ts->ocov[0], NULL);
		getStataVar(ts->nDcov[0], obs, &os, NULL, NULL, ts->dcov[0], NULL);
		ts->obsmar[obs] = 0;
		getStataVar(ts->obsmarStmt, obs, &os, NULL, NULL, NULL, ts->obsmar);
		ts->oos[obs] = 0;
		getStataVar(ts->oosStmt, obs, &os, NULL, NULL, NULL, ts->oos);	
		getStataVar(ts->nMultRisk, obs, &os, &multRiskMissing, NULL, ts->multRisk, NULL);
	
		/* offset to risk2 */
		os = modelOffset[1] + 2 * ts->nIndep[1] + ts->nExpos[1] + ts->nTcov[1];
		riskMissing[1] = 0;
		if (!ts->multModel) getStataVar(ts->nRisk[1], obs, &os, &riskMissing[1], NULL, ts->risk[1], NULL);
/*		if (ts->likelihoodType == JOINT) getStataVar(ts->nDcov[1], obs, &os, NULL, NULL, ts->dcov[1], NULL);*/	
		ts->skip[obs] = 0;
		ts->writeObs[noWriteCount] = 1;

		if (riskMissing[0] || riskMissing[1] || weightMissing || multRiskMissing || outcMissing || ocovMissing ||
			!SF_ifobs(obs + 1))
		{
			ts->omittedCaseCount++;
			ts->writeObs[noWriteCount] = 0;
			ts->skip[obs] = 1;
			goto L600;
		}

		for (m = 0; m < ts->nModels; m++)
		{
			ts->allMissV[m][obs] = 1;
			obsDataLen[m] = 0;
			obsDataMean[m] = 0.;
			for (i = 0; i < ts->nIndep[m]; i++)	ts->missV[m][obs][i] = 0;
			for (i = 0; i < ts->nIndep[m]; i++)	
			{
				if (IS_MISSING(ts->dep[m][obs][i]) || IS_MISSING(ts->indep[m][obs][i])) 
				{
					ts->missV[m][obs][i] = 1;
					goto L100;	
				}
				if (ts->nTcov[m] > 0) 
				{
					for (j = 0; j < ts->nTcovParms[m]; j++) 
					{
						if (IS_MISSING(ts->tcov[m][obs][i + j * ts->nIndep[m]])) 
						{
							ts->missV[m][obs][i] = 1;
							goto L100;	
						}
					}
				}
				if (ts->nExpos[m] > 0) 
				{
					if (IS_MISSING(ts->exposure[m][obs][i])) 
					{
						ts->missV[m][obs][i] = 1;
						goto L100;	
					}
				}
				if (ts->missV[m][obs][i] == 0) 
				{
					if (ts->nExpos[m] > 0 && !ts->oos[obs])
					{					
						if (ts->dep[m][obs][i] / ts->exposure[m][obs][i] > ts->varMaxObserved[m])
							ts->varMaxObserved[m] = ts->dep[m][obs][i] / ts->exposure[m][obs][i];

						if (ts->dep[m][obs][i] / ts->exposure[m][obs][i] < ts->varMinObserved[m]) 
							ts->varMinObserved[m] = ts->dep[m][obs][i] / ts->exposure[m][obs][i];
					}
					else
					{
						if (!ts->oos[obs])
						{
							if (ts->dep[m][obs][i] > ts->varMaxObserved[m]) 
								ts->varMaxObserved[m] = ts->dep[m][obs][i];
					
							if (ts->dep[m][obs][i] < ts->varMinObserved[m]) 
								ts->varMinObserved[m] = ts->dep[m][obs][i];
						}
					}
					if (ts->dataStartTime[0][obs] < 0 && m == 0) ts->dataStartTime[0][obs] = i;
					if (m == 1 && ts->likelihoodType == JOINT)
						if (ts->dataStartTime[1][obs] < 0) 
							ts->dataStartTime[1][obs] = i;
					if (!ts->oos[obs])
					{
						ts->nData++;
						obsDataLen[m]++;	
						numDat[m]++;
						obsDataMean[m] += ts->dep[m][obs][i];
						dataSum[m] += ts->dep[m][obs][i];
						dataSqSum[m] += ts->dep[m][obs][i] * ts->dep[m][obs][i];
						ts->averageIndep[m][i] += ts->indep[m][obs][i];
						ts->indepCount[m][i]++;
						if (i == 1)
						{ 	
							dataSum_T1[m] += ts->dep[m][obs][1];
							dataSq_T1[m] += ts->dep[m][obs][1] * ts->dep[m][obs][1];
						}
						if (i == 2) 
						{ 	
							dataSum_T1_T2[m] += ts->dep[m][obs][1] * ts->dep[m][obs][2];
							dataSum_T2[m] += ts->dep[m][obs][2];
							dataSq_T2[m] += ts->dep[m][obs][2] * ts->dep[m][obs][2];
							num_T1_T2[m]++;
						}
					}
L100:;			
				}
			}
			if (ts->altstart)
			{
				obsDataMean[m] = obsDataMean[m] / obsDataLen[m];
				meanData[m] = meanData[m] + obsDataMean[m];
			}
			for (j = 0; j < ts->nIndep[m]; j++)
				ts->allMissV[m][obs] *= ts->missV[m][obs][j];
			allModelsHaveData *= !ts->oos[obs] ? obsDataLen[m] : 1;
		}
		oosCount += ts->oos[obs] ? 1 : 0;
		if (allModelsHaveData != 0 && !ts->oos[obs]) ts->bicnobs++; 

	/* Mark obs w/out traj data in all models as out of sample */
		if (allModelsHaveData == 0) 
		{
			ts->oos[obs] = 1;
			switch (ts->likelihoodType) 
			{
				case JOINT:
					if (ts->nRisk[1] > 0) ts->oos[obs] = 0;
				case SINGLE: 
					if (ts->nRisk[0] > 0) ts->oos[obs] = 0;
					break;
				case MULTI:
					if (ts->nMultRisk > 0) ts->oos[obs] = 0;
					break;
			}
			noTrajData++;
		}
		if (obsDataLen[0] > ts->completeDataLen[0] && !ts->oos[obs]) ts->completeDataLen[0] = obsDataLen[0];
		if (obsDataLen[1] > ts->completeDataLen[1] && !ts->oos[obs]) ts->completeDataLen[1] = obsDataLen[1];
		if (ts->outcStmt[0] && !ts->oos[obs])
		{
			noc++;
			if (ts->outc[obs] > ts->outcMaxObserved[0]) ts->outcMaxObserved[0] = ts->outc[obs];
			if (ts->outc[obs] < ts->outcMinObserved[0]) ts->outcMinObserved[0] = ts->outc[obs];
			switch (ts->outcModelType[0]) 
			{
				case m_cnorm:
				case m_logit:
				case m_mlogit:
					odataSum += ts->outc[obs];
					odataSqSum += ts->outc[obs] * ts->outc[obs];	
					break;
				case m_zip:
					odataSum += ts->outc[obs];
					odataSqSum += ts->outc[obs] * ts->outc[obs];	
				break;
			}
		}
		ts->dropoutTime[0][obs] = ts->nIndep[0];
		if (ts->likelihoodType == JOINT) ts->dropoutTime[1][obs] = ts->nIndep[1];
		switch (ts->likelihoodType) 
		{
		case JOINT:
			j = ts->nIndep[1] - 1;
			while(ts->dropoutTime[1][obs] > 0 && j > -1) 
			{
				if (IS_MISSING(ts->dep[1][obs][j]))
				{
					ts->dropoutTime[1][obs]--;
					j--;
				}
				else 
					break;			
			}
		case SINGLE: 
			j = ts->nIndep[0] - 1;
			while(ts->dropoutTime[0][obs] > 0 && j > -1) 
			{
				if (IS_MISSING(ts->dep[0][obs][j]))
				{
					ts->dropoutTime[0][obs]--;
					j--;
				}
				else 
					break;			
			}
			break;
		case MULTI: 
			for (m = 0; m < ts->nModels; m++)
			{
				dropoutTime = ts->nIndep[m];
				j = ts->nIndep[m] - 1;

				while(dropoutTime > 0 && j > -1) 
				{
					if (IS_MISSING(ts->dep[m][obs][j]))
					{
						dropoutTime--;
						j--;
					}
					else 
						break;
				}
				ts->dropoutTime[0][obs] = MIN(ts->dropoutTime[0][obs], dropoutTime);
			}
			break;
		}
L600:
		noWriteCount++;
	}
	for (m = 0; m < ts->nModels; m++) 
	{
		dwork = ((double)num_T1_T2[m] * dataSum_T1_T2[m] - dataSum_T1[m] * dataSum_T2[m]) *
				 pow( ((double)ts->indepCount[m][1] * dataSq_T1[m] - dataSum_T1[m] * dataSum_T1[m]) *
					 ((double)ts->indepCount[m][2] * dataSq_T2[m] - dataSum_T2[m] * dataSum_T2[m] ), -.5);
		ts->startRho[m] = dwork < .95 ? dwork : .95;
		for (i = 0; i < ts->nIndep[m]; i++) 
			ts->averageIndep[m][i] = ts->indepCount[m][i] > 0 ? 
			(ts->averageIndep[m][i] / (double)ts->indepCount[m][i]) : MACMISSING;
		meanData[m] = ts->altstart ? meanData[m] / ts->bicnobs : dataSum[m] / numDat[m];
		dwork = dataSqSum[m] / numDat[m] - meanData[m] * meanData[m];
		ts->startSigma[m] = dwork > 0. ? sqrt(dwork) : 1.0;
		if (!ts->altstart) 
		{
			ts->varMinObserved[m] = meanData[m] - 2. * ts->startSigma[m];		
			ts->varMaxObserved[m] = meanData[m] + 2. * ts->startSigma[m];
		}
	}
	if (noc > 0)
	{
		d = odataSum / noc;
		switch (ts->outcModelType[0]) 
		{
			case m_cnorm:
			case m_zip:
				dwork = odataSqSum / noc - d * d;
				ts->ostsg = dwork > 0. ? sqrt(dwork) : 1.0;
				break;
			case m_logit:
			case m_mlogit:
				dwork = 0.;
				if (noc > ts->nOrders[0] && d > 0. && d < 1.) 
					dwork = d * (1. - d) * pow((double)noc - (double)ts->nOrders[0], -1.);
				break;
		}
		ts->ostsg = dwork > 0. ? sqrt(dwork) : 1.0;
		ts->outcMinObserved[0] = d - 2. * ts->ostsg;
		ts->outcMaxObserved[0] = d + 2. * ts->ostsg;
	}
	sprintf(buf, " \n");  SF_display(buf);
	sprintf(buf, "%d observations read.\n", ts->maxInputObs);  SF_display(buf);
	if (ts->omittedCaseCount > 0) 
	{
		sprintf(buf, "%d excluded by if condition.\n", ts->omittedCaseCount); 
	
		if (ts->nRisk[0] + ts->nRisk[1] + ts->nMultRisk > 0) 
			sprintf(buf, "%d excluded by if condition or by missing values in risk variables.\n", 
			ts->omittedCaseCount);
		if (ts->weightStmt) 
			sprintf(buf, "%d excluded by weights missing or 0 or if condition.\n", 
			ts->omittedCaseCount);
		if (ts->outcStmt[0]) 
			sprintf(buf, "%d excluded by missing outcomes, missing risk variables, or if condition.\n", 
			ts->omittedCaseCount);
		SF_display(buf);
	}
	if (noTrajData > 0) 
	{
		switch (ts->likelihoodType) 
		{
			case SINGLE:
				sprintf(buf, "%d had no trajectory data.\n", noTrajData);
			break;
			case JOINT:
			case MULTI:
				sprintf(buf, "%d had no trajectory data in one or more models.\n", noTrajData); 
			break;
		}
		SF_display(buf);
	}
	sprintf(buf, "%d observations used in the trajectory model.\n", ts->bicnobs);  
	SF_display(buf);
	if (oosCount > 0) 
	{
		sprintf(buf, "%d observations out of sample.\n", oosCount);
		SF_display(buf);
	}
	if (ts->dropoutStmt[0]) 
	{
		sprintf(buf, "Complete data length is %d for dropout model 1.\n", ts->completeDataLen[0]);
		SF_display(buf);
	}
	if (ts->dropoutStmt[1]) 
	{
		sprintf(buf, "Complete data length is %d for dropout model 2.\n", ts->completeDataLen[1]);
		SF_display(buf);
	}
	sprintf(buf, " \n");  SF_display(buf);
	ts->nObs = SF_nobs();
	if (ts->weightStmt)
		for (i = 0; i < SF_nobs(); i++) 
			ts->weight[i] /= (weightSum / (double)ts->bicnobs);
	return 0;
}

void getStataVar(int numV, int obs, int *os, int *missing, double *d1, double **d2, int *idat) {
/*
	input:	numV - 1 or >1 (single or array)
			obs - obs no.
			*os - offset to var
	output: *missing - missing indicator
			*d1, **d2 - double result ptr for numV=1, numV>1
			*idat - int result ptr for numV=1 (none needed for numV>1)			
*/
	int i;
	double d;

	if (missing != NULL) *missing = 0;			
	if (d1 != NULL && numV == 1)
	{
		SF_vdata(*os + 1, obs + 1, &d);
		d1[obs] = d;
		if (missing != NULL) 
			if (IS_MISSING(d)) *missing = 1;
	} 
	else if (idat != NULL && numV == 1)
	{
		SF_vdata(*os + 1, obs + 1, &d);
		idat[obs] = (int)d;
		if (missing != NULL) 
			if (IS_MISSING(d)) *missing = 1;
	}
	else
	{
		for (i = 0; i < numV; i++)
		{
			SF_vdata(*os + i + 1, obs + 1, &d);
			d2[obs][i] = d;	
			if (missing != NULL)
				if (IS_MISSING(d)) *missing = 1;
		}
	}
	*os += numV;		
	return;
}