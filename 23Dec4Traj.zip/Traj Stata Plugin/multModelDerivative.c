/* 
	negative log-likelihood derivative for mult trajectory model

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include	 "ctraj.h"

int  multModelDerivative(int n, double *prm, int *nf, double *g, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		dLoc, dOrd, group, i, j, jj, k, logSigmaPrm, m, mm, multRiskParm, os, os2, os3,
			r, zo, zos;
	double	x, tmp, L1, W;

	if (ts->trace) traceOutput("multDeriv", n, prm);
	for (i = 0; i < n; i++) g[i] = 0.;
	if (ts->weightStmt) for (i = 0; i < n * n; i++) ts->xprod[i] = 0.;
	ts->multGroupProb[0] = 0.;
	if (ts->nMultRisk == 0)
	{
		multRiskParm = ts->multRiskOffset;	
		calcGroupProb(0, multRiskParm, 0, prm, qi);
	}
	for (i = 0; i < ts->nObs; i++)
	{
		if (ts->obsMultModelLk[i] <= 0. || ts->skip[i] || ts->oos[i]) continue;
		L1 = ts->obsMultModelLk[i];
		W = ts->weight[i];
		if (ts->nMultRisk > 0)
		{
			multRiskParm = ts->multRiskOffset;
			calcGroupProb(i, multRiskParm, ts->multRisk, prm, qi);
		}
		if (ts->weightStmt) for (jj = 0; jj < n; jj++) ts->score[jj] = 0.;
		os2 = 0;
		for (mm = 0; mm < ts->nModels; mm++)
		{
			logSigmaPrm = ts->riskOffset[mm] - 1;
			if (ts->sigmaByGroup) logSigmaPrm = ts->riskOffset[mm] - ts->nOrders[mm] + ts->all0Group[mm];
 			for (j = 0; j < ts->nIndep[mm]; j++)
			{
				os = 0;
				if (ts->missV[mm][i][j]) goto L100;				
				if (ts->modelType[mm] == m_zip && ts->iorderStmt[mm])
				{
					zos = ts->zipParmOffset[mm];
					zo = (int)ts->iorder[mm][0];
				}
				for (k = 0; k < ts->nMultGroups; k++)
				{
					os3 = os + os2;
					switch (ts->modelType[mm])
					{
						case m_cnorm: 
							cnormChainRule(n, &mm, &i, &k, &j, prm, &os3, ts->workrslt, qi);
							break;
						case m_logit: 
							logitChainRule(n, &mm, &i, &k, &j, prm, &os3, ts->workrslt, qi); 
							break;
						case m_zibeta: 
							betaChainRule(n, &mm, &i, &k, &j, prm, &os3, ts->workrslt, qi);
							break;
						case m_zip: 
							zipChainRule(n, &mm, &i, &k, &j, prm, &os3, ts->workrslt, qi);
					}
					for (jj = 0; jj <= (int)ts->order[mm][k] +
						((int)ts->order[mm][k] + 1 > 0) * ts->nTcovParms[mm]; jj++)
					{
						x = 1.;					
						for (m = 0; m < ts->nIndep[mm]; m++) 
							if (j == m) 
								x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
									ts->varDropoutLk[0][k][i][m] : 1.) * ts->workrslt[os + os2 + jj];
							else x *= ts->varTrajLk[mm][k][i][m] * (ts->dropoutStmt[0] && mm == 0 && 
									!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? ts->varDropoutLk[0][k][i][m] : 1.);
						for (m = 0; m < ts->nModels; m++) if (mm != m) x *= ts->obsTrajLk[m][k][i];
						tmp = W * ts->multGroupProb[k] * pow(L1, -1.) * x;

						g[os + os2 + jj] -= tmp;

						if (ts->weightStmt) ts->score[os + os2 + jj] -= tmp;
					}
					if (ts->modelType[mm] == m_cnorm && !ts->sigmaByGroup)
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[mm]; m++)
							if (j == m) 
								x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
									ts->varDropoutLk[0][k][i][m] : 1.) * ts->workrslt[logSigmaPrm];
							else x *= ts->varTrajLk[mm][k][i][m] * (ts->dropoutStmt[0] && mm == 0 && 
								!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? ts->varDropoutLk[0][k][i][m] : 1.);
						for (m = 0; m < ts->nModels; m++) if (mm != m) x *= ts->obsTrajLk[m][k][i];
						tmp = W * ts->sigma[0][0] * ts->multGroupProb[k] * pow(L1, -1.) * x;
						g[logSigmaPrm] -= tmp;
						if (ts->weightStmt) ts->score[logSigmaPrm] -= tmp;
					}
					if (ts->modelType[mm] == m_cnorm && ts->sigmaByGroup)
					{	
						/* ts->all0Group */
						if (!((int)ts->order[mm][k] == -1 && k == 0)) 				
						{	
							x = 1.;
							for (m = 0; m < ts->nIndep[mm]; m++)
								if (j == m) 
									x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
										ts->varDropoutLk[0][k][i][m] : 1.) * 
										ts->workrslt[logSigmaPrm + k - ts->all0Group[mm]];
								else x *= ts->varTrajLk[mm][k][i][m] * (ts->dropoutStmt[0] && mm == 0 && 
									!IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? ts->varDropoutLk[0][k][i][m] : 1.);
							for (m = 0; m < ts->nModels; m++) if (mm != m) x *= ts->obsTrajLk[m][k][i];
							tmp = W * ts->sigma[0][k] * ts->multGroupProb[k] * pow(L1, -1.) * x;
							g[logSigmaPrm + k - ts->all0Group[mm]] -= tmp;
							if (ts->weightStmt) ts->score[logSigmaPrm + k - ts->all0Group[mm]] -= tmp;
						}
					}
					if (ts->modelType[mm] == m_zibeta)
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[mm]; m++)
							if (j == m) 
								x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
									ts->varDropoutLk[0][k][i][m] : 1.) * 
									ts->workrslt[ts->riskOffset[mm] - ts->nOrders[mm] + k];
							else x *= ts->varTrajLk[mm][k][i][m] * (ts->dropoutStmt[0] &&
								mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? ts->varDropoutLk[0][k][i][m] : 1.);
						for (m = 0; m < ts->nModels; m++) if (mm != m) x *= ts->obsTrajLk[m][k][i];
						tmp = W * ts->phi[0][k] * ts->multGroupProb[k] * pow(L1, -1.) * x;
						g[ts->riskOffset[mm] - ts->nOrders[mm] + k ] -= tmp;
						if (ts->weightStmt) ts->score[ts->riskOffset[mm] - ts->nOrders[mm] + k ] -= tmp;
					}
					if (ts->iorderStmt[mm])
					{
						if (!ts->commonIorder[mm]) zo = (int)ts->iorder[mm][k];
						for (jj = 0; jj <= zo; jj++)
						{
							x = 1.;		
							for (m = 0; m < ts->nIndep[mm]; m++)
								if (j == m) 
									x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
										ts->varDropoutLk[0][k][i][m] : 1.) * ts->workrslt[zos + jj];
								else x *= (ts->dropoutStmt[0] && mm == 0 && !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ?
									ts->varDropoutLk[0][k][i][m] : 1.) * ts->varTrajLk[mm][k][i][m];
							for (m = 0; m < ts->nModels; m++) if (mm != m) x *= ts->obsTrajLk[m][k][i];
							tmp = W * ts->multGroupProb[k] * pow(L1, -1.) * x;
							g[zos + jj] -= tmp;							
							if (ts->weightStmt) ts->score[zos + jj] -= tmp;							
						}
						if (!ts->commonIorder[mm]) zos += (int)ts->iorder[mm][k] + 1;
					}
					os += (int)ts->order[mm][k] + 1 + ((int)ts->order[mm][k] + 1 > 0) * ts->nTcovParms[mm];
				}													
L100:;			
				if (ts->dropoutStmt[0] && j > ts->dataStartTime[0][i] && 
					j < ts->dataStartTime[0][i] + ts->completeDataLen[0] && mm == 0)
				{
					dOrd = (int)ts->dOrd[0][0];	
					dLoc = ts->dLoc[0];
					if (ts->nDcov[0] > 0)	
						for (jj = 0; jj < ts->nDcov[0] / ts->nIndep[0]; jj++)
							if (IS_MISSING(ts->dcov[0][i][j + jj * ts->nIndep[0] - 1]))
								goto L200;					
					if (dOrd > 0)
						if (j >= ts->dataStartTime[0][i] + dOrd &&	j <= ts->dropoutTime[0][i])					
							for (jj = 0; jj < dOrd; jj++)	if (IS_MISSING(ts->dep[0][i][j - jj - 1])) 
								goto L200;
					for (k = 0; k < ts->nMultGroups; k++) 
					{
						if (ts->nDropout[0] > 1) dOrd = (int)ts->dOrd[0][k];
						if (dOrd != -1 && j >= ts->dataStartTime[0][i] + dOrd && 
							j <= ts->dropoutTime[0][i])
						{							
							dropoutChainRule(n, &i, &k, &j, prm, &dOrd, &dLoc, ts->workrslt, qi);
							for (jj = 0; jj <= dOrd + ts->nDcovPrm[0]; jj++)
							{
								x = 1.;
								for (m = 0; m < ts->nIndep[0]; m++)
								{
									if (j == m) x *= ts->varTrajLk[0][k][i][m] *	ts->workrslt[dLoc + jj];
									else x *= ts->varTrajLk[0][k][i][m] * !IS_MISSING(ts->varDropoutLk[0][k][i][m]) ? 
										ts->varDropoutLk[0][k][i][m] : 1.;
								}
								tmp = W * ts->multGroupProb[k] * pow(L1, -1.) * x;							
								g[dLoc + jj] -= tmp;
								if (ts->weightStmt) ts->score[dLoc + jj] -= tmp;
							}
						}
						if (ts->nDropout[0] > 1) dLoc += (int)ts->dOrd[0][k] + 1 + ts->nDcovPrm[0];
					}
L200:;		
				}
			}
			os2 += ts->nModelParm[mm];
		}
		group = 1;
		for (k = 0; k < ts->nMultGroups; k++)
		{
			if (k != (int)ts->referenceGroup[0])
			{
				for (jj = 0; jj < ts->nMultGroups; jj++)
				{
					if (ts->obsMultTrajLk[jj][i] > 0.)
					{
						tmp = W * ts->multGroupProb[k] * ts->obsMultTrajLk[jj][i] * pow(L1, -1.);
						g[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1)] += tmp;
						if (ts->weightStmt) 
							ts->score[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1)] += tmp;
						for (r = 1; r <= ts->nMultRisk; r++)
						{
							tmp = W * ts->multRisk[i][r - 1] * ts->multGroupProb[k] *
								  ts->obsMultTrajLk[jj][i] * pow(L1, -1.);
							g[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1) + r] += tmp;
							if (ts->weightStmt)
								ts->score[ ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1) + r] += tmp;
						}			
					}
				}
				tmp = W * ts->obsMultTrajLk[k][i] * pow(L1, -1.);				
				g[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1)] -= tmp;
				if (ts->weightStmt) 
					ts->score[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1)] -= tmp;
				for (r = 1; r <= ts->nMultRisk; r++)
				{
					tmp = W * ts->multRisk[i][r - 1] * ts->obsMultTrajLk[k][i] * pow(L1, -1.);
					g[ts->multRiskOffset + (group - 1) * (ts->nMultRisk + 1) + r] -= tmp;
					if (ts->weightStmt) 
						ts->score[ts->multRiskOffset + (group - 1) *	(ts->nMultRisk + 1) + r] -= tmp;
				}
				group++;
			}
		}
		if (ts->weightStmt) 
			for (k = 0; k < n; k++) 
				for (r = 0; r < n; r++) 
					ts->xprod[k * n + r] += ts->score[k] * ts->score[r];
	}															
	if (ts->trace) traceOutput("Gradient", n, g);
	return 0;
}
