/* 
	Write expected distal outcomes to Stata file

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

void writeOutc(void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		j, L, noWriteCount, obs, saveOffset, vstoreOffset, wave;
	double	posteriorOutc, temp, **trajLk, ***trajLk_T;

	noWriteCount = 0;
	trajLk = ts->obsTrajLk[0];
	trajLk_T = ts->obsTrajLk_T[0];
	if (ts->likelihoodType == MULTI)
	{
			trajLk = ts->obsMultTrajLk; 
			trajLk_T = ts->obsMultTrajLk_T;
	}
	saveOffset = ts->vstOs;
	for (obs = 0; obs < SF_nobs(); obs++)
	{
		vstoreOffset = saveOffset;
		if (!ts->writeObs[noWriteCount] || ts->skip[noWriteCount]) goto L5900;
		expectedOutc(&obs, 0, 0, ts, 0);
		posteriorOutc = 0.;
		for (j = 0; j < ts->nOrders[0]; j++) 
			posteriorOutc += trajLk[j][obs] * ts->linkfMeanOutc[j];
		switch (ts->outcModelType[0]) {
			case m_cnorm: 
			case m_mlogit:
				break;
			case m_logit: 
				posteriorOutc = invlogit(posteriorOutc);
				break;
			case m_zip: 
				posteriorOutc = exp(posteriorOutc);
				break;
			default:
				break;
		}
		if (ts->outcModelType[0] == m_mlogit)
		{
			temp = 1.;
			for (L = 0; L < ts->nOutcLevels[0]; L++)
			{
				if ((int)ts->mlogitOutcLevel[0][L] == (int)ts->baseOutc[0]) 
					ts->probOutc[L][obs] = 0.;
				else
				{
					for (j = 0; j < ts->nOrders[0]; j++)
						ts->probOutc[L][obs] += trajLk[j][obs] * ts->linkfMeanMlogitOutc[j][L];
					temp += exp(ts->probOutc[L][obs]);
				}
				
			}
			vstoreOffset++;
			for (L = 0; L < ts->nOutcLevels[0]; L++) 
			{
				posteriorOutc = exp(ts->probOutc[L][obs]) * pow(temp, -1.);
				SF_vstore(vstoreOffset++, noWriteCount + 1, posteriorOutc);
			}
		}
		else
			SF_vstore(vstoreOffset++, noWriteCount + 1, posteriorOutc);
		if (ts->probupdates) 
		{
			for (wave = 0; wave < ts->probUpdateWaves; wave++)
			{
				expectedOutc(&obs, 1, &wave, ts, 0);
				posteriorOutc = 0.;
				for (j = 0; j < ts->nOrders[0]; j++) 
					posteriorOutc += trajLk_T[j][obs][wave] * ts->linkfMeanOutc[j]; 
				switch (ts->outcModelType[0]) {
					case m_cnorm: 
					case m_mlogit:
						break;
					case m_logit: 
						posteriorOutc = invlogit(posteriorOutc);
						break;
					case m_zip: 
						posteriorOutc = exp(posteriorOutc);
						break;
					default:
						break;
				}
				if (ts->outcModelType[0] == m_mlogit)
				{
					posteriorOutc = ts->mlogitOutcLevel[0][0];		
					temp = 0.;
					for (L = 0; L < ts->nOutcLevels[0]; L++)
					{
						ts->probOutc_T[L][obs][wave] = 0.;
						for (j = 0; j < ts->nOrders[0]; j++) 
							ts->probOutc_T[L][obs][wave] += 
								trajLk_T[j][obs][wave] * ts->meanMlogitOutc[j][L];
						if (ts->probOutc_T[L][obs][wave] > temp)
						{
							posteriorOutc = ts->mlogitOutcLevel[0][L];
							temp = ts->probOutc_T[L][obs][wave];
						}
					}
					SF_vstore(vstoreOffset++, noWriteCount + 1, posteriorOutc);
					for (L = 0; L < ts->nOutcLevels[0]; L++)
						SF_vstore(vstoreOffset++, noWriteCount + 1, ts->probOutc_T[L][obs][wave]);
				}
				else
					SF_vstore(vstoreOffset++, noWriteCount + 1, posteriorOutc);
			}
		}
L5900:;
		if (!ts->skip[obs]) ts->vstOs = vstoreOffset;
		noWriteCount++;
	}
}
