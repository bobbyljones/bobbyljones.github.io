#include "ctraj.h"

int prn1lb(int *n, int *m, double *l, 
	double *u, double *x, int *iprint, fileType itfile, 
	double *epsmch)
{
    /*
    ************ 
    Subroutine prn1lb 

    This subroutine prints the input data, initial point, upper and 
      lower bounds of each variable, machine precision, as well as 
      the headings of the output. 

    NEOS, November 1994. (Latest revision June 1996.) 
    Optimization Technology Center. 
    Argonne National Laboratory and Northwestern University. 
    Written by 
                       Ciyou Zhu 
    in collaboration with R.H. Byrd, P. Lu-Chen and J. Nocedal. 
    */
    int i__1;
    static int i__;

    char buf[128];
    --x;
    --u;
    --l;
 
    if (*iprint >= 0) {
        if (*iprint >= 1) {
            if (*iprint > 100) {
                WRITELOG("L  =");
                i__1 = *n;
                for (i__ = 1; i__ <= i__1; ++i__) {
                    WRITELOG("%.2e ", l[i__]);
                }
                WRITELOG("\n");
                WRITELOG("X0 =");
                i__1 = *n;
                for (i__ = 1; i__ <= i__1; ++i__) {
                    WRITELOG("%.2e ", x[i__]);
                }
                WRITELOG("\n");
                WRITELOG("U  =");
                i__1 = *n;
                for (i__ = 1; i__ <= i__1; ++i__) {
                    WRITELOG("%.2e ", u[i__]);
                }
                WRITELOG("\n");
            }
        }
    }
    return 0;
} 

 int prn2lb(int *n, double *x, double *f, 
	double *g, int *iprint, fileType itfile, int *iter, 
	int *nfgv, int *nact, double *sbgnrm, int *nseg, int  
	*word, int *iword, int *iback, double *stp, double *
	xstep, int word_len)
{
    /*
    Subroutine prn2lb 

    This subroutine prints out new information after a successful 
      line search. 

    NEOS, November 1994. (Latest revision June 1996.) 
    Optimization Technology Center. 
    Argonne National Laboratory and Northwestern University. 
    Written by 
                       Ciyou Zhu 
    in collaboration with R.H. Byrd, P. Lu-Chen and J. Nocedal. 
    */
    int i__1;
    static int i__, imod;
	char buf[128];
    --g;
    --x;

    if (*iword == 0) {
        *word = WORD_CON;
        /*  the subspace minimization converged. */
    } else if (*iword == 1) {
        *word = WORD_BND;
        /*  the subspace minimization stopped at a bound. */
    } else if (*iword == 5) {
        *word = WORD_TNT;
        /*  the truncated Newton step has been used. */
    } else {
        *word = WORD_DEFAULT;
    }
    if (*iprint >= 99) {
        WRITELOG("LINE SEARCH %d times; norm of step = %.2e\n", *iback, *xstep);
        WRITELOG("%5d, f(x)= %16.9e, ||proj grad||_infty = %.2e\n",*iter,*f,*sbgnrm);
        if (*iprint > 100) {
            WRITELOG("X =");
            i__1 = *n;
            for (i__ = 1; i__ <= i__1; ++i__) {
                WRITELOG("%.2e ", x[i__]);
            }
            WRITELOG("\n");
            WRITELOG("G =");
            i__1 = *n;
            for (i__ = 1; i__ <= i__1; ++i__) {
                WRITELOG("%.2e ", g[i__]);
            }
            WRITELOG("\n");
        }
    } else if (*iprint > 0) {
        imod = *iter % *iprint;
        if (imod == 0) {
            WRITELOG("%6d   %17.7f %12.8f\n",*iter,*f,*sbgnrm);
        }
    }
    return 0;
}

int prn3lb(int *n, double *x, double *f, int *
	task, int *iprint, int *info, fileType itfile, int *iter, 
	int *nfgv, int *nintol, int *nskip, int *nact, 
	double *sbgnrm, double *time, int *nseg, int *word, 
	int *iback, double *stp, double *xstep, int *k, 
	double *cachyt, double *sbtime, double *lnscht, int 
	task_len, int word_len)
{
    /*
    Subroutine prn3lb 

    This subroutine prints out information when either a built-in 
      convergence test is satisfied or when an error message is 
      generated. 

    NEOS, November 1994. (Latest revision June 1996.) 
    Optimization Technology Center. 
    Argonne National Laboratory and Northwestern University. 
    Written by 
                       Ciyou Zhu 
    in collaboration with R.H. Byrd, P. Lu-Chen and J. Nocedal. 
    */
    int i__1;
    static int i__;
    char buf[128];

    --x;

    if (IS_ERROR(*task)) {
        goto L999;
    }
    if (*iprint >= 0) {
        if (*iprint >= 100) {
            WRITELOG("X = ");
            i__1 = *n;
            for (i__ = 1; i__ <= i__1; ++i__) {
                WRITELOG(" %.2e", x[i__]);
            }
            WRITELOG("\n");
        }
    }
L999:
    if (*iprint >= 0) {
        if (*info != 0) {
            if (*info == -1) {
                WRITELOG(" Matrix in 1st Cholesky factorization in formk is not Pos. Def.\n");
            }
            if (*info == -2) {
                WRITELOG(" Matrix in 2nd Cholesky factorization in formk is not Pos. Def.\n");
            }
            if (*info == -3) {
                WRITELOG(" Matrix in the Cholesky factorization in formt is not Pos. Def.\n");
            }
            if (*info == -4) {
                WRITELOG(" Derivative >= 0, backtracking line search impossible.\n");
                WRITELOG("  Previous x, f and g restored.\n");
                WRITELOG(" Possible causes: 1 error in function or gradient evaluation;\n");
                WRITELOG("                  2 rounding errors dominate computation.\n");
            }
            if (*info == -5) {
                WRITELOG(" Warning:  more than 10 function and gradient\n");
                WRITELOG("   evaluations in the last line search.  Termination\n");
                WRITELOG("   may possibly be caused by a bad search direction.\n");
            }
            if (*info == -6) {
                WRITELOG(" Input nbd(%d) is invalid\n", *k);
            }
            if (*info == -7) {
                WRITELOG(" l(%d) > u(%d). No feasible solution.\n", *k, *k);
            }
            if (*info == -8) {
                WRITELOG(" The triangular system is singular.\n");
            }
            if (*info == -9) {
                WRITELOG(" Line search cannot locate an adequate point after 20 function\n");
                WRITELOG("  and gradient evaluations.  Previous x, f and g restored.\n");
                WRITELOG(" Possible causes: 1 error in function or gradient evaluation;\n");
                WRITELOG("                  2 rounding error dominate computation.\n");
            }
        }
 	    WRITELOG(" \n");
    }
    return 0;
}


int errclb(int *n, int *m, double *factr, 
	double *l, double *u, int *nbd, int *task, int *info,
	 int *k, int task_len)
{
    /*
    Subroutine errclb 

    This subroutine checks the validity of the input data. 

    NEOS, November 1994. (Latest revision June 1996.) 
    Optimization Technology Center. 
    Argonne National Laboratory and Northwestern University. 
    Written by 
                       Ciyou Zhu 
    in collaboration with R.H. Byrd, P. Lu-Chen and J. Nocedal. 
    */
    int i__1;
    static int i__;
    --nbd;
    --u;
    --l;

    if (*n <= 0) *task = ERROR_N0;
    if (*m <= 0) *task = ERROR_M0;
    if (*factr < 0.)  *task = ERROR_FACTR;
    /*     Check the validity of the arrays nbd(i), u(i), and l(i). */
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
        if (nbd[i__] < 0 || nbd[i__] > 3) {
            *task = ERROR_NBD;
            *info = -6;
            *k = i__;
        }
        if (nbd[i__] == 2) {
            if (l[i__] > u[i__]) {
                *task = ERROR_FEAS;
                *info = -7;
                *k = i__;
            }
        }
    }
    return 0;
}
