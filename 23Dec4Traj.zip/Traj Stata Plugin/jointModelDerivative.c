/* 
	derivative joint trajectory model

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>

	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

int jointModelDerivative(int n, double *prm, int *nf, double *g, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		group, i, j, jj, z_os, zo, os_2, os, os3, os3_2, z_os_2, ls_os,
			ls_os_2, k, k_2, r, m;
	double	tmp, x; 
	

	if (ts->trace) traceOutput("jointModelDerivative", n, prm);
	if (ts->modelType[0] == m_cnorm) ls_os = ts->riskOffset[0] - 1;
	if (ts->modelType[1] == m_cnorm) ls_os_2 = ts->riskOffset[1] - 1;
	if (ts->sigmaByGroup) 
	{
		ls_os = ts->riskOffset[0] - ts->nOrders[0];
		ls_os_2 = ts->riskOffset[1] - ts->nOrders[1];	
	}
	if (ts->modelType[0] == m_zip) z_os = ts->zipParmOffset[0];
	if (ts->modelType[1] == m_zip) z_os_2 = ts->zipParmOffset[1];
	for (i = 0; i < n; i++) g[i] = 0.;
	if (ts->weightStmt) for (i = 0; i < n * n; i++) ts->xprod[i] = 0.;
	for (i = 0; i < ts->nObs; i++)
	{
		if (ts->obsModelLk[i] <= 0. || ts->skip[i] || ts->oos[i]) continue;
		if (ts->nRisk[0] > 0)
		{
			os3 = ts->riskOffset[0];
			ts->mdl = 0;
			calcGroupProb(i, os3, ts->risk[0], prm, qi);
		}
		if (ts->weightStmt) for (jj = 0; jj < n; jj++) ts->score[jj] = 0.;
		for (j = 0; j < ts->nIndep[0]; j++)
		{
			if (ts->missV[0][i][j]) continue;
			os = 0;
			os3_2 = ts->riskOffset[1];
			for (k = 0; k < ts->nOrders[0]; k++)
			{								
				ts->mdl = 0;
				switch (ts->modelType[0])
				{
					case m_cnorm:
						cnormChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
						break;
					case m_logit:
						logitChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
						break;
					case m_zip:
						zipChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
				}
				ts->mdl = 1;
				calcGroupProb(i, os3_2, ts->risk[1], prm, qi);	
				for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
				{
					for (jj = 0; jj <= (int)ts->order[0][k] + 
						(int)(ts->order[0][k] + 1 > 0) * ts->nTcovParms[0]; jj++)
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[0]; m++)
							if (j == m)
								x = x * ts->workrslt[os + jj];
							else
								x = x * ts->varTrajLk[0][k][i][m];
						tmp = ts->weight[i] * ts->groupProb[0][k] * pow(ts->obsModelLk[i], -1.) * 
								x * ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
						g[os + jj] -= tmp;					
						if (ts->weightStmt) ts->score[os + jj] -= tmp;					
					}
				}
				os3_2 += ts->nOrders[1] - 1;
				os += (int)ts->order[0][k] + 1 + ((int)ts->order[0][k] + 1 > 0) * 
					ts->nTcovParms[0];
			}
			os3_2 = ts->riskOffset[1];
			if (ts->modelType[0] == m_cnorm && !ts->sigmaByGroup)
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{							
					ts->mdl = 0;
					cnormChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
					x = 1.;
					for (m = 0; m < ts->nIndep[0]; m++)
					{
						if (j == m)
							x = x * ts->workrslt[ls_os];
						else
							x = x * ts->varTrajLk[0][k][i][m];
					}
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						tmp = ts->weight[i] * ts->sigma[0][0] * ts->groupProb[0][k] * 
							pow(ts->obsModelLk[i], -1.) * x * ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
						g[ls_os] -= tmp;
						if (ts->weightStmt) 
							ts->score[ls_os] -= tmp;
					}
					os3_2 += ts->nOrders[1] - 1;
				}
			}
			if (ts->modelType[0] == m_cnorm && ts->sigmaByGroup)
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{							
					ts->mdl = 0;
					cnormChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
					x = 1.;
					for (m = 0; m < ts->nIndep[0]; m++)
					{
						if (j == m)
							x = x * ts->workrslt[ls_os + k];
						else
							x = x * ts->varTrajLk[0][k][i][m];
					}
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						tmp = ts->weight[i] * ts->sigma[0][k] * ts->groupProb[0][k] * 
							pow(ts->obsModelLk[i], -1.) * x * ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
						g[ls_os + k] -= tmp;
						if (ts->weightStmt) ts->score[ls_os + k] -= tmp;
					}
					os3_2 += ts->nOrders[1] - 1;
				}
			}
			os3_2 = ts->riskOffset[1];
			if (ts->iorderStmt[0])
			{
				os = z_os;				
				for (k = 0; k < ts->nOrders[0]; k++)
				{
					ts->mdl = 0;
					zipChainRule(n, &ts->mdl, &i, &k, &j, prm, &os, ts->workrslt, qi);
					zo = (int)ts->iorder[0][0];
					if (!ts->commonIorder[0]) zo = (int)ts->iorder[0][k];
					for (jj = 0; jj <= zo; jj++)
					{
						x = 1.;
						for (m = 0; m < ts->nIndep[0]; m++)
							if (j == m)
								x = x * ts->workrslt[os + jj];
							else
								x = x * ts->varTrajLk[0][k][i][m];
						ts->mdl = 1;	
						calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
						for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
						{
							tmp = ts->weight[i] * ts->groupProb[0][k] * pow(ts->obsModelLk[i], -1.) * x * 
								ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
							g[os + jj] -= tmp;
							if (ts->weightStmt) ts->score[os + jj] -= tmp;
						}
					}
					os3_2 += ts->nOrders[1] - 1;
					if (!ts->commonIorder[0]) os += (int)ts->iorder[0][k] + 1;
				}
			}
		}
		group = 1;
		for (k = 0; k < ts->nOrders[0]; k++)							
		{										
			os3_2 = ts->riskOffset[1];
			if (k != (int)ts->referenceGroup[0]) 
			{
				for (jj = 0; jj < ts->nOrders[0]; jj++)
				{
					ts->mdl = 1;	
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						tmp = ts->weight[i] * ts->groupProb[0][k] *
							ts->obsTrajLk[0][jj][i] * pow(ts->obsModelLk[i], -1.) * 
								ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
						g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] += tmp;
						if (ts->weightStmt) 
							ts->score[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] += tmp;
						for (r = 0; r < ts->nRisk[0]; r++)
						{
							tmp = ts->weight[i] * ts->risk[0][i][r] * ts->groupProb[0][k] *
								ts->obsTrajLk[0][jj][i] * pow(ts->obsModelLk[i], -1.) * 
									ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
							g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1) + r + 1] += tmp;
							if (ts->weightStmt) 
								ts->score[ts->riskOffset[0] + (group - 1) * 
									(ts->nRisk[0] + 1) + r + 1] += tmp;
						}
						if (jj == k)
						{
							tmp = ts->weight[i] * ts->obsTrajLk[0][k][i] * pow(ts->obsModelLk[i], -1.) * 
								ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];
							g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] -= tmp;
							if (ts->weightStmt) 
								ts->score[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1)] -= tmp;		
							for (r = 0; r < ts->nRisk[0]; r++)
							{
								tmp = ts->weight[i] * ts->risk[0][i][r] * 
									ts->obsTrajLk[0][k][i] * pow(ts->obsModelLk[i], -1.) * 
										ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];								
								g[ts->riskOffset[0] + (group - 1) * (ts->nRisk[0] + 1) + r + 1] -= tmp;
								if (ts->weightStmt) 
									ts->score[ts->riskOffset[0] + (group - 1) * 
										(ts->nRisk[0] + 1) + r + 1] -= tmp;
							}
						}
					}
					os3_2 += ts->nOrders[1] - 1;
				}
				group++;
			}			
		}
		for (j = 0; j < ts->nIndep[1]; j++)
		{
			if (ts->missV[1][i][j]) continue;
			os3_2 = ts->riskOffset[1];
			for (k = 0; k < ts->nOrders[0]; k++)
			{
				ts->mdl = 1;
				calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
				os = ts->jointOffset;
				for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
				{
					ts->mdl = 1;
					switch (ts->modelType[1])
					{
						case m_cnorm:
							cnormChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
							break;
						case m_logit:
							logitChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
							break;
						case m_zip:
							zipChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
					}
					for (jj = 0; 
						 jj <= (int)ts->order[1][k_2] + (int)(ts->order[1][k_2] + 1 > 0) * ts->nTcovParms[1];
						 jj++)
					{
						x = 1.;					
						for (m = 0; m < ts->nIndep[1]; m++)
							if (j == m)
								x = x * ts->workrslt[os + jj];
							else
								x = x * ts->varTrajLk[1][k_2][i][m];
						tmp = ts->weight[i] * pow(ts->obsModelLk[i], -1.) * x * 
							  ts->groupProb[1][k_2] * ts->obsTrajLk[0][k][i];	
						g[os + jj] -= tmp;
						if (ts->weightStmt) ts->score[os + jj] -= tmp;
					}
					os += (int)ts->order[1][k_2] + 1 + ((int)ts->order[1][k_2] + 1 > 0) * ts->nTcovParms[1];
				}
				os3_2 += ts->nOrders[1] - 1;
			}
			os3_2 = ts->riskOffset[1];
			if (ts->modelType[1] == m_cnorm && !ts->sigmaByGroup)
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{							
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						ts->mdl = 1;						
						cnormChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
						x = 1.;
						for (m = 0; m < ts->nIndep[1]; m++)
							if (j == m)
								x = x * ts->workrslt[ls_os_2];
							else
								x = x * ts->varTrajLk[1][k_2][i][m];
						tmp = ts->weight[i] * ts->sigma[1][k_2] * pow(ts->obsModelLk[i], -1.) * 
						 	  x * ts->groupProb[1][k_2] * ts->obsTrajLk[0][k][i];
						g[ls_os_2] -= tmp;
						if (ts->weightStmt) ts->score[ls_os_2] -= tmp;
					}
					os3_2 += ts->nOrders[1] - 1;
				}
			}
			if (ts->modelType[1] == m_cnorm && ts->sigmaByGroup)
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{							
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						ts->mdl = 1;						
						cnormChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
						x = 1.;
						for (m = 0; m < ts->nIndep[1]; m++)
							if (j == m)
								x = x * ts->workrslt[ls_os_2 + k_2];
							else
								x = x * ts->varTrajLk[1][k_2][i][m];
						tmp = ts->weight[i] * ts->sigma[1][k_2] * pow(ts->obsModelLk[i], -1.) *
						 	  x * ts->groupProb[1][k_2] * ts->obsTrajLk[0][k][i];
						g[ls_os_2 + k_2] -= tmp;
						if (ts->weightStmt) ts->score[ls_os_2 + k_2] -= tmp;
					}
					os3_2 += ts->nOrders[1] - 1;
				}
			}
			os3_2 = ts->riskOffset[1];
			if (ts->iorderStmt[1])
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{
					os_2 = z_os_2;							
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
					{
						ts->mdl = 1;
						zipChainRule(n, &ts->mdl, &i, &k_2, &j, prm, &os, ts->workrslt, qi);
						zo = (int)ts->iorder[1][0];
						if (!ts->commonIorder[1]) zo = (int)ts->iorder[1][k_2];
						for (jj = 0; jj <= zo; jj++)
						{
							x = 1.;
							for (m = 0; m < ts->nIndep[1]; m++)
								if (j == m)
									x = x * ts->workrslt[os_2 + jj];
								else
									x = x * ts->varTrajLk[1][k_2][i][m];
							tmp = ts->weight[i] * pow(ts->obsModelLk[i], -1.) * x *
								  ts->groupProb[1][k_2] * ts->obsTrajLk[0][k][i];
							g[os_2 + jj] -= tmp;
							if (ts->weightStmt) ts->score[os_2 + jj] -= tmp;
						}
						if (!ts->commonIorder[1]) os_2 += (int)ts->iorder[1][k_2] + 1;
					}
					os3_2 += ts->nOrders[1] - 1;
				}
			}
		}
		os3_2 = ts->riskOffset[1];
		for (k = 0; k < ts->nOrders[0]; k++)							
		{											
			ts->mdl = 1;				
			calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
			group = 1;
			for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++)
			{
				if (k_2 != (int)ts->referenceGroup[1]) 
				{
					for (jj = 0; jj < ts->nOrders[1]; jj++)
					{
						tmp = ts->weight[i] * ts->groupProb[1][k_2] * ts->groupProb[1][jj] * 
							  ts->obsTrajLk[1][jj][i] * pow(ts->obsModelLk[i], -1.) * ts->obsTrajLk[0][k][i];						
						g[ts->riskOffset[1] + (group - 1) + k * (ts->nOrders[1] - 1)] += tmp;
						if (ts->weightStmt) 
							ts->score[ts->riskOffset[1] + (group - 1) + k * (ts->nOrders[1] - 1)] += tmp;
						if (k_2 == jj)
						{
							tmp = ts->weight[i] * ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i] * 
							 	  pow(ts->obsModelLk[i], -1.) * ts->obsTrajLk[0][k][i];
							g[ts->riskOffset[1] + (group - 1) + k * (ts->nOrders[1] - 1)] -= tmp;
							if (ts->weightStmt) 
								ts->score[ts->riskOffset[1] + (group - 1) + k *	(ts->nOrders[1] - 1)] -= tmp;
						}
					}
					group++;
				}
			}
			os3_2 += ts->nOrders[1] - 1;
		}
		group = 1;
		for (k_2 = 0; k_2 < ts->nOrders[1]; k_2++) 			
		{
			os3_2 = ts->riskOffset[1];
			if (k_2 != (int)ts->referenceGroup[1]) 
			{
				for (k = 0; k < ts->nOrders[0]; k++)
				{
					ts->mdl = 1;
					calcGroupProb(i, os3_2, ts->risk[1], prm, qi);
					for (jj = 0; jj < ts->nOrders[1]; jj++)
					{
						for (r = 0; r < ts->nRisk[1]; r++)
						{
							tmp = ts->weight[i] * ts->obsTrajLk[0][k][i] * 
								  ts->risk[1][i][r] * ts->groupProb[1][k_2] *
								  ts->groupProb[1][jj] * ts->obsTrajLk[1][jj][i] *
								  pow(ts->obsModelLk[i], -1.);
							g[ts->riskOffset[1] + ts->nOrders[0] * (ts->nOrders[1] - 1) + r + 
							  (group - 1) * ts->nRisk[1]] += tmp;
							if (ts->weightStmt) 
								ts->score[ts->riskOffset[1] + ts->nOrders[0] * (ts->nOrders[1] - 1) + r + 
									     (group - 1) * ts->nRisk[1]] += tmp;
						}
						if (jj == k_2)
						{
							for (r = 0; r < ts->nRisk[1]; r++)
							{
								tmp = ts->weight[i] * ts->risk[1][i][r] * 
									  ts->obsTrajLk[0][k][i] * pow(ts->obsModelLk[i], -1.) *
									  ts->groupProb[1][k_2] * ts->obsTrajLk[1][k_2][i];	
								g[ts->riskOffset[1] + ts->nOrders[0] * (ts->nOrders[1] - 1) + 
								  r + (group - 1) * (ts->nRisk[1])] -= tmp;
								if (ts->weightStmt) 
									ts->score[ts->riskOffset[1] + ts->nOrders[0] * (ts->nOrders[1] - 1) + 
									r + (group - 1) * (ts->nRisk[1])] -= tmp;
							}
						}
					}
					os3_2 += ts->nOrders[1] - 1;
				}
				group++;
			}
		}
		if (ts->weightStmt)
			for (k = 0; k < n; k++)
				for (r = 0; r < n; r++) ts->xprod[k * n + r] += g[k] * g[r];
	}
	if (ts->trace) traceOutput("Gradient", n, g);
	return 0;
}
