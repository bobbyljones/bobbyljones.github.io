/* 
	Calculate CI for multinomial outcome using Sison and Glaz method

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/
#include "ctraj.h"

double truncpoi(double c, double n, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		i;
	double	arg1, f, g1, g2, lmb, poly, probn, probx, rslt, rslt2, rslt3, rslt5[5], 
			s1, s2, s3, s4, z;


	s1 = s2 = s3 = s4 = 0.;

	arg1 = n - 1.;

	rslt2 = ppois(&n, &n);

	rslt3 = ppois(&arg1, &n);

	probn = 1. / (rslt2 - rslt3);

	probx = 1.;

	for (i = 0; i < ts->nOutcLevels[0]; i++)
	{
		lmb = ts->mlogitX[i];
 
		mlogitCI_Moments(&c, &lmb, rslt5, &ts);

		rslt5[3] -= 3 * rslt5[1] * rslt5[1];
	
		s1 += rslt5[0];
   
		s2 += rslt5[1];

		s3 += rslt5[2];

		s4 += rslt5[3];

		probx *= rslt5[4];
	}
	
	z = (n - s1) / sqrt(s2);
   
	g1 = s3 / pow(s2, 1.5);
   
	g2 = s4 / (s2 * s2);
   
	poly = 1. + g1 * (pow(z, 3) - 3. * z) / 6. + g2 * (pow(z, 4) - 6. * z * z + 3.) / 24. +
				g1 * g1 * (pow(z, 6) - 15. * pow(z, 4) + 45. * z * z - 15.) / 72.;
   
	f = poly * exp(-z * z / 2.) / M_SQRT2 / M_PI;
    
	rslt = probn * probx * f / sqrt(s2);
	
	return rslt;
}

int mlogitCI_Moments(double *c, double *lmb, double *mom, void *qi )
{
	struct	TRAJSTRUCT *ts = qi;
	
	int		r;

	double	a, arg1, b, den, mu[4], poisA, poisB, rslt2, rslt3, rslt4, rslt5;
 

	a = *lmb + *c;
   
	b = *lmb - *c;
   
	if (b < 0) b = 0.;
   
	arg1 = b - 1.;

	rslt2 = ppois(&a, lmb);

	rslt3 = ppois(&arg1, lmb);

	if (b > 0) den = rslt2 - rslt3;

	if (b == 0) den = rslt2;  
   
	for (r = 1; r <= 4; r++) 
	{
      poisA = poisB = 0.;
 
		arg1 = a - r;

		rslt4 = ppois(&arg1, lmb);

		arg1 = b - r - 1.;
		
		rslt5 = ppois(&arg1, lmb);

		if (a - r >= 0.) poisA = rslt2 - rslt4;

		if (a - r < 0.) poisA = rslt2;

		if (b - r - 1. >= 0.) poisB = rslt3 - rslt5;

		if (b - r - 1. < 0. && b - 1. >= 0.) poisB = rslt3;

      if (b - r - 1. < 0. && b - 1. < 0.) poisB = 0.; 

      mu[r - 1] = pow(*lmb, r) * (1. - (poisA - poisB) / den);
   }
  
	mom[0] = mu[0];
   
	mom[1] = mu[1] + mu[0] - mu[0] * mu[0];

	mom[2] = mu[2] + mu[1] * (3. - 3. * mu[0]) + 
				mu[0] - 3. * mu[0] * mu[0] + 2. * pow(mu[0], 3);

	mom[3] = mu[3] + mu[2] * (6. - 4. * mu[0]) 
				+ mu[1] * (7. - 12. * mu[0] + 6. * mu[0] * mu[0]) + 
				mu[0] - 4. * mu[0] * mu[0] + 6. * pow(mu[0], 3) - 3. * pow(mu[0], 4);

	mom[4] = den;

	return(0);
}


