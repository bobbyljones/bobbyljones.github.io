/*	
	Negative log-likelihood for single trajectory models	
	
	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"
		
int singleModelnll(int n, double *prm, double *fx, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		gp, obs, wave;	
	double	obsTrajLkSum;
	char	buf[80];

	if (ts->trace) traceOutput("prm", n, prm);
	*fx = 0.;
	if (ts->nRisk[0] < 1) calcGroupProb(0, ts->riskOffset[0], 0, prm, qi);
	/* cnormAR1nll, cnormMixednll, or componentnll */
	if (ts->modelType[0] == m_cnorm && ts->ar1) cnormAR1nll(&prm[0], qi);
	else if (ts->modelType[0] == m_cnorm && ts->modelSubtype[0] == MIXEDMODEL) cnormMixednll(&prm[0], qi);
	else componentnll(ts->riskOffset[0], &prm[0], qi);
	for (obs = 0; obs < ts->nObs; obs++) 
	{
		ts->obsModelLk[obs] = obsTrajLkSum = 0.;
		ts->outcLk[obs] = 1.;
		if (ts->skip[obs]) continue;
		if (ts->nRisk[0] > 0) calcGroupProb(obs, ts->riskOffset[0], ts->risk[0], prm, qi);
		for (gp = 0; gp < (int)ts->nOrders[0]; gp++)
		{
			ts->obsTrajLk[0][gp][obs] *= ts->groupProb[0][gp];
			if (ts->dropoutStmt[0]) 
			{
				if (!IS_MISSING(ts->obsDropoutLk[0][gp][obs]))
					ts->obsTrajLk[0][gp][obs] *= ts->obsDropoutLk[0][gp][obs];
			}
			if (ts->probupdates && !ts->skip[obs] && ts->nPrUpdt > 0) 
			{
				for (wave = 0; wave < ts->nIndep[0]; wave++) 
				{
					if (ts->modelType[0] == m_cnorm && ts->ar1 && wave == 0)
						ts->obsTrajLk_T[0][gp][obs][0] = 1.;
					ts->obsTrajLk_T[0][gp][obs][wave] *= ts->groupProb[0][gp];
					if (ts->dropoutStmt[0]) 
						if (!IS_MISSING(ts->obsDropoutLk[0][gp][obs]))
							ts->obsTrajLk_T[0][gp][obs][wave] *= ts->obsDropoutLk[0][gp][obs];
				}
			}
			ts->obsModelLk[obs] += ts->obsTrajLk[0][gp][obs];
			obsTrajLkSum += ts->obsTrajLk[0][gp][obs];
		}
		if (ts->outcStmt[0] && !ts->twoStep) 
		{
			for (gp = 0; gp < (int)ts->nOrders[0]; gp++)
				ts->obsTrajLk[0][gp][obs] *= pow(obsTrajLkSum, -1.);
		}
	}
	/* outcome nll 1step option */
	if (ts->outcStmt[0] && !ts->twoStep) outc_nll_1S(prm, qi);
	for (obs = 0; obs < ts->nObs; obs++) 
	{
		if (ts->oos[obs] || ts->skip[obs]) 
		{/* no contribution to likelihood */} 
		else if (ts->obsModelLk[obs] > DBL_MIN && ts->outcLk[obs] > DBL_MIN) 
			*fx -= (log(ts->obsModelLk[obs]) + log(ts->outcLk[obs])) * ts->weight[obs];
		else 
		{
			if (ts->itdetail) WRITELOG("obs %d likelihood problem\n", obs+1);
			if (ts->modelType[0] == m_cnorm && ts->ar1)
			{/* continue */} 
			else 
			{
				*fx = DBL_MAX;
				goto L999;
			}
		}
	}
L999:
	if (ts->trace) WRITELOG("nll = %12.5e\n", *fx);
	return 0;
}
