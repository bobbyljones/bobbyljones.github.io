/* 	
	Stata plugin initialization

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.
*/

#include "ctraj.h"

int trajInitStata(void *trajStruct) {

	struct	TRAJSTRUCT *ts = trajStruct;
	char	buf[80], l_str[33], namesBuf[4096], *varName;
	int		i, itemp, m, maxLen = 4096, nOrder;
	double	rslt;

	SF_display(" \n");
	WRITELOG("==== traj stata plugin ====  Jones BL  Nagin DS,  build: %s\n", __DATE__);
	ts->maxInputObs = SF_nobs();
	ts->mdl = 0;	 /* model: 0, single (default); 1, joint or multi; 2-5, multi */
	ts->nPrUpdt = 0; /* probupdates after likelihood maximization indicator		  */
	ts->noprint = 0;
	ts->nModels = 1;
	for (m = 1; m < MAXMODELS; m++) if (ts->modelStmt[m]) ts->nModels++;
	for (m = 0; m < MAXMODELS; m++) 
	{
		ts->nOutcPrm[m] = ts->nOutcLevels[m] = ts->nModelParm[m] =
		ts->modelSubtype[m] = ts->all0Group[m] = 0;
	}
	for (m = 0; m < ts->nModels; m++) 
	{
		SF_mat_el("traj_mat_min", 1, m + 1, &ts->varMin[m]);
		SF_mat_el("traj_mat_max", 1, m + 1, &ts->varMax[m]);
		SF_mat_el("traj_mat_plottcov_len", 1, m + 1, &rslt);
		ts->nPlotTcov[m] = (int)rslt;
		if (ts->nPlotTcov[m] > 0) ts->plotTcovStmt[m] = 1;
	}
	SF_mat_el("traj_mat_tol", 1, 1, &ts->convergenceTol);
	SF_mat_el("traj_mat_opts", 1, 1, &rslt);	
	ts->probupdates = (int)rslt;
	//SF_mat_el("traj_mat_opts", 1, 2, &rslt);
	//ts->ciOpt = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 3, &rslt);
	ts->itdetail = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 4, &rslt);
	ts->no_var = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 5, &rslt);
	ts->trace = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 6, &rslt);
	ts->nMultGroups = (int)rslt;
	ts->multModel = ts->nMultGroups > 0 ? 1 : 0;
	SF_mat_el("traj_mat_opts", 1, 7, &rslt);
	ts->numStartVal = (int)rslt;
	ts->startStmt = ts->numStartVal > 0 ? 1 : 0;
	SF_mat_el("traj_mat_opts", 1, 8, &rslt);
	ts->scoreCIOpt = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 9, &rslt);
	ts->sigmaByGroup = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 10, &rslt);
	ts->numLowerVal = (int)rslt;
	ts->lowerStmt = ts->numLowerVal > 0 ? 1 : 0;
	SF_mat_el("traj_mat_opts", 1, 11, &rslt);
	ts->numUpperVal = (int)rslt;
	ts->upperStmt = ts->numUpperVal > 0 ? 1 : 0;
	//SF_mat_el("traj_mat_opts", 1, 12, &rslt);
	SF_mat_el("traj_mat_opts", 1, 13, &rslt);
	ts->nderiv = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 14, &rslt);
	ts->twoStep = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 15, &rslt);
	ts->altstart = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 16, &rslt);
	ts->ar1 = (int)rslt;
	SF_mat_el("traj_mat_opts", 1, 17, &rslt);
	ts->rhoByGroup = (int)rslt;
	if (ts->ar1) ts->modelSubtype[0] = AR1;
	if (ts->multModel) 
		ts->likelihoodType = MULTI;
	else 
		ts->likelihoodType = ts->nOrders[1] > 0 ? JOINT : SINGLE;
	nOrder = MAX(ts->nOrders[0], ts->nOrders[1]);
	for (m = 2; m < MAXMODELS; m++) 
	{
		ts->dropoutStmt[m] = ts->nDropout[m] = ts->outcStmt[m] = ts->dcovStmt[m] = 
		ts->nDcov[m] = ts->nRisk[m] = 0;
	}
	for (m = 1; m < MAXMODELS; m++) 
	{
		ts->outcStmt[m] = ts->rorderStmt[m] = ts->ocovStmt[m] = ts->nOcov[m] = ts->outcModelType[m] = 0;
	}
	for (m = 0; m < MAXMODELS; m++) 
	{
		ts->nTcovParms[m] = ts->nDcovPrm[m] = ts->outcMaxStmt[m] = ts->outcMinStmt[m] = 0;
		if (ts->nTcov[m] > 0) ts->plotTcov[m] = (double*)calloc(ts->nTcov[m], sizeof(double));
	}
	ts->referenceGroupStmt[0] = ts->referenceGroupStmt[1] = 1;
	if (ts->outcStmt[0]) 
	{
		switch (ts->outcModelType[0])
		{
		case m_zip:
			ts->nOutcPrm[0] = ts->nOrders[0];
			break;
		case m_cnorm:
			ts->nOutcPrm[0] = ts->nOrders[0] + 1;
			break;
		case m_mlogit:
			SF_mat_el("traj_mat_mlogitoutc", 1, 1, &ts->baseOutc[0]);
			SF_mat_el("traj_mat_mlogitoutc", 1, 2, &rslt);
			ts->nOutcLevels[0] = (int)rslt;
			ts->nOutcPrm[0] = ts->nOrders[0] * (ts->nOutcLevels[0] - 1);
			ts->mlogitOutcProb[0] = allocMat2d(ts->maxInputObs, ts->nOutcLevels[0]);
			ts->mlogitOutcLevel[0] = (double*)calloc(ts->nOutcLevels[0], sizeof(double));
			ts->mlogitX = (double*)calloc(ts->nOutcLevels[0], sizeof(double));
			itemp = 2 * ts->nOutcLevels[0];
			ts->mlogitOutcCIRslt = (double*)calloc(itemp, sizeof(double));
			for (i = 0; i < ts->nOutcLevels[0]; i++)
				SF_mat_el("traj_mat_mlogitlevels", 1, i + 1, &ts->mlogitOutcLevel[0][i]);
			break;
		case m_logit:
			ts->nOutcPrm[0] = ts->nOrders[0];
			break;
		}
		if (ts->ocovStmt[0])
		{
			if (ts->outcModelType[0] != m_mlogit) ts->nOutcPrm[0] += ts->nOcov[0];
			else ts->nOutcPrm[0] += ts->nOcov[0] * (ts->nOutcLevels[0] - 1);
		}
	}
	SF_mat_el("traj_mat_refgp", 1, 1, &ts->referenceGroup[0]);
	SF_mat_el("traj_mat_refgp", 1, 2, &ts->referenceGroup[1]);
	ts->referenceGroup[0]--;
	ts->referenceGroup[1]--;
	for (m = 0; m < MAXMODELS; m++)
	{
		sprintf(l_str, "traj_mat_order%-d", m + 1);
		if (ts->orderStmt[m])
			for (i = 0; i < ts->nOrders[m]; i++)
				SF_mat_el(l_str, 1, i + 1, &ts->order[m][i]);
		sprintf(l_str, "traj_mat_iorder%-d", m + 1);
		if (ts->iorderStmt[m])
			for (i = 0; i < ts->nIorder[m]; i++)
				SF_mat_el(l_str, 1, i + 1, &ts->iorder[m][i]);
		sprintf(l_str, "traj_mat_plottcov%-d", m + 1); 
		if (ts->plotTcovStmt[m])
			for (i = 0; i < ts->nPlotTcov[m]; i++)
				SF_mat_el(l_str, 1, i + 1, &ts->plotTcov[m][i]);
		if (ts->nTcov[m] != 0)
		{
			ts->tcovNames[m] = allocMat2dc(ts->nTcov[m], 13);
			sprintf(l_str, "_tcov%-d", m + 1);
			SF_macro_use(l_str, namesBuf, maxLen);
			varName = strtok(namesBuf, " ");
			i = 0;
			while (varName != NULL)
			{
				sprintf(ts->tcovNames[m][i], "%-.12s", varName);
				varName = strtok(NULL, " ");
				i++;
			}
		}
	}
	
	if (ts->dropoutStmt[0])
		for (i = 0; i < ts->nDropout[0]; i++)
			SF_mat_el("traj_mat_dropoutorder1", 1, i + 1, &ts->dOrd[0][i]);
	if (ts->dropoutStmt[1])
		for (i = 0; i < ts->nDropout[1]; i++)
			SF_mat_el("traj_mat_dropoutorder2", 1, i + 1, &ts->dOrd[1][i]);
	if (ts->rorderStmt[0])
		for (i = 0; i < ts->nRorder[0]; i++)
			SF_mat_el("traj_mat_rorder1", 1, i + 1, &ts->rorder[0][i]);

	/* Get variable names for output (risk, tcov, ...)		 */
	if (ts->nRisk[0] != 0)
	{
		ts->riskNames[0] = allocMat2dc(ts->nRisk[0], 13);
		SF_macro_use("_risk1", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->riskNames[0][i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}
		ts->risk[0] = allocMat2d(ts->maxInputObs, ts->nRisk[0]);
	}
	if (ts->nRisk[1] != 0)
	{
		ts->riskNames[1] = allocMat2dc(ts->nRisk[1], 13);
		SF_macro_use("_risk2", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->riskNames[1][i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}	
		ts->risk[1] = allocMat2d(ts->maxInputObs, ts->nRisk[1]);
	}
	if (ts->nMultRisk != 0)
	{
		ts->multRiskNames = allocMat2dc(ts->nMultRisk, 13);
		SF_macro_use("_multrisk", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->multRiskNames[i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}
		ts->multRisk = allocMat2d(ts->maxInputObs, ts->nMultRisk);
	}
	if (ts->nDcov[0] != 0)
	{
		ts->dcovNames[0] = allocMat2dc(ts->nDcov[0], 13);
		SF_macro_use("_dcov1", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->dcovNames[0][i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}
		ts->dcov[0] = allocMat2d(ts->maxInputObs, ts->nDcov[0]);
		ts->nDcovPrm[0] = ts->nDcov[0] / ts->nIndep[0];
	}
	if (ts->nDcov[1] != 0)
	{
		ts->dcovNames[1] = allocMat2dc(ts->nDcov[1], 13);
		SF_macro_use("_dcov1", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->dcovNames[1][i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}
		ts->dcov[1] = allocMat2d(ts->nDcov[1], ts->maxInputObs);
		ts->nDcovPrm[1] = ts->nDcov[1] / ts->nIndep[1];
	}
	if (ts->nOcov[0] != 0)
	{
		ts->ocovNames[0] = allocMat2dc(ts->nOcov[0], 13);
		SF_macro_use("_ocov1", namesBuf, maxLen);
		varName = strtok(namesBuf, " ");
		i = 0;
		while (varName != NULL) 
		{
			sprintf(ts->ocovNames[0][i], "%-.12s", varName);
			varName = strtok(NULL, " ");	
			i++;
		}
		ts->ocov[0] = allocMat2d(ts->maxInputObs, ts->nOcov[0]);
	}
	for (m = 0; m < ts->nModels; m++) 
	{			
		ts->commonIorder[m] = 0;
		if (ts->iorderStmt[m] && ts->nIorder[m] == 1) ts->commonIorder[m] = 1;
	}
	ts->vr = (double *) calloc(nOrder, sizeof(double));
	ts->ymxb1 = (double *) calloc(ts->nIndep[0], sizeof(double));
	ts->ymxb2 = (double *) calloc(ts->nIndep[0], sizeof(double));
	ts->intlimit = (int *) calloc(ts->nIndep[0], sizeof(int));
	itemp = 3 * MAX(nOrder, ts->nOutcLevels[0]) + 1;
	ts->prdw = (double *) calloc(itemp, sizeof(double));
	for (m = 0; m < 2; m++)
	{
		ts->nDropoutParms[m] = 0;
		ts->dropoutTime[m] = (int*)calloc(ts->maxInputObs, sizeof(int));
		for (i = 0; i < ts->nDropout[m]; i++)
		{
			if (ts->dOrd[m][i] > -1) ts->dropoutStmt[m] = 1;
			ts->nDropoutParms[m] += (int)ts->dOrd[m][i] + 1;
		}
		if (ts->dropoutStmt[m])
		{
			//ts->obsMultModelLkByModel[m] = (double *) calloc(ts->maxInputObs, sizeof(double));
			ts->varDropoutLk[m] = allocMat3d(ts->nOrders[m], ts->maxInputObs, ts->nIndep[m]);
			ts->dropoutProb[m] = allocMat2d(ts->nOrders[m], ts->nIndep[m]);
			ts->obsDropoutLk[m] = allocMat2d(ts->nOrders[m], ts->maxInputObs);
			ts->dropoutSumByGroupTime[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
			ts->dropoutCountByGroupTime[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
		}
	}
	switch (ts->likelihoodType) 
	{
		case JOINT: 
			ts->probUpdateWaves = MIN(ts->nIndep[0], ts->nIndep[1]) - 1; 
			break;
		case SINGLE: 
			ts->probUpdateWaves = ts->nIndep[0] - 1; 
			break;
		case MULTI:
			ts->probUpdateWaves = ts->nIndep[0]; 
			for (m = 1; m < ts->nModels; m++)
				ts->probUpdateWaves = 
					ts->nIndep[m] > ts->probUpdateWaves ? ts->nIndep[m] : ts->probUpdateWaves;
			break;
	}
	ts->obsModelLk = (double *) calloc(ts->maxInputObs, sizeof(double));
	if (ts->multModel)
	{
		ts->obsMultModelLk = (double *) calloc(ts->maxInputObs, sizeof(double));
		ts->multGroupProb = (double *) calloc(ts->nMultGroups, sizeof(double));
		ts->obsMultTrajLk = allocMat2d(ts->nMultGroups, ts->maxInputObs);
		if (ts->probupdates) 
			ts->obsMultTrajLk_T = allocMat3d(ts->nMultGroups, ts->maxInputObs, ts->probUpdateWaves);
	}
	ts->plotWork = allocMat2d(ts->nOrders[0], ts->nIndep[0]);
	if (ts->outcStmt[0]) 
	{
		ts->outcMaxObserved[0] = ts->outcMin[0] = -DBL_MAX;
		ts->outcMinObserved[0] = ts->outcMax[0] = DBL_MAX;
		ts->linkfMeanOutc = (double *) calloc(ts->nOrders[0], sizeof(double));
		ts->meanOutc = (double *) calloc(ts->nOrders[0], sizeof(double));
		ts->meanOutcL95 = (double *) calloc(ts->nOrders[0], sizeof(double));
		ts->meanOutcU95 = (double *) calloc(ts->nOrders[0], sizeof(double));
		if (ts->outcModelType[0] == m_mlogit)
		{
			ts->linkfMeanMlogitOutc = allocMat2d(ts->nOrders[0], ts->nOutcLevels[0]);
			ts->meanMlogitOutc = allocMat2d(ts->nOrders[0], ts->nOutcLevels[0]);
			ts->meanMlogitOutcL95 = allocMat2d(ts->nOrders[0], ts->nOutcLevels[0]);
			ts->meanMlogitOutcU95 = allocMat2d(ts->nOrders[0], ts->nOutcLevels[0]);
			ts->probOutc = allocMat2d(ts->nOutcLevels[0], ts->maxInputObs);
			if (ts->probupdates)
				ts->probOutc_T = allocMat3d(ts->nOutcLevels[0], ts->maxInputObs, ts->nIndep[0]);						
		}
	}
	switch (ts->likelihoodType) 
	{
		case JOINT: 
			ts->sigma[1] = (double *) calloc(ts->nOrders[1], sizeof(double));			
			ts->sigmaSq[1] = (double *) calloc(ts->nOrders[1], sizeof(double));			
			ts->rho[1] = (double *) calloc(ts->nOrders[1], sizeof(double));
			ts->phi[1] = (double *) calloc(ts->nOrders[1], sizeof(double));			
			ts->groupProbSum[1] = (double *) calloc(ts->nOrders[1], sizeof(double));	
			ts->dataStartTime[1] = (int *) calloc(ts->maxInputObs, sizeof(int));
			ts->posteriorProb[1] = (double*)calloc(ts->nOrders[1], sizeof(double));
			itemp = ts->nOrders[0] * ts->nOrders[1];
			ts->pv_jk = (double *) calloc(itemp, sizeof(double));
			itemp = MAX((ts->nOrders[0] + 1), (ts->nOrders[1] + 1));
			ts->pv_2 = (double *) calloc(itemp, sizeof(double));
			ts->obsJointTrajLk = allocMat3d(ts->nOrders[0], ts->nOrders[1], ts->maxInputObs);
		case MULTI:
		case SINGLE: 
			ts->sigma[0] = (double *) calloc(ts->nOrders[0], sizeof(double));			
			ts->sigmaSq[0] = (double *) calloc(ts->nOrders[0], sizeof(double));			
			ts->rho[0] = (double *) calloc(ts->nOrders[0], sizeof(double));			
			ts->phi[0] = (double *) calloc(ts->nOrders[0], sizeof(double));			
			ts->groupProbSum[0] = (double *) calloc(ts->nOrders[0], sizeof(double));	
			ts->dataStartTime[0] = (int *) calloc(ts->maxInputObs, sizeof(int));
			ts->posteriorProb[0] = (double*)calloc(ts->nOrders[0], sizeof(double));
			if (ts->probupdates) 
			{
				ts->groupProbSum_T[0] = allocMat2d(ts->nOrders[0], ts->probUpdateWaves);
				ts->posteriorProb_T[0] = allocMat2d(ts->nOrders[0], ts->probUpdateWaves);
			}
			break;
	}
	for (m = 0; m < ts->nModels; m++) 
	{
		ts->groupProb[m] = (double *) calloc(ts->nOrders[m], sizeof(double));		
		ts->indepCount[m] = (int *) calloc(ts->nIndep[m], sizeof(int));		
		ts->averageIndep[m] = (double *) calloc(ts->nIndep[m], sizeof(double));		
		itemp = 1 + 5 * ts->nOrders[m];
		ts->plotData[m] = (double *) calloc(itemp, sizeof(double));	
		if (ts->probupdates)
			ts->obsTrajLk_T[m] = allocMat3d(ts->nOrders[m], ts->maxInputObs, ts->nIndep[m]);
		if (ts->nTcov[m] > 0)
		{
			ts->nTcovParms[m] = ts->nTcov[m] / ts->nIndep[m];	
			ts->tcov[m] = allocMat2d(ts->maxInputObs, ts->nTcov[m]);
		}
		ts->obsTrajLk[m] = allocMat2d(ts->nOrders[m], ts->maxInputObs);
		ts->varTrajLk[m]= allocMat3d(ts->nOrders[m], ts->maxInputObs, ts->nIndep[m]);
		ts->varGradient[m] = allocMat3d(ts->nOrders[m], ts->maxInputObs, ts->nIndep[m]);
		ts->varSumByGroupTime[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
		ts->expectedTrajByGroupTime[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
		ts->varianceSum[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
		ts->probSumByGroupTime[m] = allocMat2d(ts->nIndep[m], ts->nOrders[m]);
		ts->dep[m] = allocMat2d(ts->maxInputObs, ts->nIndep[m]);
		ts->indep[m] = allocMat2d(ts->maxInputObs, ts->nIndep[m]);
		ts->missV[m] = (int **) calloc(ts->maxInputObs, sizeof(int *));
		ts->allMissV[m] = (int *) calloc(ts->maxInputObs, sizeof(int));
		for (i = 0; i < ts->maxInputObs; i++)
		{
			ts->missV[m][i] = (int *) calloc(ts->nIndep[m], sizeof(int));
		}
		if (ts->nExpos[m] > 0) ts->exposure[m] = allocMat2d(ts->maxInputObs, ts->nExpos[m]);
		ts->nZipParms[m] = 0;
		for (i = 0; i < ts->nIorder[m]; i++) ts->nZipParms[m] += (int)ts->iorder[m][i] + 1;
	}
	itemp = MAX(ts->nOrders[0], ts->nOrders[1]);
	itemp = MAX(itemp, ts->nMultGroups);
	ts->group_percent = (double *) calloc(itemp, sizeof(double)) ;	
	ts->writeObs = (int *) calloc(ts->maxInputObs, sizeof(int));
	ts->obsmar = (int *) calloc(ts->maxInputObs, sizeof(int));
	ts->oos = (int *) calloc(ts->maxInputObs, sizeof(int));
	ts->weight = (double *) calloc(ts->maxInputObs, sizeof(double));
	ts->skip = (int *) calloc(ts->maxInputObs, sizeof(int));
	ts->outc = (double *) calloc(ts->maxInputObs, sizeof(double));
	ts->outcLk = (double *) calloc(ts->maxInputObs, sizeof(double));
	if (!ts->obsmarStmt) for (i = 0; i < ts->maxInputObs; i++) ts->obsmar[i] = 0;
	if (!ts->weightStmt) for (i = 0; i < ts->maxInputObs; i++) ts->weight[i] = 1.;
	for (i = 0; i < ts->maxInputObs; i++)	ts->skip[i] = 0;
	ts->totalParms = 0;
	for (m = 0; m < ts->nModels; m++)
	{		
		if ((int)ts->order[m][0] == -1) ts->all0Group[m] = 1;
		for (i = 0; i < ts->nOrders[m]; i++) 
			ts->nModelParm[m] += (int)ts->order[m][i] + 1 + 
				((int)ts->order[m][i] + 1 > 0) * ts->nTcovParms[m]; 
		if (ts->dropoutStmt[m] && m < 2) 
		{
			ts->nModelParm[m] += (int)ts->dOrd[m][0] + 1;
			if (ts->dcovStmt[m] && (int)ts->dOrd[m][0] != -1) ts->nModelParm[m] += ts->nDcovPrm[m];
			if (ts->nDropout[m] > 1)
				for (i = 1; i < ts->nDropout[m]; i++)
				{
					ts->nModelParm[m] += (int)ts->dOrd[m][i] + 1;
					if (ts->dcovStmt[m] && (int)ts->dOrd[m][i] != -1) ts->nModelParm[m] += ts->nDcovPrm[m];
				}
		}
		if (ts->iorderStmt[m]) 
		{
			ts->nModelParm[m] += (int)ts->iorder[m][0] + 1;
			if (!ts->commonIorder[m])
				for (i = 1; i < ts->nIorder[m]; i++) 
					ts->nModelParm[m] += (int)ts->iorder[m][i] + 1;
		}
		if (ts->modelType[m] == m_cnorm) 
		{
			ts->nModelParm[m] += ts->ar1 ? 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[m] - 1) :
								           1 + ts->sigmaByGroup * (ts->nOrders[m] - 1 - ts->all0Group[m]);
		}
		if (ts->modelType[m] == m_zibeta) ts->nModelParm[m] += (int)ts->nOrders[m];
		ts->totalParms += ts->nModelParm[m];
	}
	ts->nRorderPrm = 0;
	if (ts->rorderStmt[0])
	{
		ts->commonRorder[0] = ts->nRorder[0] == 1 ? 1 : 0;
		if (ts->commonRorder[0]) 
			for (i = 1; i < ts->nOrders[0]; i++) ts->rorder[0][i] = ts->rorder[0][0];
		ts->nRorderPrm = (int)ts->rorder[0][0] + 1;
		if (!ts->commonRorder[0])
			for (i = 1; i < ts->nOrders[0]; i++) ts->nRorderPrm += (int)ts->rorder[0][i] + 1;
	}
	switch (ts->likelihoodType) 
	{
		case MULTI:
			ts->multRiskOffset = ts->totalParms; 
			ts->totalParms += (ts->nMultGroups - 1) * (ts->nMultRisk + 1);
			ts->outcOffset = ts->totalParms;
			ts->totalParms += ts->nOutcPrm[0];
			break;
		case JOINT: ts->nModelParm[1] += ts->nOrders[0] * (ts->nOrders[1] - 1) + (ts->nOrders[1] - 1) * ts->nRisk[1];
		case SINGLE: 
			ts->nModelParm[0] += (ts->nOrders[0] - 1) * (ts->nRisk[0] + 1);
			ts->nModelParm[0] += ts->nRorderPrm;
			ts->outcOffset = ts->nModelParm[0];
			ts->jointOffset = ts->outcOffset + ts->nOutcPrm[0];
			ts->nModelParm[0] += ts->nOutcPrm[0];
			ts->totalParms = ts->nModelParm[0] + ts->nModelParm[1];
			break;
	}
	return 0;
}

double** allocMat2d(int rows, int cols)
{
	int i;
	double** mat;

	mat = calloc(rows, sizeof(double*));
	for (i = 0; i < rows; i++) mat[i] = calloc(cols, sizeof(double));
	return mat;
}

char** allocMat2dc(int rows, int cols)
{
	int i;
	char** mat;

	mat = calloc(rows, sizeof(char*));
	for (i = 0; i < rows; i++) mat[i] = calloc(cols, sizeof(char));
	return mat;
}

double*** allocMat3d(int rows, int cols, int dim3)
{
	int i, j;
	double*** mat;

	mat = calloc(rows, sizeof(double**));
	for (i = 0; i < rows; i++)
	{
		mat[i] = calloc(cols, sizeof(double*));
		for (j = 0; j < cols; j++) mat[i][j] = calloc(dim3, sizeof(double));
	}
	return mat;
}
