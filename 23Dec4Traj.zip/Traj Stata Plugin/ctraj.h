/* 
	main header Stata traj plugin	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/
#define _CRT_SECURE_NO_WARNINGS

#define ABSEPS		0.00005
#define LKTYPES		2		/* storage of single and multi or joint (two-d) */
#define MAXMODELS	6		/* max number of mult models */
#define MAXGROUPS	24
#define MAXLEVELS	16
#define RMAX		2		/* allow up to random quadratic */
#define SASPROC 	1 
#define FALSE		0	  
#define TRUE		1
#define NMAX		16
#define NUM_THREADS 8

/* Probabiltity Model - modelType */
#define m_none		0
#define m_cnorm		1  
#define m_logit		2
#define m_zip		3
#define m_zibeta	4
#define m_mlogit	5

/* Model Subtypes */
#define MIXEDMODEL	1
#define AR1			2

/* Stata option types	*/
#define SS_INTEGER	2
#define SS_REAL		3
#define SS_STRING	4

/* Likelihood Type - likelihoodType */
#define	SINGLE		0
#define	JOINT		1
#define	MULTI		2

#define _USE_MATH_DEFINES

#include <string.h>
#include <stdlib.h>  
#include <stdio.h> 
#include <math.h>   
#include <float.h>
#include <time.h>
#include "lbfgsb.h"
#include "stplugin.h"

#define DEFLTMIN	-3.
#define MAXEXP		700.  
#define MAXEXPIT	700.
#define FMIN(x,y)	(((double)x)<((double)y) ? ((double)x) : ((double)y))
#define FMAX(x,y)	(((double)x)<((double)y) ? ((double)y) : ((double)x))
#define MIN(x,y)	(((int)x)<((int)y) ? ((int)x) : ((int)y))
#define MAX(x,y)	(((int)x)<((int)y) ? ((int)y) : ((int)x))
#define logit(x)	log(x * pow(1. - x, -1.))

#define RSQRT2PI	0.398942280401432677939946059934	/* 1 / sqrt(2*pi) */
#define MACEPS		2.220446E-16	/* DBL_EPSILON */	
#define M_LN_SQRT_2PI   0.918938533204672741780329736406  
#define SAS_XPSLOG	printf
#define MACMISSING	SV_missval
#define IS_MISSING	SF_is_missing	
#define XEXITSYNTAX 0
#define XEXITERROR  0
#define XEXITNORMAL 0
#define WRITELOG(...) {sprintf(buf, __VA_ARGS__); SF_display(buf);}
#define WRITEERR(...) {sprintf(buf, __VA_ARGS__); SF_error(buf); return((ST_retcode) 199);} 

struct	TRAJSTRUCT   
{
	char	**dcovNames[MAXMODELS],
			**multRiskNames,
			*outestVarName, 
			**ocovNames[MAXMODELS],
			**riskNames[MAXMODELS], 
			**tcovNames[MAXMODELS];

	int		all0Group[MAXMODELS],
			*allMissV[MAXMODELS],
			altstart,
			ar1,
			*B_boundtype,
			bicnobs,
			nPrUpdt,
			commonIorder[MAXMODELS],
			commonRorder[MAXMODELS],
			completeDataLen[2],
			jointOffset,
			*dataStartTime[MAXMODELS],
			dcovStmt[MAXMODELS],
			dLoc[MAXMODELS],
			dropoutStmt[MAXMODELS],
			*dropoutTime[MAXMODELS],
			exposStmt[MAXMODELS],
			iflt,
			*indepCount[MAXMODELS],
			indepStmt[MAXMODELS],
			*intlimit,
			iorderStmt[MAXMODELS],
			irnd,
			iseed,
			itdetail,
			*iv,
			*iv_outc,
			*iwa,
			*iwork,
			likelihoodType,
			liv_outc,
			lowerStmt,
			lv_outc,
			mdl,
			modelStmt[MAXMODELS],
			modelSubtype[MAXMODELS],
			modelType[MAXMODELS],
			multModel,
			multRiskOffset,
			multRiskStmt,
			nderiv,
			noprint,
			nData,
			nDcov[MAXMODELS], 
			nDcovPrm[MAXMODELS], 
			nDropout[MAXMODELS],
			nDropoutParms[MAXMODELS],
			nExpos[MAXMODELS],
			numGet, 
			nIndep[MAXMODELS],
			nIorder[MAXMODELS],
			maxInputObs,
			**missV[MAXMODELS], 
			no_var,
			numLowerVal,
			numModelObs,
			nModelParm[MAXMODELS],
			nModels,
			nMultGroups,
			nMultRisk,
			nObs,
			nObsmar,
			nOcov[MAXMODELS],
			nOutcPrm[MAXMODELS],
			nOOS,
			nOrders[MAXMODELS],
			nOutcLevels[MAXMODELS],
			nPlotTcov[MAXMODELS],
			nRisk[MAXMODELS],
			nRorderPrm,
			nRorder[MAXMODELS],
			numStartVal,
			nTcov[MAXMODELS], 
			nTcovParms[MAXMODELS],
			numUpperVal,
			nWeight,
			nZipParms[MAXMODELS],
			*obsmar,
			obsmarStmt,
			ocovStmt[MAXMODELS],
			omittedCaseCount,
			*oos,
			oosStmt,
			orderStmt[MAXMODELS],
			outcOffset,
			outc_iflt,
			*outc_iwa,
			outcMaxStmt[MAXMODELS],
			outcMinStmt[MAXMODELS], 
			outcModelType[MAXMODELS],
			outcStmt[MAXMODELS],
			plotTcovStmt[MAXMODELS],
			probupdates,
			probUpdateWaves,
			referenceGroupStmt[LKTYPES],
			rhoByGroup, 
			riskOffset[MAXMODELS],
			riskStmt[MAXMODELS],
			rorderOffset,
			rorderStmt[MAXMODELS],
			sigmaByGroup,
			*skip,
			startStmt,
			stataOutputVarsPtr,
			tcovStmt[MAXMODELS],
			totalParms,
			trace,
			twoStep,
			upperStmt,
			vstOs,
			weightStmt,
			scoreCIOpt,
			*writeObs,
			zipParmOffset[MAXMODELS]; 

	double	*averageIndep[MAXMODELS], 
			baseOutc[MAXMODELS],			
			*B_lower,
			*B_upper,
			*cholWork,
			classifiedGroup[LKTYPES],
			classifiedGroup_T[LKTYPES],
			convergenceTol,
			*covCholMatrix,
			*covCholWork,
			*covCholDiag,
			**dcov[MAXMODELS],
			**dep[MAXMODELS], 
			dOrd[MAXMODELS][MAXGROUPS],
			**dropoutProb[MAXMODELS],
			**dropoutSumByGroupTime[MAXMODELS],
			**dropoutCountByGroupTime[MAXMODELS],
			**exposure[MAXMODELS],
			**expectedTrajByGroupTime[MAXMODELS],
			*group_percent,
			*groupProb[MAXMODELS+1],
			*groupProbSum[LKTYPES],
			**groupProbSum_T[LKTYPES],
			*g_save1,
			*g_save2,
			*hessian,
			*hpi,
			*hw, 
			*hw2,
			**indep[MAXMODELS],
			iorder[MAXMODELS][MAXGROUPS],
			**linkfMeanMlogitOutc,
			*linkfMeanOutc, 
			mdlFit[5],
			**meanMlogitOutc, 
			**meanMlogitOutcL95,
			**meanMlogitOutcU95,
			*meanOutc, 
			*meanOutcL95,
			*meanOutcU95,
			*mlogitOutcCIRslt,
			*mlogitOutcLevel[MAXMODELS],
			**mlogitOutcProb[MAXMODELS],
			***mlogitOutcProb_T[MAXMODELS],
			*mlogitX,
			*multGroupProb,
			**multRisk,
			**obsDropoutLk[MAXMODELS],
			***obsJointTrajLk,
			**obsMultTrajLk,
			***obsMultTrajLk_T,
			**obsTrajLk[MAXMODELS],
			***obsTrajLk_T[MAXMODELS],
			*obsModelLk, 
			*obsMultModelLk,
			**ocov[MAXMODELS],
			order[MAXMODELS][MAXGROUPS],
			ostsg, 
			ostsg_2,
			*outc,
			*outc_hessian,
			*outcLk,
			outcMax[MAXMODELS], 
			outcMaxObserved[MAXMODELS], 
			outcMdlfit[3],
			outcMin[MAXMODELS],
			outcMinObserved[MAXMODELS],
			*outc_wa,
			*outcStart,
			*outcStdErr,
			*outestStart,
			*phi[MAXMODELS],
			*plotData[MAXMODELS],
			*plotTcov[MAXMODELS],
			**plotWork,
			**probOutc, 
			***probOutc_T, 
			*posteriorProb[LKTYPES],
			**posteriorProb_T[LKTYPES],
			*prdw,
			**probSumByGroupTime[MAXMODELS],
			*pv_2, 
			*pv_jk,
			referenceGroup[LKTYPES],
			*rho[MAXMODELS],
			**risk[MAXMODELS],
			rorder[MAXMODELS][MAXGROUPS],
			*saveHessian,
			*score,
			*sigma[MAXMODELS],
			*sigmaSq[MAXMODELS],
			*simtrx1,
			*simtrx2,
			*smtrx,
			*smtrxC,
			*smtrx11,
			*smtrx12,
			*smtrx21,
			*smtrx22,
			*start,
			*initVal,
			startRho[MAXMODELS],
			startSigma[MAXMODELS],
			*stdErr,
			**tcov[MAXMODELS],
			*v,
			*v_outc,
			*V,									
			***varDropoutLk[MAXMODELS],
			***varGradient[MAXMODELS],
			**varianceSum[MAXMODELS],
			**varSumByGroupTime[MAXMODELS],
			varMax[MAXMODELS], 
			varMaxObserved[MAXMODELS], 
			varMin[MAXMODELS], 						
			varMinObserved[MAXMODELS], 
			***varTrajLk[MAXMODELS],
			*vr,
			*wa,
			*weight,
			*wgt,
			*worknp,
			*workrslt,
			*xprod,
			*ymxb1, 
			*ymxb2,
			*zmtrx1,
			*zmtrx2;
};

void	adjustStartValues(int *, void *);
int		adjustMultStartValues(int *, void *);
char**	allocMat2dc(int, int); 
double**	allocMat2d(int, int);
double***	allocMat3d(int, int, int);
void	betaChainRule(int, int*, int*, int*, int*, double*, int*, double*, void*);
void	calcClassifications(int *, void *);
void	calcClassUpdates(int *, void *);
void	calcGroupProb(int, int, double **, double *, void *);
int		calcMLE_(int *, double *, double *, 
				int (*)(int, double *, double *, void *),
				int (*)(int, double *, int *, double *, void *), int *, int *, int *, double *, void *);
int		calcMLE_no_derivative_(int *, double *, double *, 
				int (*)(int, double *, double *, void *), int *, int *, int *, double *, void *);
void	MVN_Pr_(int *, double *, double *, int *, double *,
			int *, double *, double *, double *, double *, int *, int *, void *);
void	calcs(void *);							
int		ciOpt_snorm(int *, double *);
void	cnormAR1nll(double *, void *);
void	cnormChainRule(int, int*, int*, int*, int*, double*, int*, double *, void *);
void	cnormMixednll(double *, void *);
int		cmpDbl(const void *, const void *);
void	componentnll(int, double *, void *);
void	defaultStart(void *);
int		deflt_(int *, int *, int *, int *, double *);
int		dgedi_(double *, int *, int *, int *, double *, double *, int *);
int		dgefa_(double *, int *, int *,int *, int *);
int		dgemm_(char *, char *, int *, int *, int *, double *, double *, int *,
			   double *, int *, double *, double *, int *);
void	dropoutChainRule(int, int*, int*, int*, double *, int*, int*, double *, void *);
double	dropoutLk(int*, int*, int*, double*, int*, int*, void*);
void	expectedOutc(int *, int, int *, void *, int);
void	expectedTraj(int*, double*, double*, double*, double*, void*);
void	freeMat2d(int, double**);
void	freeMat2dc(int, char**);
void	freeMat3d(int, int, double***);
int		getStataData(void *);
void	getStataVar(int, int, int*, int*, double*, double**, int*);
int		jointModelDerivative(int, double *, int *, double *, void *);
int		jointModelnll(int, double *, double *, void *);
void	logitChainRule(int, int*, int*, int*, int*, double*, int*, double*, void*);
void	logitCI(double, double, double *);
int		mlogitCI_Moments(double *, double *, double *, void *);
void	mlogitCI(double *, void *);
void	mlogitDeltaMethod(int, int, void*);
int		multModelnll(int, double *, double *, void *);
int		multModelDerivative(int, double *, int *, double *, void *);
int		multTrajStataOutput(void *);
void	outc_nll_1S(double*, void*);
int		outc_nll_2S(int , double *, double *, void *);
int		outcDeriv2S(int, double *, int *, double *, void *);
void	parmPositions(void *);
void	parmTransform(void *);
int		printParmsToLog(int, int, double *, int, void *);
int		returnResultsToStata(void *);
void	scoreCI(double*, void*);
int		sharedStataOutput(int, void *);
int		sgrad2_(double *, double *, double *, double *, double *, int *, int *, double *, double *);
int		singleModelDerivative(int, double *, int *, double *, void *);
int		singleModelnll(int, double *, double *, void *);
int		tprob(double, int, double *);
int		trajInitStata(void *);
int		traceOutput(char *, int, double *);
void	trajCleanUpStata(void *);
int		trajStataOutput(void *);
int		validateInput(struct TRAJSTRUCT);
void	writeOutc(void *);
void	writeParmLine(int, int, int, double, double, char *);
void	zipChainRule(int, int*, int*, int*, int*, double*, int*, double*, void*);
double	_kf_gammap(double s, double z);
double	kf_gammap(double s, double z);
double	ppois(double *, double *);
double	alogam(double, int *);
double	dbeta(double *, double *, double *, double *, int);
double	digamma(double, int *);
double	dnorm(double *, double *, double *);
double  invlogit(double);
double	linPred(double*, double*, int*, int*, int*, double*, int*, double*);
double	mvnphi_(double*);
double	mvnuni_();
double	randu_(int *);
double	sdot_(int *, double *, int *, double *, int *);
double	truncpoi(double, double, void *);
void	chol(double *, int, double *, int *);
