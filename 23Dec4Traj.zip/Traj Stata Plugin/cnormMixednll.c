/*	
	cnorm mixed effects model	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"                    

void cnormMixednll(double *prm, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	char	buf[90], ta = 'N', tb = 'N';
	int		iseed=123, i, iC, iNC, j, jj, k, r, r2, r_os, iflt, itp, i_1 = 1, im, nrep, nrf, nc, os;
	double	aeps = ABSEPS, d_1 = 1., d_0 = 0., det2[2], dtr2, err, G[(RMAX + 1) * (RMAX + 1)],
			rlp = 0., *tcovPtr, vl, x, xb = 0.;

	nrep = 5000 * (int)pow((double)ts->nIndep[0], 3.);
	r_os = ts->rorderOffset;
	for (k = 0; k < ts->nOrders[0]; k++) 
		ts->sigma[0][k] = (ts->sigmaByGroup) ? exp(prm[ts->rorderOffset - ts->nOrders[0] + k]): 
											   exp(prm[ts->rorderOffset - 1]);
	os = 0;
	for (k = 0; k < ts->nOrders[0]; k++)
	{
		for (jj = 0; jj < (RMAX + 1) * (RMAX + 1); jj++) G[jj] = 0.;
		if (ts->commonRorder[0]) 
		{
			nrf = (int)ts->rorder[0][0] + 1;
			for (jj = 0; jj < nrf; jj++) G[jj + jj * nrf] = pow(exp(prm[r_os + jj]), 2);
		} 
		else 
		{
			nrf = (int)ts->rorder[0][k] + 1;
			for (i = 0; i < nrf; i++) G[i + i * nrf] = pow(exp(prm[r_os + i]), 2);
			r_os += nrf;
		}
		for (i = 0; i < ts->nObs; i++) 
		{
			ts->obsTrajLk[0][k][i] = 1.;				
			if (ts->skip[i] || ts->allMissV[0][i]) continue;
			tcovPtr = 0;
			if (ts->nTcov[0] > 0) tcovPtr = ts->tcov[0][i];
			iC = iNC = 0;
			for (j = 0; j < ts->nIndep[0]; j++)
			{
				if (ts->missV[0][i][j]) continue;
				xb = linPred(prm, &ts->indep[0][i][j], &os, &j, &ts->nIndep[0], 
							 &ts->order[0][k], &ts->nTcovParms[0], tcovPtr);
				/* iC indexes censored data, iNC indexes uncensored data */
				if (ts->dep[0][i][j] <= ts->varMin[0]) 
				{
					ts->ymxb1[iC] = ts->varMin[0] - xb;
					if (nrf > 0) 
					{
						ts->zmtrx1[iC * nrf] = 1.;			
						for (jj = 1; jj < nrf; jj++) 
							ts->zmtrx1[iC * nrf + jj] = pow(ts->indep[0][i][j], jj);
					}
					ts->intlimit[iC] = 0;
					iC++;
				} 
				else if (ts->dep[0][i][j] < ts->varMax[0]) 
				{
					ts->ymxb2[iNC] = ts->dep[0][i][j] - xb;
					if (nrf > 0) 
					{
						ts->zmtrx2[iNC * nrf] = 1.;
						for (jj = 1; jj < nrf; jj++) 
							ts->zmtrx2[iNC * nrf + jj] = pow(ts->indep[0][i][j], jj);
					}
					iNC++;
				} 
				else 
				{
					ts->ymxb1[iC] = ts->varMax[0] - xb;
					if (nrf > 0) 
					{
						ts->zmtrx1[iC * nrf] = 1.;
						for (jj = 1; jj < nrf; jj++)
							ts->zmtrx1[iC * nrf + jj] = pow(ts->indep[0][i][j], jj);
					}
					ts->intlimit[iC] = 1;
					iC++;
				}
			}
			for (j = iC; j < iC + iNC; j++) 
			{
				ts->ymxb1[j] = ts->ymxb2[j - iC];				
				if (nrf > 0) 
				{
					ts->zmtrx1[j * nrf] = 1.;		
					for (jj = 1; jj < nrf; jj++)
						ts->zmtrx1[j * nrf + jj] = ts->zmtrx2[(j - iC)* nrf + jj];
				}
			}
			nc = iC + iNC;
			/*	zmtrx2 = GZ' */
			if (nrf > 0 && nc > 0) 
			{
				dgemm_(&ta, &tb, &nrf, &nc, &nrf, &d_1, G, &nrf,
					ts->zmtrx1, &nrf, &d_0, ts->zmtrx2, &nrf);
				ta = 'T'; 
				/*   calc ZGZ' -> sm */
				dgemm_(&ta, &tb, &nc, &nc, &nrf, &d_1, ts->zmtrx1,
					&nrf, ts->zmtrx2, &nrf, &d_0, ts->smtrx, &nc);
				for (jj = 0; jj < nc; jj++)
					ts->smtrx[jj * nc + jj] += ts->sigma[0][k] * ts->sigma[0][k];
			} 
			else 
			{
				for (jj = 0; jj < nc * nc; jj++) ts->smtrx[jj] = 0.;
				/*	sg is I*sgsq + R */
				for (jj = 0; jj < nc; jj++)
					ts->smtrx[jj * nc + jj] += ts->sigma[0][k] * ts->sigma[0][k];
			}
			/*	uncensored */
			if (iNC > 0) 
			{
				for (jj = iC; jj < iC + iNC; jj++) {
					for (r = iC; r < iC + iNC; r++) {
						ts->simtrx2[(jj - iC)* iNC + (r - iC)] = ts->smtrx[jj * nc + r];
					}
				}
				dgefa_(ts->simtrx2, &iNC, &iNC, ts->iwork, &iflt);
				if (iflt != 0) 
				{
					WRITELOG("Obs %d problem code %d\n", i+1, iflt);
					goto  L100;
				} 
				else 
				{
					itp = 11;
					/* inv (in smiNC) and det (ymxb2 as work) */
					dgedi_(ts->simtrx2, &iNC, &iNC, ts->iwork, det2, ts->ymxb2, &itp);
				}
				dtr2 = det2[0] * pow(10., det2[1]);
				if (dtr2 <= 0.) 
				{
					WRITELOG("Obs %d problem inverting: %f\n", i+1, dtr2);
					goto  L100;
				}
			}
			/* f_censored(y=min,y=max | min<y<max) 1=C, 2=NC
			conditional mean given unc	smtrx11 = sg12*sg22 inv, ymxb2 = smtrx11 * (y[unc]-xb)
			conditional variance		smtrx11 = s11 - simtrx1 = s12*s22 inv * s21 */
			if (iC > 0 && iNC > 0) 
			{
				for (jj = iC; jj < iC + iNC; jj++) 
					for (r = 0; r < iC; r++) 
						ts->smtrx21[(jj - iC)* iC + r] = ts->smtrx[jj * nc + r];
				for (jj = 0; jj < iC; jj++) 
				{
					for (r = 0; r < iNC; r++) 
					{
						ts->smtrx11[jj * iNC + r] = 0.;
						for (r2 = 0; r2 < iNC; r2++) 
							ts->smtrx11[jj * iNC + r] += ts->smtrx21[r2 * iC + jj] *
							  						     ts->simtrx2[r * iNC + r2];
					}
				}
				for (jj = 0; jj < iC; jj++) 
				{
					ts->ymxb2[jj] = 0.;
					for (r2 = 0; r2 < iNC; r2++) 
						ts->ymxb2[jj] += ts->smtrx11[jj * iNC + r2] * ts->ymxb1[iC + r2];
				}
				for (jj = 0; jj < iC; jj++) 
				{
					for (r = 0; r < iC; r++) 
					{
						ts->simtrx1[jj * iC + r] = 0.;
						for (r2 = 0; r2 < iNC; r2++)
							ts->simtrx1[jj * iC + r] += ts->smtrx11[r * iNC + r2] *
														ts->smtrx21[r2 * iC + jj];
					}
				}
				for (jj = 0; jj < iC; jj++)
					for (r = 0; r < iC; r++)
						ts->smtrx11[jj * iC + r] = ts->smtrx[jj * nc + r] - 
												   ts->simtrx1[jj * iC + r];
				for (jj = 0; jj < iC; jj++)
					for (r = 0; r < iC; r++)
						ts->smtrx12[jj * iC + r] = ts->smtrx11[jj * iC + r];
				for (jj = 0; jj < iC; jj++)
					for (r = 0; r < iC; r++)
						ts->simtrx1[jj * iC + r] = ts->smtrx11[jj * iC + r];
				for (jj = 0; jj < iC; jj++)
					for (j = 0; j < jj; j++)
						ts->smtrx12[j + (jj - 1)* jj / 2] =
							ts->simtrx1[j * iC + jj] *
							pow(fabs(ts->simtrx1[jj * iC + jj]), -.5) *
							pow(fabs(ts->simtrx1[j * iC + j]), -.5);				
				for (jj = 0; jj < iC; jj++) 
				{
					ts->ymxb2[jj] *= -1. * pow(fabs(ts->simtrx1[jj * iC + jj]), -.5);
					ts->ymxb2[jj] += ts->ymxb1[jj] * pow(fabs(ts->simtrx1[jj * iC + jj]), -.5);
				}
				MVN_Pr_(&iC, ts->ymxb2, ts->ymxb2, ts->intlimit,
						ts->smtrx12, &nrep, &aeps, &rlp, &err, &vl, &im, &iseed, qi);
				if (im != 0) 
				{
					WRITELOG("obs %d mvn err\n", i+1);
					goto  L100;
				}
				ts->obsTrajLk[0][k][i] = vl;
			}
			/* all censored */
			if (iC > 0 && iNC == 0) 
			{
				for (jj = 0; jj < iC; jj++)
					for (r = 0; r < iC; r++)
						ts->simtrx1[jj * iC + r] = ts->smtrx[jj * nc + r];
				for (jj = 0; jj < iC; jj++)
					for (j = 0; j < jj; j++)
						ts->smtrx12[j + (jj - 1)* jj / 2] =
							ts->simtrx1[j * iC + jj] * 
							pow(fabs(ts->simtrx1[jj * iC + jj]), -.5) * 
							pow(fabs(ts->simtrx1[j * iC + j]), -.5);
				for (jj = 0; jj < iC; jj++) 
					ts->ymxb2[jj] = (ts->ymxb1[jj] - ts->ymxb2[jj]) * 
									pow(fabs(ts->simtrx1[j * iC + j]), -.5);
				MVN_Pr_(&iC, ts->ymxb2, ts->ymxb2, ts->intlimit,
						ts->smtrx12, &nrep, &aeps, &rlp, &err, &vl, &im, &iseed, qi);
				if (im != 0) 
				{
					WRITELOG("obs %d cnorm mixed model mvn prob err\n", i+1);
					goto L100;
				}
				ts->obsTrajLk[0][k][i] = vl;
			}
			/* all uncensored, pr = unconditional probability */
			/* mixed, pr = conditional pr(C|NC) from above * unconditional pr */
			if (iNC > 0) 
			{
				dgemm_(&ta, &tb, &iNC, &i_1, &iNC, &d_1, ts->simtrx2, &iNC, ts->ymxb1 + iC, &iNC,
					   &d_0, ts->ymxb2, &iNC);
				x = sdot_(&iNC, ts->ymxb1 + iC, &i_1, ts->ymxb2, &i_1);
				ts->obsTrajLk[0][k][i] *= pow(RSQRT2PI, iNC) * pow(dtr2, -.5) * exp(-.5 * x);
			}
		}
	L100:;
		os += (int)ts->order[0][k] + 1 + ((int)ts->order[0][k] + 1 > 0) * ts->nTcovParms[0];
	}
}
