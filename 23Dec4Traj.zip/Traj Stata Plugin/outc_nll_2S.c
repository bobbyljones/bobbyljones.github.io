/* 
	Distal outcome nll - 2S
	Weighted GLM [weight = P(group)] ~ outcome covariates
	No overall intercept model.

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include	 "ctraj.h"
		
int  outc_nll_2S(int n, double *prm, double *fx, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		gp, ifault=0, j, jj, L, los, obs,
			wrkOS;		/* work offset for position calculations */
	double	d1, lmb, **trajLk, mu, oSg, tmp;
	char	buf[90];
	
	if(ts->trace) traceOutput("outc nll 2S", n, prm);
	*fx = 0.;
	trajLk = ts->obsTrajLk[0];
	if (ts->likelihoodType == MULTI) trajLk = ts->obsMultTrajLk;
	if (ts->outcModelType[0] == m_cnorm) 
	{
		wrkOS = ts->nOrders[0] + ts->nOcov[0];
		oSg = exp(prm[wrkOS]);
	}
	for (obs = 0; obs < ts->nObs; obs++)
	{
		ts->outcLk[obs] = 0.;
		if (ts->skip[obs]) continue;
		for (j = 0; j < ts->nOrders[0]; j++)
		{
			if (ts->outcModelType[0] != m_mlogit)
			{
				wrkOS = j;
				mu = prm[wrkOS];
				if (ts->nOcov[0] > 0)
				{
					for( jj = 0; jj < ts->nOcov[0]; jj++ ) 
						mu += prm[ts->nOrders[0] + jj] * ts->ocov[0][obs][jj];
				}
			}	
			switch( ts->outcModelType[0] ) 
			{
				case m_cnorm:				
					ts->outcLk[obs] += trajLk[j][obs] * dnorm( &ts->outc[obs], &mu, &oSg );
					break;
				case m_logit:
					ts->outcLk[obs] += ts->outc[obs] == 0. ?
				 		trajLk[j][obs] * (1. - invlogit(mu)) : 
						trajLk[j][obs] * invlogit(mu);
					break;
				case m_mlogit:
					los = 0; 
					d1 = mu = 0.;
					for( L = 0; L < ts->nOutcLevels[0]; L++ )
					{
						ts->mlogitOutcProb[0][obs][L] = 0.;
						if( (int)ts->mlogitOutcLevel[0][L] == (int)ts->baseOutc[0] )
						{	
							ts->mlogitOutcProb[0][obs][L] = trajLk[L][obs];
							d1 += ts->mlogitOutcProb[0][obs][L];
						} 
						else 
						{													
							for( gp = 0; gp < ts->nOrders[0]; gp++ )
							{
								wrkOS = gp * (ts->nOutcLevels[0] - 1) + los;
								mu = prm[wrkOS];
								if( ts->nOcov[0] > 0 )
								{
									for( jj = 0; jj < ts->nOcov[0]; jj++ )
										mu += prm[ts->nOrders[0] * (ts->nOutcLevels[0] - 1) +
											  los * ts->nOcov[0] + jj] * ts->ocov[0][obs][jj];
								}
								ts->mlogitOutcProb[0][obs][L] += exp(mu) * trajLk[gp][obs];
							}
							d1 += ts->mlogitOutcProb[0][obs][L];		
							los++;
						}	
					}
					for( L = 0; L < ts->nOutcLevels[0]; L++ )
					{
						ts->mlogitOutcProb[0][obs][L] /= d1;
						if( (int)ts->outc[obs] == (int)ts->mlogitOutcLevel[0][L] )
							ts->outcLk[obs] = ts->mlogitOutcProb[0][obs][L];
					}
					break;
				case m_zip:
					lmb = exp(mu);
					if( ts->outc[obs] == 0. )
					{
						ts->outcLk[obs] += trajLk[j][obs] * exp(-lmb);
					}
					else
					{
						tmp = -lmb + ts->outc[obs] * log(lmb) -
							   alogam(ts->outc[obs] + 1., &ifault);
						ts->outcLk[obs] += trajLk[j][obs] * exp(tmp);
					}
					break;		
			}
		}
		if( ts->outcLk[obs] > DBL_MIN )
		{
			*fx -= ts->oos[obs] || ts->skip[obs] ? 0. : log ( ts->outcLk[obs] );
		}
		else 
		{
			*fx = DBL_MAX;
			goto L999;
		}
	}
L999:
	if( ts->trace ) WRITELOG ("outc model twostep - nll = %12.5e\n", *fx);
	return 0;
}
