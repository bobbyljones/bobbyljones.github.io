#include "ctraj.h"
char   buf[80];
int calcMLE_(int *n,double *d,double *x,int (*calcf)(int,double *, double *, void *),
	int (*calcg)(int,double *,int *,double *,void *),int *iv,int *liv,int *lv,double *v,  
	void *info)
{
	static int c__2 = 2;
    static int nextv = 47;
    static int nfcall = 6;
    static int nfgcal = 7;
    static int g = 28;
    static int toobig = 2;
    static int vneed = 4;
    int i_1;
    static double f;
    static int g1;
    static int nf,np, iv1;
	extern int sumit_();
	--d;
    --x;
    --iv;
    --v;
	np=*n; 

/*  ***  MINIMIZE GENERAL UNCONSTRAINED OBJECTIVE FUNCTION USING   *** */
/*  ***  ANALYTIC GRADIENT AND HESSIAN APPROX. FROM SECANT UPDATE  *** */
/*       DIMENSION V(71 + N*(N+15)/2)  */
/*     THIS ROUTINE INTERACTS WITH SUBROUTINE  SUMIT  IN AN ATTEMPT */
/*     TO FIND AN N-VECTOR  X*  THAT MINIMIZES THE (UNCONSTRAINED) */
/*     OBJECTIVE FUNCTION COMPUTED BY  CALCF. */

/* N........ (INPUT) THE NUMBER OF VARIABLES ON WHICH  F  DEPENDS, I.E.,*/
/*                  THE NUMBER OF COMPONENTS IN  X. */
/* D........ (INPUT/OUTPUT) A SCALE VECTOR SUCH THAT  D(I)*X(I), */
/*                  I = 1,2,...,N,  ARE ALL IN COMPARABLE UNITS. */
/*                  D CAN STRONGLY AFFECT THE BEHAVIOR. */
/*                  FINDING THE BEST CHOICE OF D IS GENERALLY A TRIAL- */
/*                  AND-ERROR PROCESS.  CHOOSING D SO THAT D(I)*X(I) */
/*                  HAS ABOUT THE SAME VALUE FOR ALL I OFTEN WORKS WELL.*/
/*                  THE DEFAULTS PROVIDED BY SUBROUTINE DEFLT (SEE IV */
/*                  BELOW) REQUIRE THE CALLER TO SUPPLY D. */
/* X........ (INPUT/OUTPUT) BEFORE INITIAL CALL THE CALLER */
/*                  SHOULD SET X TO AN INITIAL GUESS AT X*. */
/*                  ON RETURN, X  CONTAINS THE BEST POINT SO FAR */
/*                  FOUND, I.E., THE ONE THAT GIVES THE LEAST VALUE SO */
/*                  FAR SEEN FOR  F(X). */
/* CALCF.... (INPUT) A SUBROUTINE THAT, GIVEN X, COMPUTES F(X).  CALCF */
/*                  MUST BE DECLARED EXTERNAL IN THE CALLING PROGRAM. */
/*                  IT IS INVOKED BY */
/*                       CALL CALCF(N, X, NF, F, UIPARM, URPARM, UFPARM)*/
/*                  NF IS THE INVOCATION COUNT FOR CALCF.  IT IS INCLUD-*/
/*                  ED FOR POSSIBLE USE WITH CALCG.  IF X IS OUT OF */
/*                  BOUNDS (E.G., IF IT WOULD CAUSE OVERFLOW IN COMPUT- */
/*                  ING F(X)), THEN CALCF SHOULD SET NF TO 0.  THIS WILL*/
/*                  CAUSE A SHORTER STEP TO BE ATTEMPTED.  THE OTHER */
/*                  PARAMETERS ARE AS DESCRIBED ABOVE AND BELOW.  CALCF */
/*                  SHOULD NOT CHANGE N, P, OR X. */
/* CALCG.... (INPUT) A SUBROUTINE THAT, GIVEN X, COMPUTES G(X), THE GRA-*/
/*                  DIENT OF F AT X.  CALCG MUST BE DECLARED EXTERNAL IN*/
/*                  THE CALLING PROGRAM.  IT IS INVOKED BY */
/*                       CALL CALCG(N, X, NF, G, UIPARM, URPARM, UFAPRM)*/
/*                  NF IS THE INVOCATION COUNT FOR CALCF AT THE TIME */
/*                  F(X) WAS EVALUATED.  THE X PASSED TO CALCG IS */
/*                  USUALLY THE ONE PASSED TO CALCF ON EITHER ITS MOST */
/*                  RECENT INVOCATION OR THE ONE PRIOR TO IT.  IF CALCF */
/*                  SAVES INTERMEDIATE RESULTS FOR USE BY CALCG, THEN IT*/
/*                  IS POSSIBLE TO TELL FROM NF WHETHER THEY ARE VALID */
/*                  FOR THE CURRENT X (OR WHICH COPY IS VALID IF TWO */
/*                  COPIES ARE KEPT).  IF G CANNOT BE COMPUTED AT X, */
/*                  THEN CALCG SHOULD SET NF TO 0.  IN THIS CASE, ROUTINE */
/*                  WILL RETURN WITH IV(1) = 65.  THE OTHER PARAMETERS */
/*                  TO CALCG ARE AS DESCRIBED ABOVE AND BELOW.  CALCG */
/*                  SHOULD NOT CHANGE N OR X. */
/* IV....... (INPUT/OUTPUT) AN int VALUE ARRAY OF LENGTH LIV (SEE */
/*                  BELOW) THAT HELPS CONTROL THE ALGORITHM AND */
/*                  THAT IS USED TO STORE VARIOUS INTERMEDIATE QUANTI- */
/*                  TIES.  OF PARTICULAR INTEREST ARE THE INITIALIZATION/*/
/*                  RETURN CODE IV(1) AND THE ENTRIES IN IV THAT CONTROL*/
/*                  PRINTING AND LIMIT THE NUMBER OF ITERATIONS AND FUNC-*/
/*                  TION EVALUATIONS.  SEE THE SECTION ON IV INPUT */
/*                  VALUES BELOW. */
/* V........ (INPUT/OUTPUT) A FLOATING-POINT VALUE ARRAY OF LENGTH LV */
/*                  (SEE BELOW) THAT HELPS CONTROL THE ALGORITHM */
/*                  AND THAT IS USED TO STORE VARIOUS INTERMEDIATE */
/*                  QUANTITIES.  OF PARTICULAR INTEREST ARE THE ENTRIES */
/*                  IN V THAT LIMIT THE LENGTH OF THE FIRST STEP */
/*                  ATTEMPTED (LMAX0) AND SPECIFY CONVERGENCE TOLERANCES*/
/*                  (AFCTOL, LMAXS, RFCTOL, SCTOL, XCTOL, XFTOL). */
/* LIV...... (INPUT) LENGTH OF IV ARRAY.  MUST BE AT LEAST 60.  IF LIV */
/*                  IS TOO SMALL, THEN ROUTINE RETURNS WITH IV(1) = 15. */
/*                  IF LIV IS AT LEAST LASTIV (= 44), THEN THE MINIMUM */
/*                  ACCEPTABLE VALUE OF LIV IS STORED IN IV(LASTIV) */
/*                  WHEN ROUTINE RETURNS.  (THIS IS INTENDED FOR USE */
/*                  WITH EXTENSIONS THAT HANDLE CONSTRAINTS.) */
/* LV....... (INPUT) LENGTH OF V ARRAY.  MUST BE AT LEAST 77+N*(N+17)/2.*/
/*                  (AT LEAST 77+N*(N+17)/2 
/*                   IF LV IS TOO SMALL, THEN */
/*                  ROUTINE RETURNS WITH IV(1) = 16.  IF LIV IS AT LEAST */
/*                  LASTV (= 45), THEN THE MINIMUM ACCEPTABLE VALUE OF */
/*                  LV IS STORED IN IV(LASTV) WHEN ROUTINE RETURNS. */
/*  ***  IV INPUT VALUES (FROM SUBROUTINE DEFLT)  *** */
/* IV(1)...  ON INPUT, IV(1) SHOULD HAVE A VALUE BETWEEN 0 AND 14...... */
/*             0 AND 12 MEAN THIS IS A FRESH START.  0 MEANS THAT */
/*                  DEFLT(2, IV, LIV, LV, V) */
/*             IS TO BE CALLED TO PROVIDE ALL DEFAULT VALUES TO IV AND */
/*             V.  12 (THE VALUE THAT DEFLT ASSIGNS TO IV(1)) MEANS THE */
/*             CALLER HAS ALREADY CALLED DEFLT AND HAS POSSIBLY CHANGED */
/*             SOME IV AND/OR V ENTRIES TO NON-DEFAULT VALUES. */
/*             13 MEANS DEFLT HAS BEEN CALLED AND THAT ROUTINE (AND */
/*             SUMIT) SHOULD ONLY ALLOCATE STORAGE IN IV AND V. */
/*             14 MEANS THAT A STORAGE HAS BEEN ALLOCATED (E.G. BY A */
/*             CALL WITH IV(1) = 13) AND THAT THE ALGORITHM SHOULD BE */
/*             STARTED.  WHEN CALLED WITH IV(1) = 13, ROUTINE RETURNS */
/*             IV(1) = 14 UNLESS LIV OR LV IS TOO SMALL (OR N IS NOT */
/*             POSITIVE).  DEFAULT = 12. */
/* IV(INITH).... IV(25) TELLS WHETHER THE HESSIAN APPROXIMATION H SHOULD*/
/*             BE INITIALIZED.  1 (THE DEFAULT) MEANS SUMIT SHOULD */
/*             INITIALIZE H TO THE DIAGONAL MATRIX WHOSE I-TH DIAGONAL */
/*             ELEMENT IS D(I)**2.  0 MEANS THE CALLER HAS SUPPLIED A */
/*             CHOLESKY FACTOR  L  OF THE INITIAL HESSIAN APPROXIMATION */
/*             H = L*(L**T)  IN V, STARTING AT V(IV(LMAT)) = V(IV(42)) */
/*             (AND STORED COMPACTLY BY ROWS).  NOTE THAT IV(LMAT) MAY */
/*             BE INITIALIZED BY CALLING WITH IV(1) = 13 (SEE */
/*             THE IV(1) DISCUSSION ABOVE).  DEFAULT = 1. */
/* IV(MXFCAL)... IV(17) GIVES THE MAXIMUM NUMBER OF FUNCTION EVALUATIONS*/
/*             (CALLS ON CALCF) ALLOWED.  IF THIS NUMBER DOES NOT SUF- */
/*             FICE, THEN ROUTINE RETURNS WITH IV(1) = 9.  DEFAULT = 200. */
/* IV(MXITER)... IV(18) GIVES THE MAXIMUM NUMBER OF ITERATIONS ALLOWED. */
/*             IT ALSO INDIRECTLY LIMITS THE NUMBER OF GRADIENT EVALUA- */
/*             TIONS (CALLS ON CALCG) TO IV(MXITER) + 1.  IF IV(MXITER) */
/*             ITERATIONS DO NOT SUFFICE, THEN ROUTINE RETURNS WITH */
/*             IV(1) = 10.  DEFAULT = 150. */
/* IV(OUTLEV)... IV(19) CONTROLS THE NUMBER AND LENGTH OF ITERATION SUM-*/
/*             MARY LINES PRINTED (BY ITSUM).  IV(OUTLEV) = 0 MEANS DO */
/*             NOT PRINT ANY SUMMARY LINES.  OTHERWISE, PRINT A SUMMARY */
/*             LINE AFTER EACH ABS(IV(OUTLEV)) ITERATIONS.  IF IV(OUTLEV)*/
/*             IS POSITIVE, THEN SUMMARY LINES OF LENGTH 78 (PLUS CARRI-*/
/*             AGE CONTROL) ARE PRINTED, INCLUDING THE FOLLOWING...  THE*/
/*             ITERATION AND FUNCTION EVALUATION COUNTS, F = THE CURRENT*/
/*             FUNCTION VALUE, RELATIVE DIFFERENCE IN FUNCTION VALUES */
/*             ACHIEVED BY THE LATEST STEP (I.E., RELDF = (F0-V(F))/F01,*/
/*             WHERE F01 IS THE MAXIMUM OF ABS(V(F)) AND ABS(V(F0)) AND */
/*             V(F0) IS THE FUNCTION VALUE FROM THE PREVIOUS ITERA- */
/*             TION), THE RELATIVE FUNCTION REDUCTION PREDICTED FOR THE */
/*             STEP JUST TAKEN (I.E., PRELDF = V(PREDUC) / F01, WHERE */
/*             V(PREDUC) IS DESCRIBED BELOW), THE SCALED RELATIVE CHANGE*/
/*             IN X (SEE V(RELDX) BELOW), THE STEP PARAMETER FOR THE */
/*             STEP JUST TAKEN (STPPAR = 0 MEANS A FULL NEWTON STEP, */
/*             BETWEEN 0 AND 1 MEANS A RELAXED NEWTON STEP, BETWEEN 1 */
/*             AND 2 MEANS A DOUBLE DOGLEG STEP, GREATER THAN 2 MEANS */
/*             A SCALED DOWN CAUCHY STEP -- SEE SUBROUTINE DBLDOG), THE */
/*             2-NORM OF THE SCALE VECTOR D TIMES THE STEP JUST TAKEN */
/*             (SEE V(DSTNRM) BELOW), AND NPRELDF, I.E., */
/*             V(NREDUC)/F01, WHERE V(NREDUC) IS DESCRIBED BELOW -- IF */
/*             NPRELDF IS POSITIVE, THEN IT IS THE RELATIVE FUNCTION */
/*             REDUCTION PREDICTED FOR A NEWTON STEP (ONE WITH */
/*             STPPAR = 0).  IF NPRELDF IS NEGATIVE, THEN IT IS THE */
/*             NEGATIVE OF THE RELATIVE FUNCTION REDUCTION PREDICTED */
/*             FOR A STEP COMPUTED WITH STEP BOUND V(LMAXS) FOR USE IN */
/*             TESTING FOR SINGULAR CONVERGENCE. */
/*                  IF IV(OUTLEV) IS NEGATIVE, THEN LINES OF LENGTH 50 */
/*             ARE PRINTED, INCLUDING ONLY THE FIRST 6 ITEMS LISTED */
/*             ABOVE (THROUGH RELDX). */
/*             DEFAULT = 1. */
/* IV(PARPRT)... IV(20) = 1 MEANS PRINT ANY NONDEFAULT V VALUES ON A */
/*             FRESH START OR ANY CHANGED V VALUES ON A RESTART. */
/*             IV(PARPRT) = 0 MEANS SKIP THIS PRINTING.  DEFAULT = 1. */
/* IV(PRUNIT)... IV(21) IS THE OUTPUT UNIT NUMBER ON WHICH ALL PRINTING */
/*             IS DONE.  IV(PRUNIT) = 0 MEANS SUPPRESS ALL PRINTING. */
/*             DEFAULT = STANDARD OUTPUT UNIT (UNIT 6 ON MOST SYSTEMS). */
/* IV(SOLPRT)... IV(22) = 1 MEANS PRINT OUT THE VALUE OF X RETURNED (AS */
/*             WELL AS THE GRADIENT AND THE SCALE VECTOR D). */
/*             IV(SOLPRT) = 0 MEANS SKIP THIS PRINTING.  DEFAULT = 1. */
/* IV(STATPR)... IV(23) = 1 MEANS PRINT SUMMARY STATISTICS UPON RETURN- */
/*             ING.  THESE CONSIST OF THE FUNCTION VALUE, THE SCALED */
/*             RELATIVE CHANGE IN X CAUSED BY THE MOST RECENT STEP (SEE */
/*             V(RELDX) BELOW), THE NUMBER OF FUNCTION AND GRADIENT */
/*             EVALUATIONS (CALLS ON CALCF AND CALCG), AND THE RELATIVE */
/*             FUNCTION REDUCTIONS PREDICTED FOR THE LAST STEP TAKEN AND*/
/*             FOR A NEWTON STEP (OR PERHAPS A STEP BOUNDED BY V(LMAX0) */
/*             -- SEE THE DESCRIPTIONS OF PRELDF AND NPRELDF UNDER */
/*             IV(OUTLEV) ABOVE). */
/*             IV(STATPR) = 0 MEANS SKIP THIS PRINTING. */
/*             IV(STATPR) = -1 MEANS SKIP THIS PRINTING AS WELL AS THAT */
/*             OF THE ONE-LINE TERMINATION REASON MESSAGE.  DEFAULT = 1.*/
/* IV(X0PRT).... IV(24) = 1 MEANS PRINT THE INITIAL X AND SCALE VECTOR D*/
/*             (ON A FRESH START ONLY).  IV(X0PRT) = 0 MEANS SKIP THIS */
/*             PRINTING.  DEFAULT = 1. */
/*  ***  (SELECTED) IV OUTPUT VALUES  *** */
/* IV(1)........ ON OUTPUT, IV(1) IS A RETURN CODE.... */
/*             3 = X-CONVERGENCE.  THE SCALED RELATIVE DIFFERENCE (SEE */
/*                  V(RELDX)) BETWEEN THE CURRENT PARAMETER VECTOR X AND*/
/*                  A LOCALLY OPTIMAL PARAMETER VECTOR IS VERY LIKELY AT*/
/*                  MOST V(XCTOL). */
/*             4 = RELATIVE FUNCTION CONVERGENCE.  THE RELATIVE DIFFER- */
/*                  ENCE BETWEEN THE CURRENT FUNCTION VALUE AND ITS LO- */
/*                  CALLY OPTIMAL VALUE IS VERY LIKELY AT MOST V(RFCTOL).*/
/*             5 = BOTH X- AND RELATIVE FUNCTION CONVERGENCE (I.E., THE */
/*                  CONDITIONS FOR IV(1) = 3 AND IV(1) = 4 BOTH HOLD). */
/*             6 = ABSOLUTE FUNCTION CONVERGENCE.  THE CURRENT FUNCTION */
/*                  VALUE IS AT MOST V(AFCTOL) IN ABSOLUTE VALUE. */
/*             7 = SINGULAR CONVERGENCE.  THE HESSIAN NEAR THE CURRENT */
/*                  ITERATE APPEARS TO BE SINGULAR OR NEARLY SO, AND A */
/*                  STEP OF LENGTH AT MOST V(LMAX0) IS UNLIKELY TO YIELD*/
/*                  A RELATIVE FUNCTION DECREASE OF MORE THAN V(SCTOL). */
/*             8 = FALSE CONVERGENCE.  THE ITERATES APPEAR TO BE CONVERG-*/
/*                  ING TO A NONCRITICAL POINT.  THIS MAY MEAN THAT THE */
/*                  CONVERGENCE TOLERANCES (V(AFCTOL), V(RFCTOL), */
/*                  V(XCTOL)) ARE TOO SMALL FOR THE ACCURACY TO WHICH */
/*                  THE FUNCTION AND GRADIENT ARE BEING COMPUTED, THAT */
/*                  THERE IS AN ERROR IN COMPUTING THE GRADIENT, OR THAT*/
/*                  THE FUNCTION OR GRADIENT IS DISCONTINUOUS NEAR X. */
/*             9 = FUNCTION EVALUATION LIMIT REACHED WITHOUT OTHER CON- */
/*                  VERGENCE (SEE IV(MXFCAL)). */
/*            10 = ITERATION LIMIT REACHED WITHOUT OTHER CONVERGENCE */
/*                  (SEE IV(MXITER)). */
/*            11 = STOPX RETURNED .TRUE. (EXTERNAL INTERRUPT).   */
/*            14 = STORAGE HAS BEEN ALLOCATED (AFTER A CALL WITH */
/*                  IV(1) = 13). */
/*            17 = RESTART ATTEMPTED WITH N CHANGED. */
/*            18 = D HAS A NEGATIVE COMPONENT AND IV(DTYPE) .LE. 0. */
/*            19...43 = V(IV(1)) IS OUT OF RANGE. */
/*            63 = F(X) CANNOT BE COMPUTED AT THE INITIAL X. */
/*            64 = BAD PARAMETERS PASSED TO ASSESS (WHICH SHOULD NOT */
/*            65 = THE GRADIENT COULD NOT BE COMPUTED AT X (SEE CALCG */
/*            67 = BAD FIRST PARAMETER TO DEFLT. */
/*            80 = IV(1) WAS OUT OF RANGE. */
/*            81 = N IS NOT POSITIVE. */
/* IV(G)........ IV(28) IS THE STARTING SUBSCRIPT IN V OF THE CURRENT */
/*             GRADIENT VECTOR (THE ONE CORRESPONDING TO X). */
/* IV(NFCALL)... IV(6) IS THE NUMBER OF CALLS SO FAR MADE ON CALCF (I.E.,*/
/*             FUNCTION EVALUATIONS). */
/* IV(NGCALL)... IV(30) IS THE NUMBER OF GRADIENT EVALUATIONS (CALLS ON */
/*             CALCG). */
/* IV(NITER).... IV(31) IS THE NUMBER OF ITERATIONS PERFORMED. */
/*  ***  (SELECTED) V INPUT VALUES (FROM SUBROUTINE DEFLT)  *** */
/* V(BIAS)..... V(43) IS THE BIAS PARAMETER USED IN SUBROUTINE DBLDOG --*/
/*             SEE THAT SUBROUTINE FOR DETAILS.  DEFAULT = 0.8. */
/* V(AFCTOL)... V(31) IS THE ABSOLUTE FUNCTION CONVERGENCE TOLERANCE. */
/*             IF ROUTINE FINDS A POINT WHERE THE FUNCTION VALUE IS LESS */
/*             THAN V(AFCTOL) IN ABSOLUTE VALUE, AND IF ROUTINE DOES NOT */
/*             RETURN WITH IV(1) = 3, 4, OR 5, THEN IT RETURNS WITH */
/*             IV(1) = 6.  DEFAULT = MAX(10**-20, MACHEP**2), WHERE */
/*             MACHEP IS THE UNIT ROUNDOFF. */
/* V(DINIT).... V(38), IF NONNEGATIVE, IS THE VALUE TO WHICH THE SCALE */
/*             VECTOR D IS INITIALIZED.  DEFAULT = -1. */
/* V(LMAX0).... V(35) GIVES THE MAXIMUM 2-NORM ALLOWED FOR D TIMES THE */
/*             VERY FIRST STEP THAT ROUTINE ATTEMPTS.  THIS PARAMETER CAN */
/*             MARKEDLY AFFECT THE PERFORMANCE OF THE ROUTINE. */
/* V(LMAXS).... V(36) IS USED IN TESTING FOR SINGULAR CONVERGENCE -- IF */
/*             THE FUNCTION REDUCTION PREDICTED FOR A STEP OF LENGTH */
/*             BOUNDED BY V(LMAXS) IS AT MOST V(SCTOL) * ABS(F0), WHERE */
/*             F0  IS THE FUNCTION VALUE AT THE START OF THE CURRENT */
/*             ITERATION, AND IF ROUTINE DOES NOT RETURN WITH IV(1) = 3, */
/*             4, 5, OR 6, THEN IT RETURNS WITH IV(1) = 7.  DEFAULT = 1.*/
/* V(RFCTOL)... V(32) IS THE RELATIVE FUNCTION CONVERGENCE TOLERANCE. */
/*             IF THE CURRENT MODEL PREDICTS A MAXIMUM POSSIBLE FUNCTION*/
/*             REDUCTION (SEE V(NREDUC)) OF AT MOST V(RFCTOL)*ABS(F0) */
/*             AT THE START OF THE CURRENT ITERATION, WHERE  F0  IS THE */
/*             THEN CURRENT FUNCTION VALUE, AND IF THE LAST STEP ATTEMPT-*/
/*             ED ACHIEVED NO MORE THAN TWICE THE PREDICTED FUNCTION */
/*             DECREASE, THEN ROUTINE RETURNS WITH IV(1) = 4 (OR 5). */
/*             DEFAULT = MAX(10**-10, MACHEP**(2/3)), WHERE MACHEP IS */
/*             THE UNIT ROUNDOFF. */
/* V(SCTOL).... V(37) IS THE SINGULAR CONVERGENCE TOLERANCE -- SEE THE */
/*             DESCRIPTION OF V(LMAXS) ABOVE. */
/* V(TUNER1)... V(26) HELPS DECIDE WHEN TO CHECK FOR FALSE CONVERGENCE. */
/*             THIS IS DONE IF THE ACTUAL FUNCTION DECREASE FROM THE */
/*             CURRENT STEP IS NO MORE THAN V(TUNER1) TIMES ITS PREDICT-*/
/*             ED VALUE.  DEFAULT = 0.1. */
/* V(XCTOL).... V(33) IS THE X-CONVERGENCE TOLERANCE.  IF A NEWTON STEP */
/*             (SEE V(NREDUC)) IS TRIED THAT HAS V(RELDX) .LE. V(XCTOL) */
/*             AND IF THIS STEP YIELDS AT MOST TWICE THE PREDICTED FUNC-*/
/*             TION DECREASE, THEN ROUTINE RETURNS WITH IV(1) = 3 (OR 5). */
/*             (SEE THE DESCRIPTION OF V(RELDX) BELOW.) */
/*             DEFAULT = MACHEP**0.5, WHERE MACHEP IS THE UNIT ROUNDOFF.*/
/* V(XFTOL).... V(34) IS THE FALSE CONVERGENCE TOLERANCE.  IF A STEP IS */
/*             TRIED THAT GIVES NO MORE THAN V(TUNER1) TIMES THE PREDICT-*/
/*             ED FUNCTION DECREASE AND THAT HAS V(RELDX) .LE. V(XFTOL),*/
/*             AND IF ROUTINE DOES NOT RETURN WITH IV(1) = 3, 4, 5, 6, OR */
/*             7, THEN IT RETURNS WITH IV(1) = 8.  (SEE THE DESCRIPTION */
/*             OF V(RELDX) BELOW.)  DEFAULT = 100*MACHEP, WHERE */
/*             MACHEP IS THE UNIT ROUNDOFF. */
/* V(*)........ DEFLT SUPPLIES TO V A NUMBER OF TUNING CONSTANTS, WITH */
/*             WHICH IT SHOULD ORDINARILY BE UNNECESSARY TO TINKER.  SEE*/
/*             SECTION 17 OF VERSION 2.2 OF THE NL2SOL USAGE SUMMARY */
/*             (I.E., THE APPENDIX TO REF. 1) FOR DETAILS ON V(I), */
/*             I = DECFAC, INCFAC, PHMNFC, PHMXFC, RDFCMN, RDFCMX, */
/*             TUNER2, TUNER3, TUNER4, TUNER5. */
/*  ***  (SELECTED) V OUTPUT VALUES  *** */
/* V(DGNORM)... V(1) IS THE 2-NORM OF (DIAG(D)**-1)*G, WHERE G IS THE */
/*             MOST RECENTLY COMPUTED GRADIENT. */
/* V(DSTNRM)... V(2) IS THE 2-NORM OF DIAG(D)*STEP, WHERE STEP IS THE */
/*             CURRENT STEP. */
/* V(F)........ V(10) IS THE CURRENT FUNCTION VALUE. */
/* V(F0)....... V(13) IS THE FUNCTION VALUE AT THE START OF THE CURRENT */
/*             ITERATION. */
/* V(NREDUC)... V(6), IF POSITIVE, IS THE MAXIMUM FUNCTION REDUCTION */
/*             POSSIBLE ACCORDING TO THE CURRENT MODEL, I.E., THE FUNC- */
/*             TION REDUCTION PREDICTED FOR A NEWTON STEP (I.E., */
/*             STEP = -H**-1 * G,  WHERE  G  IS THE CURRENT GRADIENT AND*/
/*             H IS THE CURRENT HESSIAN APPROXIMATION). */
/*                  IF V(NREDUC) IS NEGATIVE, THEN IT IS THE NEGATIVE OF*/
/*             THE FUNCTION REDUCTION PREDICTED FOR A STEP COMPUTED WITH*/
/*             A STEP BOUND OF V(LMAXS) FOR USE IN TESTING FOR SINGULAR */
/*             CONVERGENCE. */
/* V(PREDUC)... V(7) IS THE FUNCTION REDUCTION PREDICTED (BY THE CURRENT*/
/*             QUADRATIC MODEL) FOR THE CURRENT STEP.  THIS (DIVIDED BY */
/*             V(F0)) IS USED IN TESTING FOR RELATIVE FUNCTION */
/*             CONVERGENCE. */
/* V(RELDX).... V(17) IS THE SCALED RELATIVE CHANGE IN X CAUSED BY THE */
/*             CURRENT STEP, COMPUTED AS */
/*                  MAX(ABS(D(I)*(X(I)-X0(I)), 1 .LE. I .LE. P) / */
/*                     MAX(D(I)*(ABS(X(I))+ABS(X0(I))), 1 .LE. I .LE. P),*/
/*             WHERE X = X0 + STEP. */
/*        THIS ROUTINE USES A HESSIAN APPROXIMATION COMPUTED FROM THE */
/*     BFGS UPDATE (SEE REF 3).  ONLY A CHOLESKY FACTOR OF THE HESSIAN */
/*     APPROXIMATION IS STORED, AND THIS IS UPDATED USING IDEAS FROM */
/*     REF. 4.  STEPS ARE COMPUTED BY THE DOUBLE DOGLEG SCHEME DESCRIBED*/
/*     IN REF. 2.  THE STEPS ARE ASSESSED AS IN REF. 1. */
/*        AFTER A RETURN WITH IV(1) .LE. 11, IT IS POSSIBLE TO RESTART, */
/*     I.E., TO CHANGE SOME OF THE IV AND V INPUT VALUES DESCRIBED ABOVE*/
/*     AND CONTINUE THE ALGORITHM FROM THE POINT WHERE IT WAS INTERRUPT-*/
/*     ED.  IV(1) SHOULD NOT BE CHANGED, NOR SHOULD ANY ENTRIES OF IV */
/*     AND V OTHER THAN THE INPUT VALUES (THOSE SUPPLIED BY DEFLT). */
/*        STORAGE FOR G IS ALLOCATED AT THE END OF V.  THUS THE CALLER */
/*     MAY MAKE V LONGER THAN SPECIFIED ABOVE AND MAY ALLOW CALCG TO USE*/
/*     ELEMENTS OF G BEYOND THE FIRST N AS SCRATCH STORAGE. */

    if (iv[1] == 0) deflt_(&c__2, &iv[1], liv, lv, &v[1]);
    iv[vneed] += *n;
    iv1 = iv[1];
    if (iv1 == 14) goto L10;
    if (iv1 > 2 && iv1 < 12) goto L10;
    g1 = 1;
    if (iv1 == 12) iv[1] = 13;
    goto L20;
L10:
    g1 = iv[g];
L20:
    sumit_(&d[1], &f, &v[g1], &iv[1], liv, lv, n, &v[1], &x[1]);
    if ((i_1 = iv[1] - 2) < 0) goto L30;
    else if (i_1 == 0) 
	goto L40;
    else goto L50;
L30:
    nf = iv[nfcall];
    (*calcf)(np, &x[1], &f, info);
    if (f==DBL_MAX) iv[toobig] = 1;
	if (iv[toobig]==1 && iv[19] < 0) 
		WRITELOG("too big of a step\n");
    goto L20;									    
L40:
    (*calcg)(np, &x[1], &iv[nfgcal], &v[g1], info);
    goto L20;
L50:													  
    if (iv[1] != 14) goto L999;

/*  ***  STORAGE ALLOCATION */
    iv[g] = iv[nextv];
    iv[nextv] = iv[g] + *n;
    if (iv1 != 13) goto L10;
L999:
    return 0;
}

int calcMLE_no_derivative_(int *n, double *d, double *x, int (*calcf)(int,double *,double *,void *), 
			int *iv, int *liv, int *lv,double *v,void *info)
{
    static int nfcall = 6;
    static int toobig = 2;
    static int nf,np;
    static double fx;
	extern int snoit_();
    --d;
    --x;
    --iv;
    --v;
	np=*n;

/*  ***  MINIMIZE GENERAL UNCONSTRAINED OBJECTIVE FUNCTION USING */
/*  ***  FINITE-DIFFERENCE GRADIENTS AND SECANT HESSIAN APPROXIMATIONS. */
/*       THIS ROUTINE INTERACTS WITH ROUTINE SNOIT IN AN ATTEMPT */
/*     TO FIND AN N-VECTOR X* THAT MINIMIZES THE (UNCONSTRAINED) */
/*     OBJECTIVE FUNCTION COMPUTED BY CALCF. (OFTEN THE X* FOUND IS */
/*     A LOCAL MINIMIZER RATHER THAN A GLOBAL ONE.) */
/*     INSTEAD OF CALLING */
/*     CALCG TO OBTAIN THE GRADIENT OF THE OBJECTIVE FUNCTION AT X, */
/*     ROUTINE CALLS SGRAD2, WHICH COMPUTES AN APPROXIMATION TO THE */
/*     GRADIENT BY FINITE (FORWARD AND CENTRAL) DIFFERENCES */
/*     THE FOLLOWING INPUT COMPONENT IS OF INTEREST */
/* V(ETA0)..... V(42) IS AN ESTIMATED BOUND ON THE RELATIVE ERROR IN THE */
/*             OBJECTIVE FUNCTION VALUE COMPUTED BY CALCF... */
/*                  (TRUE VALUE) = (COMPUTED VALUE) * (1 + E), */
/*             WHERE ABS(E) .LE. V(ETA0).  DEFAULT = MACHEP * 10**3, */
/*             WHERE MACHEP IS THE UNIT ROUNDOFF. */
/* IV(NFCALL)... IV(6) IS THE NUMBER OF CALLS SO FAR MADE ON CALCF (I.E.,*/
/*             FUNCTION EVALUATIONS) EXCLUDING THOSE MADE ONLY FOR */
/*             COMPUTING GRADIENTS. THE INPUT VALUE IV(MXFCAL) IS A */
/*             LIMIT ON IV(NFCALL). */
/* IV(NGCALL)... IV(30) IS THE NUMBER OF FUNCTION EVALUATIONS MADE ONLY */
/*             FOR COMPUTING GRADIENTS.  THE TOTAL NUMBER OF FUNCTION */
/*             EVALUATIONS IS THUS  IV(NFCALL) + IV(NGCALL). */

L10:
    snoit_(&d[1], &fx, &iv[1], liv, lv, n, &v[1], &x[1]);
    if (iv[1] > 2) goto L999;
/*     ***  COMPUTE FUNCTION  *** */
    nf = iv[nfcall];
    (*calcf)(np, &x[1],&fx,info);
    if (fx == DBL_MAX) iv[toobig] = 1;												   
    goto L10;
L999:
    return 0;
}

int vaxpy_(int *p,double *w,double *a,double *x,double *y)
{
    int i_1;
    static int i;
    --w;
    --x;
    --y;
/*  ***  SET W = A*X + Y  --  W, X, Y = P-VECTORS, A = SCALAR  *** */
    i_1 = *p;
    for (i = 1; i <= i_1; ++i) w[i] = *a * x[i] + y[i];
    return 0;
}

int vscopy_(int *p,double *y,double *s)
{
    int i_1;
    static int i;
    --y;
/*  ***  SET P-VECTOR Y TO SCALAR S  *** */
    i_1 = *p;
    for (i = 1; i <= i_1; ++i) y[i] = *s;
    return 0;
}

int vvmulp_(int *n,double *x,double *y,double *z,int *k)
{
    int i_1;
    static int i;
    --x;
    --y;
    --z;
/* ***  SET X(I) = Y(I) * Z(I)**K, 1 .LE. I .LE. N (FOR K = 1 OR -1)  */
    if (*k >= 0) goto L20;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) x[i] = y[i] / z[i];
    goto L999;
L20:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) x[i] = y[i] * z[i];
L999:
    return 0;
}

int stopx_(int *idummy)
{
    int ret_val;
    ret_val = FALSE;
    return ret_val;
}

int ltvmul_(int *n,double *x,double *l,double *y)
{
    static double zero = 0.;
    int i_1, i_2;
    static int i, j, i0, ij;
    static double yi;
    --x;
    --l;
    --y;
/*  ***  COMPUTE  X = (L**T)*Y, WHERE  L  IS AN  N X N  LOWER */
/*  ***  TRIANGULAR MATRIX STORED COMPACTLY BY ROWS. X AND Y MAY */
/*  ***  OCCUPY THE SAME STORAGE. *** */

    i0 = 0;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		yi = y[i];
		x[i] = zero;
		i_2 = i;
		for (j = 1; j <= i_2; ++j) {
			ij = i0 + j;
			x[j] += yi * l[ij];
		}
		i0 += i;
    }
    return 0;
}

int lvmul_(int *n,double *x,double *l,double *y)
{
    static double zero = 0.;
    int i_1, i_2;
    static int i, j;
    static double t;
    static int i0, ii, ij, np1;
    --x;
    --l;
    --y;
/*  ***  COMPUTE X = L*Y, WHERE L IS AN N X N LOWER TRIANGULAR MATRIX */
/*  ***  STORED COMPACTLY BY ROWS. X AND Y MAY OCCUPY THE SAME STORAGE */
    
	np1 = *n + 1;
    i0 = *n * (*n + 1) / 2;
    i_1 = *n;
    for (ii = 1; ii <= i_1; ++ii) {
		i = np1 - ii;
		i0 -= i;
		t = zero;
		i_2 = i;
		for (j = 1; j <= i_2; ++j) {
			ij = i0 + j;
			t += l[ij] * y[j];
		}
		x[i] = t;
	}
    return 0;
}

double reldst_(int *p,double *d,double *x,double *x0)
{
    static double zero = 0.;
    int i_1;
    double ret_val, r_1, r_2;
    static double emax, xmax;
    static int i;
    static double t;
    --d;
    --x;
    --x0;
/*  ***  COMPUTE AND RETURN RELATIVE DIFFERENCE BETWEEN X AND X0  *** */
    emax = zero;
    xmax = zero;
    i_1 = *p;
    for (i = 1; i <= i_1; ++i) {
		t = (r_1 = d[i] * (x[i] - x0[i]), fabs(r_1));
		if (emax < t) emax = t;
		t = d[i] * ((r_1 = x[i], fabs(r_1)) + (r_2 = x0[i], fabs(r_2)));
		if (xmax < t) xmax = t;
    }
    ret_val = zero;
    if (xmax > zero) ret_val = emax / xmax;
    return ret_val;
}  

int sgrad2_(double *alpha,double *d,double *eta0,double *fx,double *g,int *irc,int *n,double *w,double *x)
{
    static double c2000 = 2e3;
    static int fh = 3;
    static int fx0 = 4;
    static int hsave = 5;
    static int xisave = 6;
    static double four = 4.;
    static double hmax0 = .02;
    static double hmin0 = 50.;
    static double one = 1.;
    static double p002 = .002;
    static double three = 3.;
    static double two = 2.;
    static double zero = 0.;
    double r_1, r_2;
    double d_1, d_2;
    static double hmin, h;
    static int i;
    static double h0;
    static double gi, machep, alphai, axibar, afxeta, discon, aai, agi, eta, afx, axi;
    --alpha;
    --d;
    --g;
    --w;
    --x;
/*  ***  COMPUTE FINITE DIFFERENCE GRADIENT BY STWEART*S SCHEME  *** */
/*     THIS ROUTINE USES AN EMBELLISHED FORM OF THE FINITE-DIFFER-*/
/*     ENCE SCHEME PROPOSED BY STEWART (REF. 1) TO APPROXIMATE THE */
/*     GRADIENT OF THE FUNCTION F(X), WHOSE VALUES ARE SUPPLIED BY */
/*     REVERSE COMMUNICATION. */
/*  ALPHA IN  (APPROXIMATE) DIAGONAL ELEMENTS OF THE HESSIAN OF F(X). */
/*      D IN  SCALE VECTOR SUCH THAT D(I)*X(I), I = 1,...,N, ARE IN */
/*             COMPARABLE UNITS. */
/*   ETA0 IN  ESTIMATED BOUND ON RELATIVE ERROR IN THE FUNCTION VALUE... */
/*             (TRUE VALUE) = (COMPUTED VALUE)*(1+E),   WHERE */
/*             ABS(E) .LE. ETA0. */
/*     FX I/O ON INPUT,  FX  MUST BE THE COMPUTED VALUE OF F(X).  ON */
/*             OUTPUT WITH IRC = 0, FX HAS BEEN RESTORED TO ITS ORIGINAL */
/*             VALUE, THE ONE IT HAD WHEN SGRAD2 WAS LAST CALLED WITH */
/*             IRC = 0. */
/*      G I/O ON INPUT WITH IRC = 0, G SHOULD CONTAIN AN APPROXIMATION */
/*             TO THE GRADIENT OF F NEAR X, E.G., THE GRADIENT AT THE */
/*             PREVIOUS ITERATE.  WHEN SGRAD2 RETURNS WITH IRC = 0, G IS */
/*             THE DESIRED FINITE-DIFFERENCE APPROXIMATION TO THE */
/*             GRADIENT AT X. */
/*    IRC I/O INPUT/RETURN CODE... BEFORE THE VERY FIRST CALL ON SGRAD2, */
/*             THE CALLER MUST SET IRC TO 0.  WHENEVER SGRAD2 RETURNS A */
/*             NONZERO VALUE FOR IRC, IT HAS PERTURBED SOME COMPONENT OF */
/*             X... THE CALLER SHOULD EVALUATE F(X) AND CALL SGRAD2 */
/*             AGAIN WITH FX = F(X). */
/*      N IN  THE NUMBER OF VARIABLES (COMPONENTS OF X) ON WHICH F */
/*             DEPENDS. */
/*      X I/O ON INPUT WITH IRC = 0, X IS THE POINT AT WHICH THE */
/*             GRADIENT OF F IS DESIRED.  ON OUTPUT WITH IRC NONZERO, X */
/*             IS THE POINT AT WHICH F SHOULD BE EVALUATED.  ON OUTPUT */
/*             WITH IRC = 0, X HAS BEEN RESTORED TO ITS ORIGINAL VALUE */
/*             (THE ONE IT HAD WHEN SGRAD2 WAS LAST CALLED WITH IRC = 0) */
/*             AND G CONTAINS THE DESIRED GRADIENT APPROXIMATION. */
/*      W I/O WORK VECTOR OF LENGTH 6 IN WHICH SGRAD2 SAVES CERTAIN */
/*             QUANTITIES WHILE THE CALLER IS EVALUATING F(X) AT A */
/*             PERTURBED X. */
/*     ***  APPLICATION AND USAGE RESTRICTIONS  *** */
/*        THIS ROUTINE IS INTENDED FOR USE WITH QUASI-NEWTON ROUTINES */
/*     FOR UNCONSTRAINED MINIMIZATION (IN WHICH CASE  ALPHA  COMES FROM */
/*     THE DIAGONAL OF THE QUASI-NEWTON HESSIAN APPROXIMATION). */
/*        THIS CODE DEPARTS FROM THE SCHEME PROPOSED BY STEWART (REF. 1)*/
/*     IN ITS GUARDING AGAINST OVERLY LARGE OR SMALL STEP SIZES AND ITS */
/*     HANDLING OF SPECIAL CASES (SUCH AS ZERO COMPONENTS OF ALPHA OR G)*/
/* 1. STEWART, G.W. (1967), A MODIFICATION OF DAVIDON*S MINIMIZATION */
/*        METHOD TO ACCEPT DIFFERENCE APPROXIMATIONS OF DERIVATIVES, */
/*        J. ASSOC. COMPUT. MACH. 14, PP. 72-83. */
    if (*irc < 0) goto L140;
    else if (*irc == 0) goto L100;
    else goto L210;
/*  ***  FRESH START -- GET MACHINE-DEPENDENT CONSTANTS  *** */
/*  STORE MACHEP IN W(1) AND H0 IN W(2), WHERE MACHEP IS THE UNIT */
/*  ROUNDOFF (THE SMALLEST POSITIVE NUMBER SUCH THAT */
/*  1 + MACHEP .GT. 1  AND  1 - MACHEP .LT. 1),  AND  H0 IS THE */
/*  SQUARE-ROOT OF MACHEP. */
L100:
    w[1] = DBL_EPSILON;
    w[2] = sqrt(w[1]);
    w[fx0] = *fx;
/*  ***  INCREMENT  I  AND START COMPUTING  G(I)  *** */
L110:
    i = abs(*irc) + 1;
    if (i > *n) goto L300;
    *irc = i;
    afx = (r_1 = w[fx0], fabs(r_1));
    machep = w[1];
    h0 = w[2];
    hmin = hmin0 * machep;
    w[xisave] = x[i];
    axi = (r_1 = x[i], fabs(r_1));
    r_1 = axi, r_2 = one / d[i];
    axibar = FMAX(r_2, r_1);
    gi = g[i];
    agi = fabs(gi);
    eta = fabs(*eta0);
    if (afx > zero) {
		r_1 = eta, r_2 = agi * axi * machep / afx;
		eta = FMAX(r_2,r_1);
    }
    alphai = alpha[i];
    if (alphai == zero) goto L170;
    if (gi == zero || *fx == zero) goto L180;
    afxeta = afx * eta;
    aai = fabs(alphai);
/*  *** COMPUTE H = STEWART*S FORWARD-DIFFERENCE STEP SIZE. */
    r_1 = gi;
    if (r_1 * r_1 <= afxeta * aai) goto L120;
    h = two * sqrt(afxeta / aai);
    h *= one - aai * h / (three * aai * h + four * agi);
    goto L130;
L120:
    r_1 = aai;
    d_1 = (double) (afxeta * agi / (r_1 * r_1));
    d_2 = (double) (one / three);
    h = two * pow(d_1, d_2);
    h *= one - two * agi / (three * aai * h + four * agi);
/*  ***  ENSURE H IS NOT INSIGNIFICANTLY SMALL  *** */
L130:
    r_1 = h, r_2 = hmin * axibar;
    h = FMAX(r_2,r_1);
/*  *** USE FORWARD DIFFERENCE IF BOUND ON TRUNCATION ERROR IS AT MOST 10**-3.*/
    if (aai * h <= p002 * agi) goto L160;
/*  *** COMPUTE H = STEWART*S STEP FOR CENTRAL DIFFERENCE. */
    discon = c2000 * afxeta;
    r_1 = gi;
    h = discon / (agi + sqrt(r_1 * r_1 + aai * discon));
/*  *** ENSURE H IS NEITHER TOO SMALL NOR TOO BIG  *** */
    r_1 = h, r_2 = hmin * axibar;
    h = FMAX(r_2,r_1);
    if (h >= hmax0 * axibar) {
		d_1 = (double) h0;
		d_2 = (double) (two / three);
		h = axibar * pow(d_1, d_2);
    }
/*  ***  COMPUTE CENTRAL DIFFERENCE  *** */
    *irc = -i;
    goto L200;
L140:
    h = -w[hsave];
    i = abs(*irc);
    if (h > zero) goto L150;
    w[fh] = *fx;
    goto L200;
L150:
    g[i] = (w[fh] - *fx) / (two * h);
    x[i] = w[xisave];
    goto L110;
/*  ***  COMPUTE FORWARD DIFFERENCES FOR VARIOUS CASES  *** */
L160:
    if (h >= hmax0 * axibar) h = h0 * axibar;
    if (alphai * gi < zero) h = -h;
    goto L200;
L170:
    h = axibar;
    goto L200;
L180:
    h = h0 * axibar;
L200:
    x[i] = w[xisave] + h;
    w[hsave] = h;
    goto L999;
/*  ***  COMPUTE ACTUAL FORWARD DIFFERENCE  *** */
L210:
    g[*irc] = (*fx - w[fx0]) / w[hsave];
    x[*irc] = w[xisave];
    goto L110;
/*  ***  RESTORE FX AND INDICATE THAT G HAS BEEN COMPUTED  *** */
L300:
    *fx = w[fx0];
    *irc = 0;
L999:
    return 0; } 


int litvmu_(int *n,double *x,double *l,double *y)
{
    static double zero = 0.;
    int i_1, i_2;
    static int i, j, i0, ii, ij;
    static double xi;
    static int im1, np1;
    --x;
    --l;
    --y;
/*  ***  SOLVE (L**T)*X = Y, WHERE L IS AN N X N LOWER TRIANGULAR MATRIX*/
/*  ***  STORED COMPACTLY BY ROWS.  X AND Y MAY OCCUPY THE SAME STORAGE */
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) x[i] = y[i];
    np1 = *n + 1;
    i0 = *n * (*n + 1) / 2;
    i_1 = *n;
    for (ii = 1; ii <= i_1; ++ii) {
		i = np1 - ii;
		xi = x[i] / l[i0];
		x[i] = xi;
		if (i <= 1) goto L999;
		i0 -= i;
		if (xi == zero) goto L30;
		im1 = i - 1;
		i_2 = im1;
		for (j = 1; j <= i_2; ++j) {
			ij = i0 + j;
			x[j] -= xi * l[ij];
		}
L30:
    ;}
L999:
    return 0;
}

static int c__1 = 1;
int livmul_(int *n,double *x,double *l,double *y)
{
    static double zero = 0.;
    int i_1, i_2;
    static int i, j, k;
    static double t;
    --x;
    --l;
    --y;
/*  ***  SOLVE L*X = Y, WHERE L IS AN N X N LOWER TRIANGULAR MATRIX */
/*  ***  STORED COMPACTLY BY ROWS. X AND Y MAY OCCUPY THE SAME STORAGE */
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
		if (y[k] != zero) goto L20;
		x[k] = zero;
    }
    goto L999;
L20:
    j = k * (k + 1) / 2;
    x[k] = y[k] / l[j];
    if (k >= *n) goto L999;
    ++k;
    i_1 = *n;
    for (i = k; i <= i_1; ++i) {
		i_2 = i - 1;
		t = sdot_(&i_2, &l[j + 1], &c__1, &x[1], &c__1);
		j += i;
		x[i] = (y[i] - t) / l[j];
    }
L999:
    return 0;
}

int scopy_(int *n,double *sx,int *incx,double *sy,int *incy)
{
    int i_1, i_2;
    static int i, m, ix, iy, ns, mp1;
    --sx;
    --sy;
/* ***PURPOSE  Copy vector y = x */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       SX  vector with N elements */
/*     INCX  spacing between elements of SX */
/*       SY  vector with N elements */
/*     INCY  spacing between elements of SY */
/*     --Output-- */
/*       SY  copy of vector SX (unchanged if N .LE. 0) */
/*     Copy SX to SY. */
/*     For I = 0 to N-1, copy  SX(LX+I*INCX) to SY(LY+I*INCY), */
/*     where LX = 1 if INCX .GE. 0, else LX = (-INCX)*N, and LY is */
/*     defined in a similar way using INCY. */
    if (*n <= 0) return 0;
    if (*incx == *incy) {
		if ((i_1 = *incx - 1) < 0) goto L5;
		else if (i_1 == 0) goto L20;
		else goto L60;
    }
L5:
/*  CODE FOR UNEQUAL OR NONPOSITIVE INCREMENTS. */
    ix = 1;
    iy = 1;
    if (*incx < 0) ix = (-(*n) + 1) * *incx + 1;
    if (*incy < 0) iy = (-(*n) + 1) * *incy + 1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		sy[iy] = sx[ix];
		ix += *incx;
		iy += *incy;
    }
    return 0;
/*  CODE FOR BOTH INCREMENTS EQUAL TO 1 */
/*  CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 7. */
L20:
    m = *n % 7;
    if (m == 0) goto L40;
    i_1 = m;
    for (i = 1; i <= i_1; ++i) sy[i] = sx[i];
    if (*n < 7) return 0;
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 7) {
		sy[i] = sx[i];
		sy[i + 1] = sx[i + 1];
		sy[i + 2] = sx[i + 2];
		sy[i + 3] = sx[i + 3];
		sy[i + 4] = sx[i + 4];
		sy[i + 5] = sx[i + 5];
		sy[i + 6] = sx[i + 6];
    }
    return 0;
/*  CODE FOR EQUAL, POSITIVE, NONUNIT INCREMENTS. */
L60:
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) sy[i] = sx[i];
    return 0;
} 

double sdot_(int *n,double *sx,int *incx,double *sy,int *incy)
{
    int i_1, i_2;
    double ret_val;
    static int i, m, ix, iy, ns, mp1;
    --sx;
    --sy;
/* ***PURPOSE  inner product of vectors */
/* ***DESCRIPTION */
/*    Description of Parameters */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       SX  vector with N elements */
/*     INCX  storage spacing between elements of SX */
/*       SY  vector with N elements */
/*     INCY  storage spacing between elements of SY */
/*     --Output-- */
/*     SDOT  dot product (zero if N .LE. 0) */
/*     Returns the dot product of SX and SY. */
/*     SDOT = sum for I = 0 to N-1 of  SX(LX+I*INCX) * SY(LY+I*INCY), */
/*     where LX = 1 if INCX .GE. 0, else LX = (-INCX)*N, and LY is */
/*     defined in a similar way using INCY. */
    ret_val = 0.;
    if (*n <= 0) return ret_val;
		if (*incx == *incy) {
			if ((i_1 = *incx - 1) < 0) goto L5;
		else if (i_1 == 0) goto L20;
		else goto L60;
    }
L5:
/*  CODE FOR UNEQUAL INCREMENTS OR NONPOSITIVE INCREMENTS. */
    ix = 1;
    iy = 1;
    if (*incx < 0) ix = (-(*n) + 1) * *incx + 1;
    if (*incy < 0) iy = (-(*n) + 1) * *incy + 1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		ret_val += sx[ix] * sy[iy];
		ix += *incx;
		iy += *incy;
    }
    return ret_val;
/*  CODE FOR BOTH INCREMENTS EQUAL TO 1 */
/*  CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 5. */
L20:
    m = *n % 5;
    if (m == 0) goto L40;
    i_1 = m;
    for (i = 1; i <= i_1; ++i) ret_val += sx[i] * sy[i];
    if (*n < 5) return ret_val;
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 5) 
		ret_val = ret_val + sx[i] * sy[i] + sx[i + 1] * sy[i + 1] + sx[i + 2] 
		* sy[i + 2] + sx[i + 3] * sy[i + 3] + sx[i + 4] * sy[i + 4];
    return ret_val;
/*  CODE FOR POSITIVE EQUAL INCREMENTS .NE.1. */
L60:
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) ret_val += sx[i] * sy[i];
    return ret_val;
}

int wzbfgs_(double *l,int *n,double *s,double *w,double *y,double *z)
{
    static double eps = .1;
    static double one = 1.;
    int i_1;
    static int i;
    static double theta, epsrt, cs, cy, ys;
    static double shs;
    --l;
    --s;
    --w;
    --y;
    --z;
/*  ***  COMPUTE Y AND Z FOR LUPDAT CORRESPONDING TO BFGS UPDATE */
/* L (I/O) CHOLESKY FACTOR OF HESSIAN, A LOWER TRIANG. MATRIX STORED */
/*             COMPACTLY BY ROWS. */
/* N (INPUT) ORDER OF  L  AND LENGTH OF  S,  W,  Y,  Z. */
/* S (INPUT) THE STEP JUST TAKEN. */
/* W (OUTPUT) RIGHT SINGULAR VECTOR OF RANK 1 CORRECTION TO L. */
/* Y (INPUT) CHANGE IN GRADIENTS CORRESPONDING TO S. */
/* Z (OUTPUT) LEFT SINGULAR VECTOR OF RANK 1 CORRECTION TO L. */
/*     WHEN S IS COMPUTED IN CERTAIN WAYS, E.G. BY  GQTSTP  OR */
/*     DBLDOG, IT IS POSSIBLE TO SAVE N**2/2 OPERATIONS SINCE  (L**T)*S */
/*     OR  L*(L**T)*S IS THEN KNOWN. */
/*     IF THE BFGS UPDATE TO L*(L**T) WOULD REDUCE ITS DETERMINANT TO */
/*     LESS THAN EPS TIMES ITS OLD VALUE, THEN THIS ROUTINE IN EFFECT */
/*     REPLACES  Y  BY  THETA*Y + (1 - THETA)*L*(L**T)*S,  WHERE  THETA */
/*     (BETWEEN 0 AND 1) IS CHOSEN TO MAKE THE REDUCTION FACTOR = EPS. */
    ltvmul_(n, &w[1], &l[1], &s[1]);
    shs = sdot_(n, &w[1], &c__1, &w[1], &c__1);
    ys = sdot_(n, &y[1], &c__1, &s[1], &c__1);
    if (ys >= eps * shs) goto L10;
    theta = (one - eps) * shs / (shs - ys);
    epsrt = sqrt(eps);
    cy = theta / (shs * epsrt);
    cs = (one + (theta - one) / epsrt) / shs;
    goto L20;
L10:
    cy = one / (sqrt(ys) *sqrt(shs));
    cs = one / shs;
L20:
    livmul_(n, &z[1], &l[1], &y[1]);
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) z[i] = cy * z[i] - cs * w[i];
    return 0;
}

int lupdat_(double *beta,double *gamma,double *l,double *lambda,double *lplus,int *n,double *w,double *z)
{
    static double one = 1.;
    static double zero = 0.;
    int i_1, i_2;
    double r_1;
    static double a, b;
    static int i, j, k;
    static double s, theta, bj, gj;
    static int ij, jj;
    static double lj, wj, nu, zj;
    static int jp1, nm1, np1;
    static double eta, lij, ljj;
    --beta;
    --gamma;
    --l;
    --lambda;
    --lplus;
    --w;
    --z;
/*  ***  COMPUTE LPLUS = SECANT UPDATE OF L  *** */
/*   BETA = SCRATCH VECTOR. */
/*  GAMMA = SCRATCH VECTOR. */
/*      L (INPUT) LOWER TRIANGULAR MATRIX, STORED ROWWISE. */
/* LAMBDA = SCRATCH VECTOR. */
/*  LPLUS (OUTPUT) LOWER TRIANGULAR MATRIX, STORED ROWWISE, WHICH MAY */
/*             OCCUPY THE SAME STORAGE AS  L. */
/*      N (INPUT) LENGTH OF VECTOR PARAMETERS AND ORDER OF MATRICES. */
/*      W (INPUT, DESTROYED ON OUTPUT) RIGHT SINGULAR VECTOR OF RANK 1 */
/*             CORRECTION TO  L. */
/*      Z (INPUT, DESTROYED ON OUTPUT) LEFT SINGULAR VECTOR OF RANK 1 */
/*             CORRECTION TO  L. */
/*     THIS ROUTINE UPDATES THE CHOLESKY FACTOR  L  OF A SYMMETRIC */
/*     POSITIVE DEFINITE MATRIX TO WHICH A SECANT UPDATE IS BEING */
/*     APPLIED -- IT COMPUTES A CHOLESKY FACTOR  LPLUS  OF */
/*     L * (I + Z*W**T) * (I + W*Z**T) * L**T.  IT IS ASSUMED THAT  W */
/*     AND  Z  HAVE BEEN CHOSEN SO THAT THE UPDATED MATRIX IS STRICTLY */
/*     POSITIVE DEFINITE. */

    nu = one;
    eta = zero;
    if (*n <= 1) goto L30;
    nm1 = *n - 1;

/*  *** TEMP: STORE S(J)= SUM OVER K = J+1 TO N OF W(K)**2 IN LAMBDA(J) */
    s = zero;
    i_1 = nm1;
    for (i = 1; i <= i_1; ++i) {
		j = *n - i;
		r_1 = w[j + 1];
		s += r_1 * r_1;
		lambda[j] = s;
    }

/*  ***  COMPUTE LAMBDA, GAMMA, AND BETA BY GOLDFARB*S RECURRENCE 3. */
    i_1 = nm1;
    for (j = 1; j <= i_1; ++j) {
		wj = w[j];
		a = nu * z[j] - eta * wj;
		theta = one + a * wj;
		s = a * lambda[j];
		r_1 = theta;
		lj = sqrt(r_1 * r_1 + a * s);
		if (theta > zero) lj = -lj;
		lambda[j] = lj;
		b = theta * wj + s;
		gamma[j] = b * nu / lj;
		beta[j] = (a - b * eta) / lj;
		nu = -nu / lj;
		r_1 = a;
		eta = -(eta + r_1 * r_1 / (theta - lj)) / lj;
    }
L30:
    lambda[*n] = one + (nu * z[*n] - eta * w[*n]) * w[*n];

/*  *** UPDATE L, GRADUALLY OVERWRITING W AND Z WITH L*W AND L*Z. */
    np1 = *n + 1;
    jj = *n * (*n + 1) / 2;
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
		j = np1 - k;
		lj = lambda[j];
		ljj = l[jj];
		lplus[jj] = lj * ljj;
		wj = w[j];
		w[j] = ljj * wj;
		zj = z[j];
		z[j] = ljj * zj;
		if (k == 1) goto L50;
		bj = beta[j];
		gj = gamma[j];
		ij = jj + j;
		jp1 = j + 1;
		i_2 = *n;
		for (i = jp1; i <= i_2; ++i) {
			lij = l[ij];
			lplus[ij] = lj * lij + bj * w[i] + gj * z[i];
			w[i] += lij * wj;
			z[i] += lij * zj;
			ij += i;
		}
L50:
		jj -= j;
    }
    return 0;
}

double snrm2_(int *n,double *sx,int *incx)
{
    static double zero = 0.;
    static double one = 1.;
    static double cutlo = 4.441e-16;
    static double cuthi = 1.304e19;
    int i_1, i_2;
    double ret_val, r_1;
    static double xmax;
    static int next, i, j, nn;
    static double hitest, sum;
    --sx;
/* ***PURPOSE  Euclidean length (L2 norm) of vector */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       SX  vector with N elements */
/*     INCX  storage spacing between elements of SX */
/*     --Output-- */
/*    SNRM2  result (zero if N .LE. 0) */
/*     Euclidean norm of the N-vector stored in SX() with storage */
/*     increment INCX . */
/*     If N .LE. 0, return with result = 0. */
/*     If N .GE. 1, then INCX must be .GE. 1 */
/*     Four Phase Method using two built-in constants that are */
/*     hopefully applicable to all machines. */
/*     CUTLO = maximum of  SQRT(U/EPS)  over all known machines. */
/*     CUTHI = minimum of  SQRT(V)      over all known machines. */
/*     where */
/*     EPS = smallest no. such that EPS + 1. .GT. 1. */
/*     U   = smallest positive no.   (underflow limit) */
/*     V   = largest  no.            (overflow  limit) */
/*     Brief Outline of Algorithm.. */
/*     Phase 1 scans zero components. */
/*     Move to phase 2 when a component is nonzero and .LE. CUTLO */
/*     Move to phase 3 when a component is .GT. CUTLO */
/*     Move to phase 4 when a component is .GE. CUTHI/M */
/*     where M = N for X() double and M = 2*N for complex. */
    if (*n > 0) goto L10;
    ret_val = zero;
    goto L300;
L10:
    next = 0;
    sum = zero;
    nn = *n * *incx;
/*  BEGIN MAIN LOOP */
    i = 1;
L20:
    switch (next) {
		case 0: goto L30;
		case 1: goto L50;
		case 2: goto L70;
		case 3: goto L110;
    }
L30:
    if ((r_1 = sx[i], fabs(r_1)) > cutlo) goto L85;
    next = 1;
    xmax = zero;
/*  PHASE 1.SUM IS ZERO */
L50:
    if (sx[i] == zero) goto L200;
    if ((r_1 = sx[i], fabs(r_1)) > cutlo) goto L85;
/*  PREPARE FOR PHASE 2. */
    next = 2;
    goto L105;
/*  PREPARE FOR PHASE 4. */
L100:
    i = j;
    next = 3;
    sum = sum / sx[i] / sx[i];
L105:
    xmax = (r_1 = sx[i], fabs(r_1));
    goto L115;
/*  PHASE 2.  SUM IS SMALL. */
/*  SCALE TO AVOID DESTRUCTIVE UNDERFLOW. */
L70:
    if ((r_1 = sx[i], fabs(r_1)) > cutlo) goto L75;

/*  COMMON CODE FOR PHASES 2 AND 4. */
/*  IN PHASE 4 SUM IS LARGE. SCALE TO AVOID OVERFLOW */
L110:
    if ((r_1 = sx[i], fabs(r_1)) <= xmax) goto L115;
    r_1 = xmax / sx[i];
    sum = one + sum * (r_1 * r_1);
    xmax = (r_1 = sx[i], fabs(r_1));
    goto L200;
L115:
    r_1 = sx[i] / xmax;
    sum += r_1 * r_1;
    goto L200;
/*  PREPARE FOR PHASE 3. */
L75:
    sum = sum * xmax * xmax;
/*  FOR double OR D.P. SET HITEST = CUTHI/N */
/*  FOR COMPLEX      SET HITEST = CUTHI/(2*N) */
L85:
    hitest = cuthi / (double) (*n);
/*  PHASE 3.  SUM IS MID-RANGE.  NO SCALING. */
    i_1 = nn;
    i_2 = *incx;
    for (j = i; i_2 < 0 ? j >= i_1 : j <= i_1; j += i_2) {
		if ((r_1 = sx[j], fabs(r_1)) >= hitest) goto L100;
		r_1 = sx[j];
		sum += r_1 * r_1;
    }
    ret_val = sqrt(sum);
    goto L300;
L200:
    i += *incx;
    if (i <= nn) goto L20;
/*  END OF MAIN LOOP. */
/*  COMPUTE SQUARE ROOT AND ADJUST FOR SCALING. */
    ret_val = xmax * sqrt(sum);
L300:
    return ret_val;
}

int dbdog_(double *dig,double *g,int *lv,int *n,double *nwtstp,double *step,double *v)
{
    static double half = .5;
    static int gthg = 44;
    static int gtstep = 4;
    static int nreduc = 6;
    static int nwtfac = 46;
    static int preduc = 7;
    static int radius = 8;
    static int stppar = 5;
    static double one = 1.;
    static double two = 2.;
    static double zero = 0.;
    static int bias = 43;
    static int dgnorm = 1;
    static int dstnrm = 2;
    static int dst0 = 3;
    static int grdfac = 45;
    int i_1;
    double r_1, r_2;
    static int i;
    static double cfact, t, relax, cnorm, gnorm, t1, t2, rlambd, ghinvg, femnsq,
	     ctrnwt, nwtnrm;
    --dig;
    --g;
    --nwtstp;
    --step;
    --v;
/*  ***  COMPUTE DOUBLE DOGLEG STEP  *** */
/*       THIS SUBROUTINE COMPUTES A CANDIDATE STEP (FOR USE IN AN UNCON-*/
/*     STRAINED MINIMIZATION CODE) BY THE DOUBLE DOGLEG ALGORITHM OF */
/*     DENNIS AND MEI (REF. 1), WHICH IS A VARIATION ON POWELL*S DOGLEG */
/*     SCHEME (REF. 2, P. 95). */
/*    DIG (INPUT) DIAG(D)**-2 * G -- SEE ALGORITHM NOTES. */
/*      G (INPUT) THE CURRENT GRADIENT VECTOR. */
/*     LV (INPUT) LENGTH OF V. */
/*      N (INPUT) NUMBER OF COMPONENTS IN  DIG, G, NWTSTP,  AND  STEP. */
/* NWTSTP (INPUT) NEGATIVE NEWTON STEP -- SEE ALGORITHM NOTES. */
/*   STEP (OUTPUT) THE COMPUTED STEP. */
/*      V (I/O) VALUES ARRAY, THE FOLLOWING COMPONENTS OF WHICH ARE */
/*             USED HERE... */
/* V(BIAS)   (INPUT) BIAS FOR RELAXED NEWTON STEP, WHICH IS V(BIAS) OF */
/*             THE WAY FROM THE FULL NEWTON TO THE FULLY RELAXED NEWTON */
/*             STEP.  RECOMMENDED VALUE = 0.8 . */
/* V(DGNORM) (INPUT) 2-NORM OF DIAG(D)**-1 * G -- SEE ALGORITHM NOTES. */
/* V(DSTNRM) (OUTPUT) 2-NORM OF DIAG(D) * STEP, WHICH IS V(RADIUS) */
/*             UNLESS V(STPPAR) = 0 -- SEE ALGORITHM NOTES. */
/* V(DST0) (INPUT) 2-NORM OF DIAG(D) * NWTSTP -- SEE ALGORITHM NOTES. */
/* V(GRDFAC) (OUTPUT) THE COEFFICIENT OF  DIG  IN THE STEP RETURNED -- */
/*             STEP(I) = V(GRDFAC)*DIG(I) + V(NWTFAC)*NWTSTP(I). */
/* V(GTHG)   (INPUT) SQUARE-ROOT OF (DIG**T) * (HESSIAN) * DIG -- SEE */
/*             ALGORITHM NOTES. */
/* V(GTSTEP) (OUTPUT) INNER PRODUCT BETWEEN G AND STEP. */
/* V(NREDUC) (OUTPUT) FUNCTION REDUCTION PREDICTED FOR THE FULL NEWTON */
/*             STEP. */
/* V(NWTFAC) (OUTPUT) THE COEFFICIENT OF  NWTSTP  IN THE STEP RETURNED -- */
/*             SEE V(GRDFAC) ABOVE. */
/* V(PREDUC) (OUTPUT) FUNCTION REDUCTION PREDICTED FOR THE STEP RETURNED. */
/* V(RADIUS) (INPUT) THE TRUST REGION RADIUS.  D TIMES THE STEP RETURNED */
/*             HAS 2-NORM V(RADIUS) UNLESS V(STPPAR) = 0. */
/* V(STPPAR) (OUTPUT) CODE TELLING HOW STEP WAS COMPUTED... 0 MEANS A */
/*             FULL NEWTON STEP.  BETWEEN 0 AND 1 MEANS V(STPPAR) OF THE */
/*             WAY FROM THE NEWTON TO THE RELAXED NEWTON STEP.  BETWEEN */
/*             1 AND 2 MEANS A TRUE DOUBLE DOGLEG STEP, V(STPPAR) - 1 OF */
/*             THE WAY FROM THE RELAXED NEWTON TO THE CAUCHY STEP. */
/*             GREATER THAN 2 MEANS 1 / (V(STPPAR) - 1) TIMES THE CAUCHY */
/*             STEP. */
/*     LET  G  AND  H  BE THE CURRENT GRADIENT AND HESSIAN APPROXIMA- */
/*     TION RESPECTIVELY AND LET D BE THE CURRENT SCALE VECTOR.  THIS */
/*     ROUTINE ASSUMES DIG = DIAG(D)**-2 * G  AND  NWTSTP = H**-1 * G. */
/*     THE STEP COMPUTED IS THE SAME ONE WOULD GET BY REPLACING G AND H */
/*     BY  DIAG(D)**-1 * G  AND  DIAG(D)**-1 * H * DIAG(D)**-1, */
/*     COMPUTING STEP, AND TRANSLATING STEP BACK TO THE ORIGINAL */
/*     VARIABLES, I.E., PREMULTIPLYING IT BY DIAG(D)**-1. */
/*  ***  REFERENCES  *** */
/* 1. DENNIS, J.E., AND MEI, H.H.W. (1979), TWO NEW UNCONSTRAINED OPTI- */
/*             MIZATION ALGORITHMS WHICH USE FUNCTION AND GRADIENT */
/*             VALUES, J. OPTIM. THEORY APPLIC. 28, PP. 453-482. */
/* 2. POWELL, M.J.D. (1970), A HYBRID METHOD FOR NON-LINEAR EQUATIONS, */
/*             IN NUMERICAL METHODS FOR NON-LINEAR EQUATIONS, EDITED BY */
/*             P. RABINOWITZ, GORDON AND BREACH, LONDON. */

    nwtnrm = v[dst0];
    rlambd = one;
    if (nwtnrm > zero) rlambd = v[radius] / nwtnrm;
    gnorm = v[dgnorm];
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) step[i] = g[i] / gnorm;
    ghinvg = sdot_(n, &step[1], &c__1, &nwtstp[1], &c__1);
    v[nreduc] = half * ghinvg * gnorm;
    v[grdfac] = zero;
    v[nwtfac] = zero;
    if (rlambd < one) goto L30;

/*  ***  THE NEWTON STEP IS INSIDE THE TRUST REGION  *** */
    v[stppar] = zero;
    v[dstnrm] = nwtnrm;
    v[gtstep] = -ghinvg * gnorm;
    v[preduc] = v[nreduc];
    v[nwtfac] = -one;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) step[i] = -nwtstp[i];
    goto L999;
L30:
    v[dstnrm] = v[radius];
    r_1 = gnorm / v[gthg];
    cfact = r_1 * r_1;

/*  ***  CAUCHY STEP = -CFACT * G. */
    cnorm = gnorm * cfact;
    relax = one - v[bias] * (one - cnorm / ghinvg);
    if (rlambd < relax) goto L50;

/*  ***  STEP IS BETWEEN RELAXED NEWTON AND FULL NEWTON STEPS  ***/
    v[stppar] = one - (rlambd - relax) / (one - relax);
    t = -rlambd;
    v[gtstep] = t * ghinvg * gnorm;
    v[preduc] = rlambd * (one - half * rlambd) * ghinvg * gnorm;
    v[nwtfac] = t;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) step[i] = t * nwtstp[i];
    goto L999;
L50:
    if (cnorm < v[radius]) goto L70;

/*  ***  THE CAUCHY STEP LIES OUTSIDE THE TRUST REGION -- */
/*  ***  STEP = SCALED CAUCHY STEP  *** */
    t = -v[radius] / gnorm;
    v[grdfac] = t;
    v[stppar] = one + cnorm / v[radius];
    v[gtstep] = -v[radius] * gnorm;
    r_1 = v[gthg] / gnorm;
    v[preduc] = v[radius] * (gnorm - half * v[radius] * (r_1 * r_1));
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) step[i] = t * dig[i];
    goto L999;

/*  ***  COMPUTE DOGLEG STEP BETWEEN CAUCHY AND RELAXED NEWTON  *** */
/*  ***  FEMUR = RELAXED NEWTON STEP MINUS CAUCHY STEP  *** */

L70:
    ctrnwt = cfact * relax * ghinvg / gnorm;
/*  *** CTRNWT = INNER PROD. OF CAUCHY AND RELAXED NEWTON STEPS, */
/*  *** SCALED BY GNORM**-2. */
    r_1 = cfact;
    t1 = ctrnwt - r_1 * r_1;
/*  ***  T1 = INNER PROD. OF FEMUR AND CAUCHY STEP, SCALED BY */
/*  ***  GNORM**-2. */
    r_1 = v[radius] / gnorm;
    r_2 = cfact;
    t2 = r_1 * r_1 - r_2 * r_2;
    r_1 = relax * nwtnrm / gnorm;
    femnsq = r_1 * r_1 - ctrnwt - t1;
/*  ***  FEMNSQ = SQUARE OF 2-NORM OF FEMUR, SCALED BY GNORM**-2. */
    r_1 = t1;
    t = t2 / (t1 + sqrt(r_1 * r_1 + femnsq * t2));
/*  ***  DOGLEG STEP  =  CAUCHY STEP  +  T * FEMUR. */
    t1 = (t - one) * cfact;
    v[grdfac] = t1;
    t2 = -t * relax;
    v[nwtfac] = t2;
    v[stppar] = two - t;
    v[gtstep] = gnorm * (t1 * gnorm + t2 * ghinvg);
    r_1 = v[gthg] * t1;
    v[preduc] = -(t1 * gnorm) * ((t2 + one) * gnorm) - t2 * gnorm 
	    * (one + half * t2) * ghinvg - half * (r_1 * r_1);
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) step[i] = t1 * dig[i] + t2 * nwtstp[i];
L999:
    return 0;
}

int dgemm_(char *transa, char *transb, int *m, int *n,                             
	int *k, double *alpha, double *a, int *lda, 
	double *b, int *ldb, double *beta, double *c, int *ldc)
{
    static int info;
    static int nota, notb;
    static double temp;
    static int i, j, l, ncola;
    static int nrowa, nrowb;
	extern int lsame_();

/*  DGEMM  performs matrix-matrix C := alpha*op(A)*op(B) + beta*C,   
    op(X) is one of op(X) = X   or   op(X) = X',   
    alpha and beta are scalars, and A, B and C are matrices, with op(A) 
      an m by k matrix,  op(B)  a  k by n matrix and  C an m by n matrix. 
    TRANSA - CHARACTER*1.   
             TRANSA specifies the form of op(A) to be used
                TRANSA = 'N' or 'n',  op(A) = A.   
                TRANSA = 'T' or 't',  op(A) = A'.   
                TRANSA = 'C' or 'c',  op(A) = A'.   
    TRANSB - CHARACTER*1.   
             TRANSB specifies the form of op(B) to be used
                TRANSB = 'N' or 'n',  op(B) = B.   
                TRANSB = 'T' or 't',  op(B) = B'.   
                TRANSB = 'C' or 'c',  op(B) = B'.   
    M      - int.  M  specifies  the number  of rows  of the  matrix 
             op(A)  and of the  matrix  C.  M  must  be at least  zero. 
    N      - int. N  specifies the number  of columns of the matrix 
             op(B) and the number of columns of the matrix C. 
    K      - int. K  specifies  the number of columns of the matrix 
             op(A) and the number of rows of the matrix op(B).
    ALPHA  - DOUBLE PRECISION.   
             On entry, ALPHA specifies the scalar alpha.   
    A      - DOUBLE PRECISION array of DIMENSION (LDA, ka), where ka is 
             k  when  TRANSA = 'N' or 'n',  and is  m  otherwise.   
             Before entry with  TRANSA = 'N' or 'n',  the leading  m by k 
             part of the array  A  must contain the matrix  A,  otherwise 
             the leading  k by m  part of the array
    LDA    - int. LDA specifies the first dimension of A as declared 
             in the calling (sub) program. When  TRANSA = 'N' or 'n' then 
             LDA must be at least  max(1, m), otherwise  LDA must be at 
             least  max(1, k).   
    B      - DOUBLE PRECISION array of DIMENSION (LDB, kb), where kb is 
             n  when  TRANSB = 'N' or 'n',  and is  k  otherwise.   
             Before entry with  TRANSB = 'N' or 'n',  the leading  k by n 
             part of the array  B  must contain the matrix  B,  otherwise 
             the leading  n by k  part of the array  B
    LDB    - int. LDB specifies the first dimension of B as declared 
             in the calling (sub) program. When  TRANSB = 'N' or 'n' then 
             LDB must be at least  max(1, k), otherwise  LDB must be at 
             least  max(1, n).   
    BETA   - DOUBLE. BETA specifies the scalar  beta.  When  BETA  is 
             supplied as zero then C need not be set on input.   
    C      - DOUBLE PRECISION array of DIMENSION (LDC, n).   
             Before entry, the leading  m by n  part of the array  C must 
             contain the matrix  C,  except when  beta  is zero, in which 
             case C need not be set on entry.   
             On exit, the array  C  is overwritten by the  m by n  matrix 
             (alpha*op(A)*op(B) + beta*C).   
    LDC    - int. LDC specifies the first dimension of C as declared 
             in  the  calling  (sub)  program.   LDC  must  be  at  least 
             max(1, m).   */
#define A(I,J) a[(I)-1 + ((J)-1)* (*lda)]
#define B(I,J) b[(I)-1 + ((J)-1)* (*ldb)]
#define C(I,J) c[(I)-1 + ((J)-1)* (*ldc)]
    nota = lsame_(transa, "N");
    notb = lsame_(transb, "N");
    if (nota) {
		nrowa = *m;
		ncola = *k;
    } else {
		nrowa = *k;
		ncola = *m;
    }
    if (notb) nrowb = *k;
    else nrowb = *n;
/*  Test the input parameters. */
    info = 0;
    if (! nota && ! lsame_(transa, "C") && ! lsame_(transa, "T")) info = 1;
    else if (! notb && ! lsame_(transb, "C") && ! lsame_(transb, "T")) info = 2;
    else if (*m < 0) info = 3;
    else if (*n < 0) info = 4;
    else if (*k < 0) info = 5;
    else if (*lda < MAX(1,nrowa)) info = 8;
    else if (*ldb < MAX(1,nrowb)) info = 10;
    else if (*ldc < MAX(1,*m)) info = 13;

    if (info != 0) {
	    WRITELOG("** DGEMM, parameter %2d had an illegal value\n", info);
		return 0;
    }
/*  Quick return if possible. */
    if (*m == 0 || *n == 0 || (*alpha == 0. || *k == 0) && *beta == 1.) return 0;
/*  And if  alpha.eq.zero. */
    if (*alpha == 0.) {
		if (*beta == 0.) {
			for (j = 1; j <= *n; ++j) {
				for (i = 1; i <= *m; ++i) C(i,j) = 0.;
			}
		} else {
			for (j = 1; j <= *n; ++j) {
				for (i = 1; i <= *m; ++i) C(i,j) = *beta * C(i,j);
			}
		}
		return 0;
    }
/*  Start the operations. */
    if (notb) {
		if (nota) {
/*  Form  C := alpha*A*B + beta*C. */
		    for (j = 1; j <= *n; ++j) {
				if (*beta == 0.) {
					for (i = 1; i <= *m; ++i) C(i,j) = 0.;
				} else if (*beta != 1.) {
					for (i = 1; i <= *m; ++i) C(i,j) = *beta * C(i,j);
				}
				for (l = 1; l <= *k; ++l) {
					if (B(l,j) != 0.) {
						temp = *alpha * B(l,j);
						for (i = 1; i <= *m; ++i) C(i,j) += temp * A(i,l);
					}
				}
			}
		} else {
/*  Form  C := alpha*A'*B + beta*C */
			for (j = 1; j <= *n; ++j) {
				for (i = 1; i <= *m; ++i) {
					temp = 0.;
					for (l = 1; l <= *k; ++l) temp += A(l,i) * B(l,j);
					if (*beta == 0.) C(i,j) = *alpha * temp;
					else C(i,j) = *alpha * temp + *beta * C(i,j);
				}
			}
		}
	} else {
		if (nota) {
/*  Form  C := alpha*A*B' + beta*C */
			for (j = 1; j <= *n; ++j) {
			if (*beta == 0.) {
				for (i = 1; i <= *m; ++i) C(i,j) = 0.;
			} else if (*beta != 1.) {
				for (i = 1; i <= *m; ++i) C(i,j) = *beta * C(i,j);
			}
			for (l = 1; l <= *k; ++l) {
				if (B(j,l) != 0.) {
					temp = *alpha * B(j,l);
					for (i = 1; i <= *m; ++i) C(i,j) += temp * A(i,l);
				}
			}
	    
			}
		} else {
/*  Form  C := alpha*A'*B' + beta*C */
			for (j = 1; j <= *n; ++j) {
				for (i = 1; i <= *m; ++i) {
					temp = 0.;
					for (l = 1; l <= *k; ++l) temp += A(l,i) * B(j,l);
					if (*beta == 0.) C(i,j) = *alpha * temp;
					else C(i,j) = *alpha * temp + *beta * C(i,j);
				}
			}
		}
	}
    return 0;
}

int lsame_(char *ca, char *cb)
{
    int ret_val;
    static int inta, intb, zcode;

/*  LSAME returns .TRUE. if CA is the same letter as CB regardless of case
.   
    Arguments   
    =========   
    CA      (input) CHARACTER*1   
    CB      (input) CHARACTER*1   
    CA and CB specify the single characters to be compared.   
   ===================================================================== */

/*  Test if the characters are equal */
    ret_val = *(unsigned char *)ca == *(unsigned char *)cb;
    if (ret_val) return ret_val;

/*  Now test for equivalence if both characters are alphabetic. */
    zcode = 'Z';

/*  Use Z rather than A so that ASCII can be detected on Prime   
    machines, on which ICHAR returns a value with bit 8 set.   
    ICHAR(A) on Prime machines returns 193 which is the same as   
    ICHAR(A) on an EBCDIC machine. */
    inta = *(unsigned char *)ca;
    intb = *(unsigned char *)cb;
    if (zcode == 90 || zcode == 122) {

/*  ASCII is assumed - ZCODE is the ASCII code of either lower or upper case Z */
		if (inta >= 97 && inta <= 122) inta += -32;
		if (intb >= 97 && intb <= 122) intb += -32;
	}
    else if (zcode == 233 || zcode == 169) {

/*  EBCDIC is assumed - ZCODE is the EBCDIC code of either lower or upper case Z */
		if (inta >= 129 && inta <= 137 || inta >= 145 && inta <= 153 || inta 
			>= 162 && inta <= 169) inta += 64;
		if (intb >= 129 && intb <= 137 || intb >= 145 && intb <= 153 || intb 
			>= 162 && intb <= 169) intb += 64;
		else if (zcode == 218 || zcode == 250) {

/*  ASCII is assumed, on Prime machines - ZCODE is the ASCII code   
    plus 128 of either lower or upper case Z */
			if (inta >= 225 && inta <= 250) inta += -32;
			if (intb >= 225 && intb <= 250) intb += -32;
		}
    }
    ret_val = inta == intb;
    return ret_val;
}

//void genmn(int p,double *mn,double *parm,double *x,double *work,int *iseed)
/*
**********************************************************************
              GENerate Multivariate Normal random deviate
                              Arguments
     parm --> Parameters needed to generate multivariate normal
               deviates (MEANV and Cholesky decomposition of
               COVM). Set by a previous call to SETGMN.
               1 : 1                - size of deviate, P
               2 : P + 1            - mean vector
               P+2 : P*(P+3)/2 + 1  - upper half of cholesky
                                       decomposition of cov matrix
     x    <-- Vector deviate generated.
     work <--> Scratch array
                              Method
     1) Generate P independent standard normal deviates - Ei ~ N(0,1)
     2) Using Cholesky decomposition find A s.t. trans(A)*A = COVM
     3) trans(A)E + MEANV ~ N(MEANV,COVM)
**********************************************************************
*/
//{
//int i,icount,j,D1,D2,D3,D4;
//double ae;

/*
     Generate P independent normal deviates - WORK ~ N(0,1)
*/
//    for (i=1; i<=p; i++) work[i-1] = snorm(iseed); 
//    for (i=1,D3=1,D4=(p-i+D3)/D3; D4>0; D4--,i+=D3) {
/*
     PARM (P+2 : P*(P+3)/2 + 1) contains A, the Cholesky
      decomposition of the desired covariance matrix.
          trans(A)(1,1) = PARM(P+2)
          trans(A)(2,1) = PARM(P+3)
          trans(A)(2,2) = PARM(P+2+P)
          trans(A)(3,1) = PARM(P+4)
          trans(A)(3,2) = PARM(P+3+P)
          trans(A)(3,3) = PARM(P+2-1+2P)  ...
     trans(A)*WORK + MEANV ~ N(MEANV,COVM)
*/
//        icount = 0;
//        ae = 0.0;
//        for (j=1,D1=1,D2=(i-j+D1)/D1; D2>0; D2--,j+=D1) {
//            icount += (j-1);
//            ae += (*(parm+(i-1)+(j-1)*p-icount)**(work+j-1));
//        }
//        *(x+i-1) = ae+*(mn+i-1);
//    }
//}

int assst_(double *d,int *iv,int *p,double *step,double *stlstg,double *v,double *x,double *x0)
{
    static double half = .5;
    static int radinc = 8;
    static int restor = 9;
    static int stage = 10;
    static int stglim = 11;
    static int switch_ = 12;
    static int toobig = 2;
    static int xirc = 13;
    static int afctol = 31;
    static int decfac = 22;
    static int dstnrm = 2;
    static double one = 1.;
    static int dst0 = 3;
    static int dstsav = 18;
    static int f = 10;
    static int fdif = 11;
    static int flstgd = 12;
    static int f0 = 13;
    static int gtslst = 14;
    static int gtstep = 4;
    static int incfac = 23;
    static int lmaxs = 36;
    static double two = 2.;
    static int nreduc = 6;
    static int plstgd = 15;
    static int preduc = 7;
    static int radfac = 16;
    static int rdfcmn = 24;
    static int rdfcmx = 25;
    static int reldx = 17;
    static int rfctol = 32;
    static int sctol = 37;
    static int stppar = 5;
    static double zero = 0.;
    static int tuner1 = 26;
    static int tuner2 = 27;
    static int tuner3 = 28;
    static int xctol = 33;
    static int xftol = 34;
    static int irc = 29;
    static int mlstgd = 32;
    static int model = 5;
    static int nfcall = 6;
    static int nfgcal = 7;
    int i_1;
    double r_1, r_2;
    static double emax, xmax, rfac1;
    static int i;
    static double emaxs;
    static int goodx;
    static double reldx1;
    static int nfc;
    static double gts;
    --d;
    --iv;
    --step;
    --stlstg;
    --v;
    --x;
    --x0;
/*  ***  ASSESS CANDIDATE STEP *** */
/*     THIS SUBROUTINE IS CALLED BY AN UNCONSTRAINED MINIMIZATION */
/*     ROUTINE TO ASSESS THE NEXT CANDIDATE STEP.  IT MAY RECOMMEND ONE */
/*     OF SEVERAL COURSES OF ACTION, SUCH AS ACCEPTING THE STEP, RECOM- */
/*     PUTING IT USING THE SAME OR A NEW QUADRATIC MODEL, OR HALTING DUE*/
/*     TO CONVERGENCE OR FALSE CONVERGENCE.  SEE THE RETURN CODE LISTING*/
/*     BELOW. */
/* --------------------------  PARAMETER USAGE -------------------------- */
/*     IV (I/O) int PARAMETER AND SCRATCH VECTOR -- SEE DESCRIPTION */
/*             BELOW OF IV VALUES REFERENCED. */
/*      D (IN)  SCALE VECTOR USED IN COMPUTING V(RELDX) -- SEE BELOW. */
/*      P (IN)  NUMBER OF PARAMETERS BEING OPTIMIZED. */
/*   STEP (I/O) ON INPUT, STEP IS THE STEP TO BE ASSESSED.  IT IS UN- */
/*             CHANGED ON OUTPUT UNLESS A PREVIOUS STEP ACHIEVED A */
/*             BETTER OBJECTIVE FUNCTION REDUCTION, IN WHICH CASE STLSTG*/
/*             WILL HAVE BEEN COPIED TO STEP. */
/* STLSTG (I/O) WHEN ASSESS RECOMMENDS RECOMPUTING STEP EVEN THOUGH THE */
/*             CURRENT (OR A PREVIOUS) STEP YIELDS AN OBJECTIVE FUNC- */
/*             TION DECREASE, IT SAVES IN STLSTG THE STEP THAT GAVE THE */
/*             BEST FUNCTION REDUCTION SEEN SO FAR (IN THE CURRENT ITERA-*/
/*             TION).  IF THE RECOMPUTED STEP YIELDS A LARGER FUNCTION */
/*             VALUE, THEN STEP IS RESTORED FROM STLSTG AND */
/*             X = X0 + STEP IS RECOMPUTED. */
/*      V (I/O) REAL PARAMETER AND SCRATCH VECTOR -- SEE DESCRIPTION */
/*             BELOW OF V VALUES REFERENCED. */
/*      X (I/O) ON INPUT, X = X0 + STEP IS THE POINT AT WHICH THE OBJEC-*/
/*             TIVE FUNCTION HAS JUST BEEN EVALUATED.  IF AN EARLIER */
/*             STEP YIELDED A BIGGER FUNCTION DECREASE, THEN X IS */
/*             RESTORED TO THE CORRESPONDING EARLIER VALUE.  OTHERWISE, */
/*             IF THE CURRENT STEP DOES NOT GIVE ANY FUNCTION DECREASE, */
/*             THEN X IS RESTORED TO X0. */
/*     X0 (IN)  INITIAL OBJECTIVE FUNCTION PARAMETER VECTOR (AT THE */
/*             START OF THE CURRENT ITERATION). */

/*  ***  IV VALUES REFERENCED  *** */

/*    IV(IRC) (I/O) ON INPUT FOR THE FIRST STEP TRIED IN A NEW ITERATION, */
/*             IV(IRC) SHOULD BE SET TO 3 OR 4 (THE VALUE TO WHICH IT IS */
/*             SET WHEN STEP IS DEFINITELY TO BE ACCEPTED).  ON INPUT */
/*             AFTER STEP HAS BEEN RECOMPUTED, IV(IRC) SHOULD BE */
/*             UNCHANGED SINCE THE PREVIOUS RETURN OF ASSESS. */
/*                ON OUTPUT, IV(IRC) IS A RETURN CODE HAVING ONE OF THE */
/*             FOLLOWING VALUES... */
/*                  1 = SWITCH MODELS OR TRY SMALLER STEP. */
/*                  2 = SWITCH MODELS OR ACCEPT STEP. */
/*                  3 = ACCEPT STEP AND DETERMINE V(RADFAC) BY GRADIENT */
/*                       TESTS. */
/*                  4 = ACCEPT STEP, V(RADFAC) HAS BEEN DETERMINED. */
/*                  5 = RECOMPUTE STEP (USING THE SAME MODEL). */
/*                  6 = RECOMPUTE STEP WITH RADIUS = V(LMAXS) BUT DO NOT */
/*                       EVAULATE THE OBJECTIVE FUNCTION. */
/*                  7 = X-CONVERGENCE (SEE V(XCTOL)). */
/*                  8 = RELATIVE FUNCTION CONVERGENCE (SEE V(RFCTOL)). */
/*                  9 = BOTH X- AND RELATIVE FUNCTION CONVERGENCE. */
/*                 10 = ABSOLUTE FUNCTION CONVERGENCE (SEE V(AFCTOL)). */
/*                 11 = SINGULAR CONVERGENCE (SEE V(LMAXS)). */
/*                 12 = FALSE CONVERGENCE (SEE V(XFTOL)). */
/*                 13 = IV(IRC) WAS OUT OF RANGE ON INPUT. */
/*             RETURN CODE I HAS PRECDENCE OVER I+1 FOR I = 9, 10, 11. */
/* IV(MLSTGD) (I/O) SAVED VALUE OF IV(MODEL). */
/*  IV(MODEL) (I/O) ON INPUT, IV(MODEL) SHOULD BE AN int IDENTIFYING */
/*             THE CURRENT QUADRATIC MODEL OF THE OBJECTIVE FUNCTION. */
/*             IF A PREVIOUS STEP YIELDED A BETTER FUNCTION REDUCTION, */
/*             THEN IV(MODEL) WILL BE SET TO IV(MLSTGD) ON OUTPUT. */
/* IV(NFCALL) (IN)  INVOCATION COUNT FOR THE OBJECTIVE FUNCTION. */
/* IV(NFGCAL) (I/O) VALUE OF IV(NFCALL) AT STEP THAT GAVE THE BIGGEST */
/*             FUNCTION REDUCTION THIS ITERATION.  IV(NFGCAL) REMAINS */
/*             UNCHANGED UNTIL A FUNCTION REDUCTION IS OBTAINED. */
/* IV(RADINC) (I/O) THE NUMBER OF RADIUS INCREASES (OR MINUS THE NUMBER */
/*             OF DECREASES) SO FAR THIS ITERATION. */
/* IV(RESTOR) (OUT) SET TO 0 UNLESS X AND V(F) HAVE BEEN RESTORED, IN */
/*             WHICH CASE ASSESS SETS IV(RESTOR) = 1. */
/*  IV(STAGE) (I/O) COUNT OF THE NUMBER OF MODELS TRIED SO FAR IN THE */
/*             CURRENT ITERATION. */
/* IV(STGLIM) (IN)  MAXIMUM NUMBER OF MODELS TO CONSIDER. */
/* IV(SWITCH) (OUT) SET TO 0 UNLESS A NEW MODEL IS BEING TRIED AND IT */
/*             GIVES A SMALLER FUNCTION VALUE THAN THE PREVIOUS MODEL, */
/*             IN WHICH CASE ASSESS SETS IV(SWITCH) = 1. */
/* IV(TOOBIG) (IN)  IS NONZERO IF STEP WAS TOO BIG (E.G. IF IT CAUSED */
/*             OVERFLOW). */
/*   IV(XIRC) (I/O) VALUE THAT IV(IRC) WOULD HAVE IN THE ABSENCE OF */
/*             CONVERGENCE, FALSE CONVERGENCE, AND OVERSIZED STEPS. */

/*  ***  V VALUES REFERENCED  *** */

/* V(AFCTOL) (IN)  ABSOLUTE FUNCTION CONVERGENCE TOLERANCE.  IF THE */
/*             ABSOLUTE VALUE OF THE CURRENT FUNCTION VALUE V(F) IS LESS */
/*             THAN V(AFCTOL), THEN ASSESS RETURNS WITH IV(IRC) = 10. */
/* V(DECFAC) (IN)  FACTOR BY WHICH TO DECREASE RADIUS WHEN IV(TOOBIG) IS */
/*             NONZERO. */
/* V(DSTNRM) (IN)  THE 2-NORM OF D*STEP. */
/* V(DSTSAV) (I/O) VALUE OF V(DSTNRM) ON SAVED STEP. */
/*   V(DST0) (IN)  THE 2-NORM OF D TIMES THE NEWTON STEP (WHEN DEFINED, */
/*             I.E., FOR V(NREDUC) .GE. 0). */
/*      V(F) (I/O) ON BOTH INPUT AND OUTPUT, V(F) IS THE OBJECTIVE FUNC- */
/*             TION VALUE AT X.  IF X IS RESTORED TO A PREVIOUS VALUE, */
/*             THEN V(F) IS RESTORED TO THE CORRESPONDING VALUE. */
/*   V(FDIF) (OUT) THE FUNCTION REDUCTION V(F0) - V(F) (FOR THE OUTPUT */
/*             VALUE OF V(F) IF AN EARLIER STEP GAVE A BIGGER FUNCTION */
/*             DECREASE, AND FOR THE INPUT VALUE OF V(F) OTHERWISE). */
/* V(FLSTGD) (I/O) SAVED VALUE OF V(F). */
/*     V(F0) (IN)  OBJECTIVE FUNCTION VALUE AT START OF ITERATION. */
/* V(GTSLST) (I/O) VALUE OF V(GTSTEP) ON SAVED STEP. */
/* V(GTSTEP) (IN)  INNER PRODUCT BETWEEN STEP AND GRADIENT. */
/* V(INCFAC) (IN)  MINIMUM FACTOR BY WHICH TO INCREASE RADIUS. */
/*  V(LMAXS) (IN)  MAXIMUM REASONABLE STEP SIZE (AND INITIAL STEP BOUND). */
/*             IF THE ACTUAL FUNCTION DECREASE IS NO MORE THAN TWICE */
/*             WHAT WAS PREDICTED, IF A RETURN WITH IV(IRC) = 7, 8, 9, */
/*             OR 10 DOES NOT OCCUR, IF V(DSTNRM) .GT. V(LMAXS), AND IF */
/*             V(PREDUC) .LE. V(SCTOL) * ABS(V(F0)), THEN ASSESS RE- */
/*             TURNS WITH IV(IRC) = 11.  IF SO DOING APPEARS WORTHWHILE, */
/*             THEN ASSESS REPEATS THIS TEST WITH V(PREDUC) COMPUTED FOR */
/*             A STEP OF LENGTH V(LMAXS) (BY A RETURN WITH IV(IRC) = 6). */
/* V(NREDUC) (I/O)  FUNCTION REDUCTION PREDICTED BY QUADRATIC MODEL FOR */
/*             NEWTON STEP.  IF ASSESS IS CALLED WITH IV(IRC) = 6, I.E., */
/*             IF V(PREDUC) HAS BEEN COMPUTED WITH RADIUS = V(LMAXS) FOR */
/*             USE IN THE SINGULAR CONVERVENCE TEST, THEN V(NREDUC) IS */
/*             SET TO -V(PREDUC) BEFORE THE LATTER IS RESTORED. */
/* V(PLSTGD) (I/O) VALUE OF V(PREDUC) ON SAVED STEP. */
/* V(PREDUC) (I/O) FUNCTION REDUCTION PREDICTED BY QUADRATIC MODEL FOR */
/*             CURRENT STEP. */
/* V(RADFAC) (OUT) FACTOR TO BE USED IN DETERMINING THE NEW RADIUS, */
/*             WHICH SHOULD BE V(RADFAC)*DST, WHERE  DST  IS EITHER THE */
/*             OUTPUT VALUE OF V(DSTNRM) OR THE 2-NORM OF */
/*             DIAG(NEWD)*STEP  FOR THE OUTPUT VALUE OF STEP AND THE */
/*             UPDATED VERSION, NEWD, OF THE SCALE VECTOR D.  FOR */
/*             IV(IRC) = 3, V(RADFAC) = 1.0 IS RETURNED. */
/* V(RDFCMN) (IN)  MINIMUM VALUE FOR V(RADFAC) IN TERMS OF THE INPUT */
/*             VALUE OF V(DSTNRM) -- SUGGESTED VALUE = 0.1. */
/* V(RDFCMX) (IN)  MAXIMUM VALUE FOR V(RADFAC) -- SUGGESTED VALUE = 4.0. */
/*  V(RELDX) (OUT) SCALED RELATIVE CHANGE IN X CAUSED BY STEP, COMPUTED */
/*             BY FUNCTION  RELDST  AS */
/*                 MAX (D(I)*ABS(X(I)-X0(I)), 1 .LE. I .LE. P) / */
/*                    MAX (D(I)*(ABS(X(I))+ABS(X0(I))), 1 .LE. I .LE. P). */
/*             IF AN ACCEPTABLE STEP IS RETURNED, THEN V(RELDX) IS COM- */
/*             PUTED USING THE OUTPUT (POSSIBLY RESTORED) VALUES OF X */
/*             AND STEP.  OTHERWISE IT IS COMPUTED USING THE INPUT */
/*             VALUES. */
/* V(RFCTOL) (IN)  RELATIVE FUNCTION CONVERGENCE TOLERANCE.  IF THE */
/*             ACTUAL FUNCTION REDUCTION IS AT MOST TWICE WHAT WAS PRE- */
/*             DICTED AND  V(NREDUC) .LE. V(RFCTOL)*ABS(V(F0)),  THEN */
/*             ASSESS RETURNS WITH IV(IRC) = 8 OR 9. */
/* V(STPPAR) (IN)  MARQUARDT PARAMETER -- 0 MEANS FULL NEWTON STEP. */
/* V(TUNER1) (IN)  TUNING CONSTANT USED TO DECIDE IF THE FUNCTION */
/*             REDUCTION WAS MUCH LESS THAN EXPECTED.  SUGGESTED */
/*             VALUE = 0.1. */
/* V(TUNER2) (IN)  TUNING CONSTANT USED TO DECIDE IF THE FUNCTION */
/*             REDUCTION WAS LARGE ENOUGH TO ACCEPT STEP.  SUGGESTED */
/*             VALUE = 10**-4. */
/* V(TUNER3) (IN)  TUNING CONSTANT USED TO DECIDE IF THE RADIUS */
/*             SHOULD BE INCREASED.  SUGGESTED VALUE = 0.75. */
/*  V(XCTOL) (IN)  X-CONVERGENCE CRITERION.  IF STEP IS A NEWTON STEP */
/*             (V(STPPAR) = 0) HAVING V(RELDX) .LE. V(XCTOL) AND GIVING */
/*             AT MOST TWICE THE PREDICTED FUNCTION DECREASE, THEN */
/*             ASSESS RETURNS IV(IRC) = 7 OR 9. */
/*  V(XFTOL) (IN)  FALSE CONVERGENCE TOLERANCE.  IF STEP GAVE NO OR ONLY */
/*             A SMALL FUNCTION DECREASE AND V(RELDX) .LE. V(XFTOL), */
/*             THEN ASSESS RETURNS WITH IV(IRC) = 12. */

/*        ON THE FIRST CALL OF AN ITERATION, ONLY THE I/O VARIABLES */
/*     STEP, X, IV(IRC), IV(MODEL), V(F), V(DSTNRM), V(GTSTEP), AND */
/*     V(PREDUC) NEED HAVE BEEN INITIALIZED.  BETWEEN CALLS, NO I/O */
/*     VALUES EXECPT STEP, X, IV(MODEL), V(F) AND THE STOPPING TOLER- */
/*     ANCES SHOULD BE CHANGED. */
/*        AFTER A RETURN FOR CONVERGENCE OR FALSE CONVERGENCE, ONE CAN */
/*     CHANGE THE STOPPING TOLERANCES AND CALL ASSESS AGAIN, IN WHICH */
/*     CASE THE STOPPING TESTS WILL BE REPEATED. */

/*  ***  REFERENCES  *** */

/*     (1) DENNIS, J.E., JR., GAY, D.M., AND WELSCH, R.E. (1981), */
/*        AN ADAPTIVE NONLINEAR LEAST-SQUARES ALGORITHM, */
/*        ACM TRANS. MATH. SOFTWARE, VOL. 7, NO. 3. */

/*     (2) POWELL, M.J.D. (1970)  A FORTRAN SUBROUTINE FOR SOLVING */
/*        SYSTEMS OF NONLINEAR ALGEBRAIC EQUATIONS, IN NUMERICAL */
/*        METHODS FOR NONLINEAR ALGEBRAIC EQUATIONS, EDITED BY */
/*        P. RABINOWITZ, GORDON AND BREACH, LONDON. */
 
    nfc = iv[nfcall];
    iv[switch_] = 0;
    iv[restor] = 0;
    rfac1 = one;
    goodx = TRUE;
    i = iv[irc];
    if (i >= 1 && i <= 12) {
		switch (i) {
		    case 1:  goto L20;
		    case 2:  goto L30;
		    case 3:  goto L10;
		    case 4:  goto L10;
		    case 5:  goto L40;
		    case 6:  goto L280;
		    case 7:  goto L220;
	 		case 8:  goto L220;
		    case 9:  goto L220;
			case 10:  goto L220;
			case 11:  goto L220;
			case 12:  goto L170;
		}
    }
    iv[irc] = 13;
    goto L999;

/*  ***  INITIALIZE FOR NEW ITERATION  *** */
L10:
    iv[stage] = 1; iv[radinc] = 0; v[flstgd] = v[f0];
    if (iv[toobig] == 0) goto L90;
    iv[stage] = -1;
    iv[xirc] = i;
    goto L60;

/*  ***  STEP WAS RECOMPUTED WITH NEW MODEL OR SMALLER RADIUS  *** */
/*  ***  FIRST DECIDE WHICH  *** */
L20:
    if (iv[model] != iv[mlstgd]) goto L30;

/*  ***  OLD MODEL RETAINED, SMALLER RADIUS TRIED  *** */
/*  ***  DO NOT CONSIDER ANY MORE NEW MODELS THIS ITERATION  *** */
    iv[stage] = iv[stglim];
    iv[radinc] = -1;
    goto L90;

/*  ***  A NEW MODEL IS BEING TRIED.  DECIDE WHETHER TO KEEP IT.  *** */
L30:
    ++iv[stage];
/*  ***  NOW WE ADD THE POSSIBILTIY THAT STEP WAS RECOMPUTED WITH  *** */
/*  ***  THE SAME MODEL, PERHAPS BECAUSE OF AN OVERSIZED STEP.     *** */
L40:
    if (iv[stage] > 0) goto L50;

/*  ***  STEP WAS RECOMPUTED BECAUSE IT WAS TOO BIG.  *** */
	if (iv[toobig] != 0) goto L60;

/*  ***  RESTORE IV(STAGE) AND PICK UP WHERE WE LEFT OFF.  *** */
    iv[stage] = -iv[stage];
    i = iv[xirc];
    switch (i) {
		case 1:  goto L20;
		case 2:  goto L30;
		case 3:  goto L90;
		case 4:  goto L90;
		case 5:  goto L70;
    }
L50:
    if (iv[toobig] == 0) goto L70;

/*  ***  HANDLE OVERSIZE STEP  *** */
    if (iv[radinc] > 0) goto L80;
    iv[stage] = -iv[stage];
    iv[xirc] = iv[irc];
L60:
    v[radfac] = v[decfac];
    --iv[radinc];
    iv[irc] = 5;
    goto L999;
L70:
    if (v[f] < v[flstgd]) goto L90;
/*  *** THE NEW STEP IS A LOSER. RESTORE OLD MODEL.  *** */

    if (iv[model] == iv[mlstgd]) goto L80;
    iv[model] = iv[mlstgd];
    iv[switch_] = 1;

/*  ***  RESTORE STEP, ETC. ONLY IF A PREVIOUS STEP DECREASED V(F). */
L80:
    if (v[flstgd] >= v[f0]) goto L90;
    iv[restor] = 1;
    v[f] = v[flstgd];
    v[preduc] = v[plstgd];
    v[gtstep] = v[gtslst];
    if (iv[switch_] == 0) rfac1 = v[dstnrm] / v[dstsav];
    v[dstnrm] = v[dstsav];
    nfc = iv[nfgcal];
    goodx = FALSE;
/*  ***  COMPUTE RELATIVE CHANGE IN X BY CURRENT STEP  *** */
L90:
    reldx1 = reldst_(p, &d[1], &x[1], &x0[1]);

/*  ***  RESTORE X AND STEP IF NECESSARY  *** */
    if (goodx) goto L110;
    i_1 = *p;
    for (i = 1; i <= i_1; ++i) {
		step[i] = stlstg[i];
		x[i] = x0[i] + stlstg[i];
    }
L110:
    v[fdif] = v[f0] - v[f];
    if (v[fdif] > v[tuner2] * v[preduc]) goto L140;

/*  ***  NO (OR ONLY A TRIVIAL) FUNCTION DECREASE */
/*  ***  -- SO TRY NEW MODEL OR SMALLER RADIUS */
    v[reldx] = reldx1;
    if (v[f] < v[f0]) goto L120;
    iv[mlstgd] = iv[model];
    v[flstgd] = v[f];
    v[f] = v[f0];
    scopy_(p, &x0[1], &c__1, &x[1], &c__1);
    iv[restor] = 1;
    goto L130;
L120:
    iv[nfgcal] = nfc;
L130:
    iv[irc] = 1;
    if (iv[stage] < iv[stglim]) goto L160;
    iv[irc] = 5;
    --iv[radinc];
    goto L160;
/*  ***  NONTRIVIAL FUNCTION DECREASE ACHIEVED  *** */
L140:
    iv[nfgcal] = nfc;
    rfac1 = one;
    if (goodx) v[reldx] = reldx1;
    v[dstsav] = v[dstnrm];
    if (v[fdif] > v[preduc] * v[tuner1]) goto L190;

/*  ***  DECREASE WAS MUCH LESS THAN PREDICTED -- EITHER CHANGE MODELS */
/*  ***  OR ACCEPT STEP WITH DECREASED RADIUS. */
    if (iv[stage] >= iv[stglim]) goto L150;
/*  ***  CONSIDER SWITCHING MODELS  *** */
    iv[irc] = 2;
    goto L160;

/*  ***  ACCEPT STEP WITH DECREASED RADIUS  *** */
L150:
    iv[irc] = 4;
/*  ***  SET V(RADFAC) TO FLETCHER*S DECREASE FACTOR  *** */
L160:
    iv[xirc] = iv[irc];
    emax = v[gtstep] + v[fdif];
    v[radfac] = half * rfac1;
    if (emax < v[gtstep]) {/* Computing MAX */
		r_1 = v[rdfcmn], r_2 = half * v[gtstep] / emax;
		v[radfac] = rfac1 * FMAX(r_2,r_1);
    }
/*  ***  DO FALSE CONVERGENCE TEST  *** */
L170:
    if (v[reldx] <= v[xftol]) goto L180;
    iv[irc] = iv[xirc];
    if (v[f] < v[f0]) goto L200;
    goto L230;
L180:
    iv[irc] = 12;
    goto L240;
/*  ***  HANDLE GOOD FUNCTION DECREASE  *** */
L190:
    if (v[fdif] < -(double)v[tuner3] * v[gtstep]) goto L210;

/*  ***  INCREASING RADIUS LOOKS WORTHWHILE.  SEE IF WE JUST */
/*  ***  RECOMPUTED STEP WITH A DECREASED RADIUS OR RESTORED STEP */
/*  ***  AFTER RECOMPUTING IT WITH A LARGER RADIUS. */
    if (iv[radinc] < 0) goto L210;
    if (iv[restor] == 1) goto L210;

/*  ***  WE DID NOT. TRY A LONGER STEP UNLESS THIS WAS A NEWTON STEP */
    v[radfac] = v[rdfcmx];
    gts = v[gtstep];
    if (v[fdif] < (half / v[radfac] - one) * gts) {
		r_1 = v[incfac], r_2 = half * gts / (gts + v[fdif]);
		v[radfac] = FMAX(r_2,r_1);
    }
    iv[irc] = 4;
    if (v[stppar] == zero) goto L230;
/*  ***  STEP WAS NOT A NEWTON STEP. RECOMPUTE IT WITH A LARGER RADIUS */
    iv[irc] = 5;
    ++iv[radinc];

/*  ***  SAVE VALUES CORRESPONDING TO GOOD STEP  *** */
L200:
    v[flstgd] = v[f];
    iv[mlstgd] = iv[model];
    scopy_(p, &step[1], &c__1, &stlstg[1], &c__1);
    v[dstsav] = v[dstnrm];
    iv[nfgcal] = nfc;
    v[plstgd] = v[preduc];
    v[gtslst] = v[gtstep];
    goto L230;

/*  ***  ACCEPT STEP WITH RADIUS UNCHANGED  *** */
L210:
    v[radfac] = one;
    iv[irc] = 3;
    goto L230;

/*  ***  COME HERE FOR A RESTART AFTER CONVERGENCE  *** */
L220:
    iv[irc] = iv[xirc];
    if (v[dstsav] >= zero) goto L240;
    iv[irc] = 12;
    goto L240;

/*  ***  PERFORM CONVERGENCE TESTS  *** */
L230:
    iv[xirc] = iv[irc];
L240:
    if ((r_1 = v[f], fabs(r_1)) < v[afctol]) iv[irc] = 10;
    if (half * v[fdif] > v[preduc]) goto L999;
    emax = v[rfctol] * (r_1 = v[f0], fabs(r_1));
    emaxs = v[sctol] * (r_1 = v[f0], fabs(r_1));
    if (v[dstnrm] > v[lmaxs] && v[preduc] <= emaxs) iv[irc] = 11;
    if (v[dst0] < zero) goto L250;
    i = 0;
    if (v[nreduc] > zero && v[nreduc] <= emax || v[nreduc] == zero && v[preduc] == zero) i = 2;
    if (v[stppar] == zero && v[reldx] <= v[xctol] && goodx) ++i;
    if (i > 0) iv[irc] = i + 6;

/*  *** CONSIDER RECOMPUTING STEP OF LENGTH V(LMAXS) FOR SINGULAR CONVERGENCE TEST */
L250:
    if (iv[irc] > 5 && iv[irc] != 12) goto L999;
    if (v[dstnrm] > v[lmaxs]) goto L260;
    if (v[preduc] >= emaxs) goto L999;
    if (v[dst0] <= zero) goto L270;
    if (half * v[dst0] <= v[lmaxs]) goto L999;
    goto L270;
L260:
    if (half * v[dstnrm] <= v[lmaxs]) goto L999;
    xmax = v[lmaxs] / v[dstnrm];
    if (xmax * (two - xmax) * v[preduc] >= emaxs) goto L999;
L270:
    if (v[nreduc] < zero) goto L290;

/*  ***  RECOMPUTE V(PREDUC) FOR USE IN SINGULAR CONVERGENCE TEST  *** */
    v[gtslst] = v[gtstep];
    v[dstsav] = v[dstnrm];
    if (iv[irc] == 12) v[dstsav] = -v[dstsav];
    v[plstgd] = v[preduc];
    iv[irc] = 6;
    scopy_(p, &step[1], &c__1, &stlstg[1], &c__1);
    goto L999;

/*  *** PERFORM SINGULAR CONVERGENCE TEST WITH RECOMPUTED V(PREDUC)  *** */
L280:
    v[gtstep] = v[gtslst];
    v[dstnrm] = (r_1 = v[dstsav], fabs(r_1));
    scopy_(p, &stlstg[1], &c__1, &step[1], &c__1);
    iv[irc] = iv[xirc];
    if (v[dstsav] <= zero) iv[irc] = 12;
    v[nreduc] = -v[preduc];
    v[preduc] = v[plstgd];
L290:
    if (-(double)v[nreduc] <= v[rfctol] * (r_1 = v[f0], fabs(r_1))) iv[irc] = 11;
L999:
    return 0;
}

static int c__2 = 2;
int vdflt_(int *alg,int *lv,double *v)
{
    static double one = 1.;
    static int dltfdc = 42;
    static int dltfdj = 43;
    static int dtinit = 39;
    static int d0init = 40;
    static int epslon = 19;
    static int eta0 = 42;
    static int fuzz = 45;
    static int huberc = 48;
    static int incfac = 23;
    static int lmax0 = 35;
    static double three = 3.;
    static int lmaxs = 36;
    static int phmnfc = 20;
    static int phmxfc = 21;
    static int rdfcmn = 24;
    static int rdfcmx = 25;
    static int rfctol = 32;
    static int rlimit = 46;
    static int rsptol = 49;
    static int sctol = 37;
    static int sigmin = 50;
    static int afctol = 31;
    static int tuner1 = 26;
    static int tuner2 = 27;
    static int tuner3 = 28;
    static int tuner4 = 29;
    static int tuner5 = 30;
    static int xctol = 33;
    static int xftol = 34;
    static int bias = 43;
    static int cosmin = 47;
    static int decfac = 22;
    static int delta0 = 44;
    static int dfac = 41;
    static int dinit = 38;
    double r_1, r_2, r_3;
    double d_1, d_2;
    static double machep, mepcrt, sqteps;
    --v;
/*  ***  SUPPLY DEFAULT VALUES TO V  *** */
/*  ***  ALG = 1 MEANS REGRESSION CONSTANTS. */
/*  ***  ALG = 2 MEANS GENERAL UNCONSTRAINED OPTIMIZATION CONSTANTS. */
    
	machep=DBL_EPSILON;
    v[afctol] = 1e-20;
    if (machep > 1e-10) {
		r_1 = machep;
		v[afctol] = r_1 * r_1;
    }
    v[decfac] = .5;
    sqteps = sqrt((DBL_EPSILON));
    v[dfac] = .6;
    v[delta0] = sqteps;
    v[dtinit] = 1e-6;
    d_1 = (double) machep; d_2 = (double) (one / three);
    mepcrt = pow(d_1, d_2); 
    v[d0init] = 1.;
    v[epslon] = .1;
    v[incfac] = 2.;
    v[lmax0] = 1.;
    v[lmaxs] = 1.;
    v[phmnfc] = -.1;
    v[phmxfc] = .1;
    v[rdfcmn] = .1;
    v[rdfcmx] = 4.;
    r_3 = mepcrt;
    r_1 = 1e-10;
    r_2 = r_3 * r_3;
    v[rfctol] = FMAX(r_2,r_1);
    v[sctol] = v[rfctol];
    v[tuner1] = .1;
    v[tuner2] = 1e-4;
    v[tuner3] = .75;
    v[tuner4] = .5;
    v[tuner5] = .75;
    v[xctol] = sqteps;
    v[xftol] = machep * 100.;
    if (*alg >= 2) goto L10;
/*  ***  REGRESSION  VALUES */
    r_1 = 1e-6, r_2 = machep * 100.;
    v[cosmin] = FMAX(r_2,r_1);
    v[dinit] = 0.;
    v[dltfdc] = mepcrt;
    v[dltfdj] = sqteps;
    v[fuzz] = 1.5;
    v[huberc] = .7;
    v[rlimit] = sqrt(DBL_MAX) * 16.;
    v[rsptol] = .01;
    v[sigmin] = 1e-4;
    goto L999;
/*  ***  GENERAL OPTIMIZATION VALUES */
L10:
    v[bias] = .8;
    v[dinit] = -1.;
    v[eta0] = machep * 1e3;
L999:
    return 0;
}

int dgedi_(double *a,int *lda,int *n,int *ipvt,double *det,double *work,int *job)
{
    int a_dim1, a_offset, i_1, i_2;
    static int i, j, k, l;
    static double t;
    static int kb, kp1, nm1;
    static double ten;
	extern int dscal_();
	extern int daxpy_();
	extern int dswap_();
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;
    --det;
    --work;

/*     DGEDI computes the determinant and inverse of a matrix */
/*     using the factors computed by DGECO or DGEFA. */
/*     On Entry */
/*        A       DOUBLE PRECISION(LDA, N) */
/*                the output from DGECO or DGEFA. */
/*        LDA     int */
/*                the leading dimension of the array  A . */
/*        N       int */
/*                the order of the matrix  A . */
/*        IPVT    int(N) */
/*                the pivot vector from DGECO or DGEFA. */
/*        WORK    DOUBLE PRECISION(N) */
/*                work vector.  Contents destroyed. */
/*        JOB     int */
/*                = 11   both determinant and inverse. */
/*                = 01   inverse only. */
/*                = 10   determinant only. */
/*     On Return */
/*        A       inverse of original matrix if requested. */
/*                Otherwise unchanged. */
/*        DET     DOUBLE PRECISION(2) */
/*                determinant of original matrix if requested. */
/*                Otherwise not referenced. */
/*                Determinant = DET(1) * 10.0**DET(2) */
/*                with  1.0 .LE. fabs(DET(1)) .LT. 10.0 */
/*                or  DET(1) .EQ. 0.0 . */
/*     Error Condition */
/*        A division by zero will occur if the input factor contains */
/*        a zero on the diagonal and the inverse is requested. */
/*        It will not occur if the subroutines are called correctly */
/*        and if DGECO has set RCOND .GT. 0.0 or DGEFA has set */
/*        INFO .EQ. 0 . */
/* compute determinant */
    if (*job / 10 == 0) goto L70;
    det[1] = 1.;
    det[2] = 0.;
    ten = 10.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	if (ipvt[i] != i) det[1] = -det[1];
	det[1] = a[i + i * a_dim1] * det[1];
	if (det[1] == 0.) goto L60;
L10:
	if (fabs(det[1]) >= 1.) goto L20;
	det[1] = ten * det[1];
	det[2] += -1.;
	goto L10;
L20:
	if (fabs(det[1]) < ten) goto L40;
	det[1] /= ten;
	det[2] += 1.;
	goto L20;
L40:
    ;}
L60:
L70:
/*     COMPUTE INVERSE(U) */
    if (*job % 10 == 0) {
	goto L150;
    }
    i_1 = *n;
    for (k = 1; k <= i_1; ++k) {
	a[k + k * a_dim1] = 1. / a[k + k * a_dim1];
	t = -a[k + k * a_dim1];
	i_2 = k - 1;
	dscal_(&i_2, &t, &a[k * a_dim1 + 1], &c__1);
	kp1 = k + 1;
	if (*n < kp1) {
	    goto L90;
	}
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    t = a[k + j * a_dim1];
	    a[k + j * a_dim1] = 0.;
	    daxpy_(&k, &t, &a[k * a_dim1 + 1], &c__1, &a[j * a_dim1 + 1], &
		    c__1);
	}
L90:
    ;}
/*        FORM INVERSE(U)*INVERSE(L) */
    nm1 = *n - 1;
    if (nm1 < 1) {
	goto L140;
    }
    i_1 = nm1;
    for (kb = 1; kb <= i_1; ++kb) {
	k = *n - kb;
	kp1 = k + 1;
	i_2 = *n;
	for (i = kp1; i <= i_2; ++i) {
	    work[i] = a[i + k * a_dim1];
	    a[i + k * a_dim1] = 0.;
	}
	i_2 = *n;
	for (j = kp1; j <= i_2; ++j) {
	    t = work[j];
	    daxpy_(n, &t, &a[j * a_dim1 + 1], &c__1, &a[k * a_dim1 + 1], &
		    c__1);
	}
	l = ipvt[k];
	if (l != k) {
	    dswap_(n, &a[k * a_dim1 + 1], &c__1, &a[l * a_dim1 + 1], &c__1);
	}
    }
L140:
L150:
    return 0;
}
int dswap_(int *n,double *dx,int *incx,double *dy,int *incy)
{
    int i_1, i_2;
    static int i, m;
    static double dtemp1, dtemp2, dtemp3;
    static int ix, iy, ns, mp1;
    --dx;
    --dy;
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       DX  vector with N elements */
/*     INCX  storage spacing between elements of DX */
/*       DY  vector with N elements */
/*     INCY  storage spacing between elements of DY */
/*     --Output-- */
/*       DX  input vector DY (unchanged if N .LE. 0) */
/*       DY  input vector DX (unchanged if N .LE. 0) */
/*     Interchange DX and DY. */
/*     For I = 0 to N-1, interchange  DX(LX+I*INCX) and DY(LY+I*INCY), */
/*     where LX = 1 if INCX .GE. 0, else LX = (-INCX)*N, and LY is */
/*     defined in a similar way using INCY. */
    if (*n <= 0) return 0;
    if (*incx == *incy) {
		if ((i_1 = *incx - 1) < 0) goto L5;
		else if (i_1 == 0) goto L20;
		else goto L60;
    }
L5:
/*  CODE FOR UNEQUAL OR NONPOSITIVE INCREMENTS. */
    ix = 1;
    iy = 1;
    if (*incx < 0) ix = (-(*n) + 1) * *incx + 1;
    if (*incy < 0) iy = (-(*n) + 1) * *incy + 1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		dtemp1 = dx[ix];
		dx[ix] = dy[iy];
		dy[iy] = dtemp1;
		ix += *incx;
		iy += *incy;
    }
    return 0;
/*  CODE FOR BOTH INCREMENTS EQUAL TO 1 */
/*  CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 3. */
L20:
    m = *n % 3;
    if (m == 0) goto L40;
    i_1 = m;
    for (i = 1; i <= i_1; ++i) {
		dtemp1 = dx[i];
		dx[i] = dy[i];
		dy[i] = dtemp1;
    }
    if (*n < 3) return 0;
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 3) {
		dtemp1 = dx[i];
		dtemp2 = dx[i + 1];
		dtemp3 = dx[i + 2];
		dx[i] = dy[i];
		dx[i + 1] = dy[i + 1];
		dx[i + 2] = dy[i + 2];
		dy[i] = dtemp1;
		dy[i + 1] = dtemp2;
		dy[i + 2] = dtemp3;
    }
    return 0;
L60:
/*  CODE FOR EQUAL, POSITIVE, NONUNIT INCREMENTS. */
    ns = *n * *incx;											 
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
		dtemp1 = dx[i];
		dx[i] = dy[i];
		dy[i] = dtemp1;
    }
    return 0;
}

double randu_(int *iseed)
{
    static double xb = 16807.;
    static double xm = 2147483647.;
    double ret_val, d_1;
    double seed, xnews;
    seed = (double) (*iseed);
    d_1 = xb * seed;
    xnews = fmod(d_1,xm);
    ret_val = xnews / xm;
    *iseed = (int) xnews;
    return ret_val;
} 

static int c_n1 = -1;
int sumit_(double *d,double *fx,double *g,int *iv,int *liv,int *lv,int *n,double *v,double *x)
{
    static int cnvcod = 55;
    static int mxiter = 18;
    static int nfcall = 6;
    static int nfgcal = 7;
    static int ngcall = 30;
    static int niter = 31;
    static int nwtstp = 34;
    static int radinc = 8;
    static int step = 40;
    static int stglim = 11;
    static int stlstg = 41;
    static int dg = 37;
    static int toobig = 2;
    static int xirc = 13;
    static int x0 = 43;
    static int dgnorm = 1;
    static int dinit = 38;
    static int dstnrm = 2;
    static int dst0 = 3;
    static int f = 10;
    static int f0 = 13;
    static int gthg = 44;
    static int g0 = 48;
    static int gtstep = 4;
    static int incfac = 23;
    static int lmat = 42;
    static int lmax0 = 35;
    static int nextv = 47;
    static int radfac = 16;
    static int radius = 8;
    static int rad0 = 9;
    static int tuner4 = 29;
    static int tuner5 = 30;
    static int inith = 25;
    static int vneed = 4;
    static double negone = -1.;
    static double one = 1.;
    static double zero = 0.;
    static int irc = 29;
    static int kagqt = 33;
    static int mode = 35;
    static int model = 5;
    static int mxfcal = 17;
    int i_1;
    static int nn1o2;
    static int temp1, step1;
    static int i, k, l;
    static double t;
    static int w, z;
    static int dummy;
    static int g01, x01, nwtst1;
    static int dg1;
    static int lstgst;
	extern int parck_();
	extern int itsum_();
    --d;
    --g;
    --iv;
    --v;
    --x;
/*  ***  CARRY OUT (UNCONSTRAINED MINIMIZATION) ITERATIONS, USING */
/*  ***  DOUBLE-DOGLEG/BFGS STEPS. */

/* D.... SCALE VECTOR. */
/* FX... FUNCTION VALUE. */
/* G.... GRADIENT VECTOR. */
/* IV... int VALUE ARRAY. */
/* LIV.. LENGTH OF IV (AT LEAST 60). */
/* LV... LENGTH OF V (AT LEAST 71 + N*(N+13)/2). */
/* N.... NUMBER OF VARIABLES (COMPONENTS IN X AND G). */
/* V.... FLOATING-POINT VALUE ARRAY. */
/* X.... VECTOR OF PARAMETERS TO BE OPTIMIZED. */

/*     PARAMETERS IV, N, V, AND X ARE THE SAME */
/*     EXCEPT THAT V CAN BE SHORTER (SINCE */
/*     THE PART OF V FOR STORING G IS NOT NEEDED). */
/*     MOREOVER, IV(1) MAY HAVE THE TWO ADDITIONAL */
/*     OUTPUT VALUES 1 AND 2, WHICH ARE EXPLAINED BELOW, AS IS THE USE */
/*     OF IV(TOOBIG) AND IV(NFGCAL).  THE VALUE IV(G), WHICH IS AN */
/*     OUTPUT VALUE, IS NOT REFERENCED BY */
/*     SUMIT OR THE SUBROUTINES IT CALLS. */
/*     FX AND G NEED NOT HAVE BEEN INITIALIZED WHEN SUMIT IS CALLED */
/*     WITH IV(1) = 12, 13, OR 14. */

/* IV(1) = 1 MEANS THE CALLER SHOULD SET FX TO F(X), THE FUNCTION VALUE */
/*             AT X, AND CALL SUMIT AGAIN, HAVING CHANGED NONE OF THE */
/*             OTHER PARAMETERS.  AN EXCEPTION OCCURS IF F(X) CANNOT BE */
/*             (E.G. IF OVERFLOW WOULD OCCUR), WHICH MAY HAPPEN BECAUSE */
/*             OF AN OVERSIZED STEP.  IN THIS CASE THE CALLER SHOULD SET */
/*             IV(TOOBIG) = IV(2) TO 1, WHICH WILL CAUSE SUMIT TO IG- */
/*             NORE FX AND TRY A SMALLER STEP.  THE PARAMETER NF THAT */
/*             IS PASSED TO CALCF (FOR POSSIBLE USE BY CALCG) IS A */
/*             COPY OF IV(NFCALL) = IV(6). */

/* IV(1) = 2 MEANS THE CALLER SHOULD SET G TO G(X), THE GRADIENT VECTOR */
/*             OF F AT X, AND CALL SUMIT AGAIN, HAVING CHANGED NONE OF */
/*             THE OTHER PARAMETERS EXCEPT POSSIBLY THE SCALE VECTOR D */
/*             WHEN IV(DTYPE) = 0.  THE PARAMETER NF THAT IS PASSED */
/*             TO CALCG IS IV(NFGCAL) = IV(7).  IF G(X) CANNOT BE */
/*             EVALUATED, THEN THE CALLER MAY SET IV(NFGCAL) TO 0, IN */
/*             WHICH CASE SUMIT WILL RETURN WITH IV(1) = 65. */

    i = iv[1];
    if (i == 1) goto L40;
    if (i == 2) goto L50;
/*  ***  CHECK VALIDITY OF IV AND V INPUT VALUES  *** */

    if (iv[1] == 0) deflt_(&c__2, &iv[1], liv, lv, &v[1]);
    iv[vneed] += *n * (*n + 13) / 2;
    parck_(&c__2, &d[1], &iv[1], liv, lv, n, &v[1]);
    i = iv[1] - 2;
    if (i > 12) goto L999;
    switch (i) {
		case 1:  goto L160;
		case 2:  goto L160;
		case 3:  goto L160;
		case 4:  goto L160;
		case 5:  goto L160;
		case 6:  goto L160;
		case 7:  goto L110;
		case 8:  goto L80;
		case 9:  goto L110;
		case 10:  goto L10;
		case 11:  goto L10;
		case 12:  goto L20;
    }
/*  ***  STORAGE ALLOCATION  *** */
L10:
    nn1o2 = *n * (*n + 1) / 2;
    l = iv[lmat];
    iv[x0] = l + nn1o2;
    iv[step] = iv[x0] + *n;
    iv[stlstg] = iv[step] + *n;
    iv[g0] = iv[stlstg] + *n;
    iv[nwtstp] = iv[g0] + *n;
    iv[dg] = iv[nwtstp] + *n;
    iv[nextv] = iv[dg] + *n;
    if (iv[1] != 13) goto L20;
    iv[1] = 14;
    goto L999;
/*  ***  INITIALIZATION  *** */
L20:
    iv[nfcall] = 1;
    iv[ngcall] = 1;
    iv[nfgcal] = 1;
    iv[mode] = -1;
    iv[model] = 1;
    iv[stglim] = 1;
    iv[toobig] = 0;
    iv[cnvcod] = 0;
    iv[radinc] = 0;
    v[rad0] = zero;
    if (v[dinit] >= zero) vscopy_(n, &d[1], &v[dinit]);
    if (iv[inith] != 1) goto L40;

/*  ***  SET THE INITIAL HESSIAN APPROXIMATION TO DIAG(D)**-2 */
    vscopy_(&nn1o2, &v[l], &zero);
    k = l - 1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		k += i;
		t = d[i];
		if (t <= zero) t = one;
		v[k] = t;
    }
    iv[1] = 1;
    goto L999;
L40:
    v[f] = *fx;
    if (iv[mode] >= 0) goto L160;
    iv[1] = 2;
    if (iv[toobig] == 0) goto L999;
    iv[1] = 63;
    goto L270;
/*  ***  MAKE SURE GRADIENT COULD BE COMPUTED  *** */
L50:
    if (iv[nfgcal] != 0) goto L60;
    iv[1] = 65;
    goto L270;
L60:
    dg1 = iv[dg];
    vvmulp_(n, &v[dg1], &g[1], &d[1], &c_n1);
    v[dgnorm] = snrm2_(n, &v[dg1], &c__1);
    if (iv[cnvcod] != 0) goto L260;
    if (iv[mode] == 0) goto L220;

/*  ALLOW FIRST STEP TO HAVE SCALED 2-NORM AT MOST V(LMAX0)  *** */
    v[radfac] = v[lmax0];
    v[dstnrm] = one;
    iv[mode] = 0;

/* -----------------------------  MAIN LOOP  
----------------------------- */

/*  PRINT ITERATION SUMMARY, CHECK ITERATION LIMIT  *** */
L70:
    itsum_(&d[1], &g[1], &iv[1], liv, lv, n, &v[1], &x[1]);
/* trace for derivative option */
//    if (iv[19] < 0) traceOutput("Gradient", *n, &g[1]);
L80:
    k = iv[niter];
    if (k < iv[mxiter]) goto L90;
    iv[1] = 10;
    goto L270;
/*  ***  UPDATE RADIUS  *** */
L90:
    iv[niter] = k + 1;
    v[radius] = v[radfac] * v[dstnrm];

/*  ***  INITIALIZE FOR START OF NEXT ITERATION  *** */
    g01 = iv[g0];
    x01 = iv[x0];
    v[f0] = v[f];
    iv[irc] = 4;
    iv[kagqt] = -1;

/*  ***  COPY X TO X0, G TO G0  *** */
    scopy_(n, &x[1], &c__1, &v[x01], &c__1);
    scopy_(n, &g[1], &c__1, &v[g01], &c__1);

/*  ***  CHECK STOPX AND FUNCTION EVALUATION LIMIT  *** */
L100:
    if (! stopx_(&dummy)) goto L120;
    iv[1] = 11;
    goto L130;

/*  COME HERE WHEN RESTARTING AFTER FUNC. EVAL. LIMIT OR STOPX. */
L110:
    if (v[f] >= v[f0]) goto L120;
    v[radfac] = one;
    k = iv[niter];
    goto L90;
L120:
    if (iv[nfcall] < iv[mxfcal]) goto L140;
    iv[1] = 9;
L130:
    if (v[f] >= v[f0]) goto L270;

/*  ***  IN CASE OF STOPX OR FUNCTION EVALUATION LIMIT WITH */
/*  ***  IMPROVED V(F), EVALUATE THE GRADIENT AT X. */
    iv[cnvcod] = iv[1];
    goto L210;
/* . . . . . . . . . . . . .  COMPUTE CANDIDATE STEP  . . . . . . . . . . 
*/
L140:
    step1 = iv[step];
    dg1 = iv[dg];
    nwtst1 = iv[nwtstp];
    if (iv[kagqt] >= 0) goto L150;
    l = iv[lmat];
    livmul_(n, &v[nwtst1], &v[l], &g[1]);
    litvmu_(n, &v[nwtst1], &v[l], &v[nwtst1]);
    vvmulp_(n, &v[step1], &v[nwtst1], &d[1], &c__1);
    v[dst0] = snrm2_(n, &v[step1], &c__1);
    vvmulp_(n, &v[dg1], &v[dg1], &d[1], &c_n1);
    ltvmul_(n, &v[step1], &v[l], &v[dg1]);
    v[gthg] = snrm2_(n, &v[step1], &c__1);
    iv[kagqt] = 0;
L150:
    dbdog_(&v[dg1], &g[1], lv, n, &v[nwtst1], &v[step1], &v[1]);
    if (iv[irc] == 6) goto L160;

/*  ***  COMPUTE F(X0 + STEP)  *** */
    x01 = iv[x0];
    step1 = iv[step];
    vaxpy_(n, &x[1], &one, &v[step1], &v[x01]);
    ++iv[nfcall];
    iv[1] = 1;
    iv[toobig] = 0;
    goto L999;

/* . . . . . . . . . . . . .  ASSESS CANDIDATE STEP  . . . . . . . . . . 
. */

L160:
    step1 = iv[step];
    lstgst = iv[stlstg];
    x01 = iv[x0];
    assst_(&d[1], &iv[1], n, &v[step1], &v[lstgst], &v[1], &x[1], &v[x01]);

    k = iv[irc];
    switch (k) {
		case 1:  goto L170;
		case 2:  goto L200;
		case 3:  goto L200;
		case 4:  goto L200;
		case 5:  goto L170;
		case 6:  goto L180;
		case 7:  goto L190;
		case 8:  goto L190;
		case 9:  goto L190;
		case 10:  goto L190;
		case 11:  goto L190;
		case 12:  goto L190;
		case 13:  goto L250;
		case 14:  goto L220;
    }
/*  RECOMPUTE STEP WITH CHANGED RADIUS  *** */
L170:
    v[radius] = v[radfac] * v[dstnrm];
    goto L100;

/*  COMPUTE STEP OF LENGTH V(LMAX0) FOR SINGULAR CONVERGENCE TEST. */
L180:
    v[radius] = v[lmax0];
    goto L140;

/*  CONVERGENCE OR FALSE CONVERGENCE  *** */
L190:
    iv[cnvcod] = k - 4;
    if (v[f] >= v[f0]) goto L260;
    if (iv[xirc] == 14) goto L260;
    iv[xirc] = 14;
/* . . . . . . . . . . . .  PROCESS ACCEPTABLE STEP  . . . . . . . . . . 
. */
L200:
    if (iv[irc] != 3) goto L210;
    step1 = iv[step];
    temp1 = iv[stlstg];

/*  SET  TEMP1 = HESSIAN * STEP  FOR USE IN GRADIENT TESTS  *** */
    l = iv[lmat];
    ltvmul_(n, &v[temp1], &v[l], &v[step1]);
    lvmul_(n, &v[temp1], &v[l], &v[temp1]);

/*  COMPUTE GRADIENT  *** */
L210:
    ++iv[ngcall];
    iv[1] = 2;
    goto L999;

/*  INITIALIZATIONS -- G0 = G - G0, ETC.  *** */
L220:
    g01 = iv[g0];
    vaxpy_(n, &v[g01], &negone, &v[g01], &g[1]);
    step1 = iv[step];
    temp1 = iv[stlstg];
    if (iv[irc] != 3) goto L240;

/*  SET V(RADFAC) BY GRADIENT TESTS  *** */
/*  SET  TEMP1 = DIAG(D)**-1 * (HESSIAN*STEP + (G(X0)-G(X))) */
    vaxpy_(n, &v[temp1], &negone, &v[g01], &v[temp1]);
    vvmulp_(n, &v[temp1], &v[temp1], &d[1], &c_n1);

/*  DO GRADIENT TESTS  *** */
    if (snrm2_(n,&v[temp1],&c__1) <= v[dgnorm] * v[tuner4]) goto L230;
    if (sdot_(n,&g[1],&c__1,&v[step1],&c__1) >= v[gtstep] * v[tuner5]) goto L240;
L230:
    v[radfac] = v[incfac];

/*  UPDATE H, LOOP  *** */
L240:
    w = iv[nwtstp];
    z = iv[x0];
    l = iv[lmat];
    wzbfgs_(&v[l], n, &v[step1], &v[w], &v[g01], &v[z]);

/*     ** USE THE N-VECTORS STARTING AT V(STEP1) AND V(G01) FOR SCRATCH.. 
*/
    lupdat_(&v[temp1], &v[step1], &v[l], &v[g01], &v[l], n, &v[w], &v[z]);
    iv[1] = 2;
    goto L70;
/*  ***  BAD PARAMETERS TO ASSESS  *** */
L250:
    iv[1] = 64;
/*  ***  PRINT SUMMARY OF FINAL ITERATION AND OTHER REQUESTED ITEMS */
L260:
    iv[1] = iv[cnvcod];
    iv[cnvcod] = 0;
L270:
    itsum_(&d[1], &g[1], &iv[1], liv, lv, n, &v[1], &x[1]);
L999:
    return 0;
}

int itsum_(double *d, double *g, int *iv, int *liv, int *lv, int *p, double *v, double *x)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	static int		f = 10;
	static int		f0 = 13;
	static int		fdif = 11;
	static int		nreduc = 6;
	static int		needhd = 36;
	static int		preduc = 7;
	static int		reldx = 17;
	static int		nfcall = 6;
	static int		nfcov = 52;
	static int		niter = 31;
	static int		outlev = 19;
	static int		prntit = 39;
	int				i_1;
	double			r_1, r_2, r_3, r_4;
	static double	oldf;
	static double	reldf;
	static int		nf, ol;
	static double	nreldf, preldf;
	static int		iv1;
	char buf[90];

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	--d;
	--g;
	--iv;
	--v;
	--x;

	iv1 = iv[1];
	if (iv1 > 62) iv1 += -51;
	ol = iv[outlev];
	if (!(iv1 < 2 || ol == 0 || iv1 >= 12 || (iv1 >= 10 && iv[prntit] == 0)))
	{
		if (iv1 == 2 && iv[niter] == 0)
		{
			iv[needhd] = 0;
			iv[prntit] = 0;

			if (ol < 0) 
			{
				sprintf(buf, "     0  %18.7f\n", v[f]);
				SF_display(buf);
			}
			goto L999;
		}
		if (iv1 <= 2) 
		{
			++iv[prntit];
			if (iv[prntit] < abs(ol)) goto L999;
		}
		nf = iv[nfcall] - (i_1 = iv[nfcov], abs(i_1));
		iv[prntit] = 0;
		reldf = 0.;
		preldf = 0.;
		r_3 = (r_1 = v[f0], fabs(r_1)), r_4 = (r_2 = v[f], fabs(r_2));
		oldf = FMAX(r_4, r_3);
		if (oldf > 0.)
		{
			reldf = v[fdif] / oldf;
			preldf = v[preduc] / oldf;
		}
		if (ol <= 0)
		{
			iv[needhd] = 0;
			sprintf(buf, "%6d  %18.7f  %11.8f\n", iv[niter], v[f], reldf * 100);
			SF_display(buf);
		} else
		{
			iv[needhd] = 0;
			nreldf = 0.;
			if (oldf > 0.) nreldf = v[nreduc] / oldf;
		}
	}
L999:
	return 0;
}

static int c__3 = 3;
int parck_(int *alg,double *d,int *iv,int *liv,int *lv,int *n,double *v)
{
    static int algsav = 51;
    static int lmat = 42;
    static int nextiv = 46;
    static int nextv = 47;
    static int nvdflt = 50;
    static int oldn = 38;
    static int parprt = 20;
    static int parsav = 49;
    static int perm = 58;
    static int prunit = 21;
    static int vneed = 4;
    static int dinit = 38;
    static double big = 0.;
    static double machep = -1.;
    static double tiny = 1.;
    static double zero = 0.;
    static double vm[34] = {.001,-.99,.001,.01,
	    1.2,.01,1.2,0.,0.,.001,
	    -1.,0.0,0.0,0.0,0.,
	    0.,0.0,0.0,0.,
	    -10.,0.,0.,0.,
	    0.0,0.0,0.0,1.01,
	    1e10,0.0,0.,0.,0.,
	    0.0,0. };
    static double vx[34] = { .9,-.001,10.,.8,
	    100.,.8,100.,.5,.5,1.,
	    1.,0.0,0.0,.1,1.,
	    1.,0.0,0.0,1.,0.0,
	    0.0,0.0,1.,1.,1.,
	    1.,1e10,0.0,
	    1.,0.0,1.,1.,1.,1. };
    static int dtype = 16;
    static int ijmp = 33;
    static int jlim[2] = { 0,24 };
    static int ndflt[2] = { 32,25 };
    static int miniv[2] = { 80,59 };
    static int dtype0 = 54;
    static int epslon = 19;
    static int inits = 25;
    static int ivneed = 3;
    static int lastiv = 44;
    static int lastv = 45;
    int i_1, i_2;
    static int i, j, k, l, m;
    static int parsv1, ii;
    static double vk;
    static int pu, ndfalt, iv1, miv1, miv2;

    --d;
    --iv;
    --v;

/*  CHECK PARAMETERS *** */
/*  ALG = 1 FOR REGRESSION, ALG = 2 FOR GENERAL UNCONSTRAINED OPT. */
/*  VDFLT  -- SUPPLIES DEFAULT PARAMETER VALUES TO V ALONE. */

    if (*alg < 1 || *alg > 2) goto L330;
    if (iv[1] == 0) deflt_(alg, &iv[1], liv, lv, &v[1]);
    pu = iv[prunit];
    miv1 = miniv[*alg - 1];
    if (perm <= *liv) {
		i_1 = miv1, i_2 = iv[perm] - 1;
		miv1 = MAX(i_2,i_1);
    }
    if (ivneed <= *liv) {
		i_1 = iv[ivneed];
		miv2 = miv1 + MAX(0,i_1);
    }
    if (lastiv <= *liv) iv[lastiv] = miv2;
    if (*liv < miv1) goto L290;
    iv[ivneed] = 0;
    i_1 = iv[vneed];
    iv[lastv] = MAX(0,i_1) + iv[lmat] - 1;
    if (*liv < miv2) goto L290;
    if (*lv < iv[lastv]) goto L310;
    iv[vneed] = 0;
    if (*alg == iv[algsav]) goto L20;
    iv[1] = 82;
    goto L999;
L20:
    iv1 = iv[1];
    if (iv1 < 12 || iv1 > 14) goto L50;
    if (*n >= 1) goto L40;
    iv[1] = 81;
    goto L999;
L40:
    if (iv1 != 14) iv[nextiv] = iv[perm];
    if (iv1 != 14) iv[nextv] = iv[lmat];
    if (iv1 == 13) goto L999;
    k = iv[parsav] - epslon;
    i_1 = *lv - k;
    vdflt_(alg, &i_1, &v[k + 1]);
    iv[dtype0] = 2 - *alg;
    iv[oldn] = *n;
    goto L100;
L50:
    if (*n == iv[oldn]) goto L70;
    iv[1] = 17;
    goto L999;
L70:
    if (iv1 <= 11 && iv1 >= 1) goto L100;    
    iv[1] = 80;
    goto L999;
L100:
    if (iv1 == 14) iv1 = 12;
    if (big > tiny) goto L110;
	tiny=DBL_MIN;
	machep=DBL_EPSILON;
	big=DBL_MAX;
    vm[11] = machep;
    vx[11] = big;
    vm[12] = tiny;
    vx[12] = big;
    vm[13] = machep;
    vm[16] = tiny;
    vx[16] = big;
    vm[17] = tiny;
    vx[17] = big;
    vx[19] = big;
    vx[20] = big;
    vx[21] = big;
    vm[23] = machep;
    vm[24] = machep;
    vm[25] = machep;
    vx[27] = sqrt(DBL_MAX) * 16.;
    vm[28] = machep;
    vx[29] = big;
    vm[32] = machep;
L110:
    m = 0;
    i = 1;
    j = jlim[*alg - 1];
    k = epslon;
    ndfalt = ndflt[*alg - 1];
    i_1 = ndfalt;
    for (l = 1; l <= i_1; ++l) {
		vk = v[k];
		if (vk >= vm[i - 1] && vk <= vx[i - 1]) goto L130;
		m = k;
L130:
		++k;
		++i;
		if (i == j) i = ijmp;
    }
    if (iv[nvdflt] == ndfalt) goto L160;
    iv[1] = 51;
    goto L999;
L160:
    if ((iv[dtype] > 0 || v[dinit] > zero) && iv1 == 12) goto L190;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
		if (d[i] > zero) goto L180;
		m = 18;
L180:
    ;}
L190:
    if (m == 0) goto L200;
    iv[1] = m;
    goto L999;
L200:
    if (pu == 0 || iv[parprt] == 0) goto L999;
    if (iv1 != 12 || iv[inits] == *alg - 1) goto L220;    
    m = 1;
L220:
    if (iv[dtype] == iv[dtype0]) goto L240;    
    m = 1;
L240:
    i = 1;
    j = jlim[*alg - 1];
    k = epslon;
    l = iv[parsav];
    ndfalt = ndflt[*alg - 1];
    i_1 = ndfalt;
    for (ii = 1; ii <= i_1; ++ii) {
		if (v[k] == v[l]) goto L270;
		m = 1;
L270:
		++k;
		++l;
		++i;
		if (i == j) i = ijmp;
    }
    iv[dtype0] = iv[dtype];
    parsv1 = iv[parsav];
    scopy_(&iv[nvdflt], &v[epslon], &c__1, &v[parsv1], &c__1);
    goto L999;
L290:
    iv[1] = 15;
    if (pu == 0) goto L999;
    if (*liv < miv1) goto L999;
    if (*lv < iv[lastv]) goto L310;
    goto L999;
L310:
    iv[1] = 16;
    goto L999;
L330:
    iv[1] = 67;
L999:
    return 0;
}

int deflt_(int *alg,int *iv,int *liv,int *lv,double *v)
{

/*  SUPPLY DEFAULT VALUES TO IV AND V	*/
    static int algsav = 51;
    static int ivneed = 3;
    static int lastiv = 44;
    static int lastv = 45;
    static int lmat = 42;
    static int mxfcal = 17;
    static int mxiter = 18;
    static int nfcov = 52;
    static int ngcov = 53;
    static int nvdflt = 50;
    static int outlev = 19;
    static int parprt = 20;
    static int parsav = 49;
    static int perm = 58;
    static int prunit = 21;
    static int solprt = 22;
    static int statpr = 23;
    static int vneed = 4;
    static int x0prt = 24;
    static int miniv[2] = { 80,59 };
    static int minv[2] = { 98,71 };
    static int dtype = 16;
    static int inith = 25;
    static int mv, miv;

    --iv;
    --v;

    miv = miniv[*alg - 1];
    if (*liv < miv) 
	{	
		iv[1] = 15;
		goto L999;
	}
    mv = minv[*alg - 1];
    if (*lv < mv) 
	{
		iv[1] = 16;
		goto L999;
	}
    vdflt_(alg, lv, &v[1]);
    iv[1] = 12;
    iv[algsav] = *alg;
    iv[ivneed] = 0;
    iv[lastiv] = miv;
    iv[lastv] = mv;
    iv[lmat] = mv + 1;
    iv[mxfcal] = 1000000;
    iv[mxiter] = 1000000;
    iv[outlev] = 1;
    iv[parprt] = 1;
    iv[perm] = miv + 1;
    iv[prunit] = 6;
    iv[solprt] = 1;
    iv[statpr] = 1;
    iv[vneed] = 0;
    iv[x0prt] = 1;
    iv[dtype] = 0;
    iv[inith] = 1;
    iv[nfcov] = 0;
    iv[ngcov] = 0;
    iv[nvdflt] = 25;
    iv[parsav] = 47;

L999:
    return 0;
} 

int snoit_(double *d, double *fx, int *iv, int *liv, int *lv, int *n, double *v, double *x)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	static int		c__2 = 2;
	static int		c__1 = 1;
	static int		eta0 = 42;
	static int		toobig = 2;
	static int		vneed = 4;
	static double	zero = 0.;
	static int		f = 10;
	static int		g = 28;
	static int		lmat = 42;
	static int		nextv = 47;
	static int		nfgcal = 7;
	static int		ngcall = 30;
	static int		niter = 31;
	static int		sgirc = 57;
	int				i_1;
	static int		i, j, k, alpha, w;
	static int		g1;
	static int		iv1;	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	--d;
	--iv;
	--v;
	--x;
	/* MINIMIZE GENERAL UNCONSTRAINED OBJECTIVE FUNCTION USING ;
	 * FINITE-DIFFERENCE GRADIENTS AND SECANT HESSIAN APPROXIMATIONS. ;
	 * DIMENSION V(77 + N*(N+17)/2) ;
	 * THIS ROUTINE INTERACTS WITH SUBROUTINE SUMIT IN AN ATTEMPT ;
	 * TO FIND AN N-VECTOR X* THAT MINIMIZES THE (UNCONSTRAINED) ;
	 * OBJECTIVE FUNCTION FX = F(X) COMPUTED BY THE CALLER. (OFTEN ;
	 * THE X* FOUND IS A LOCAL MINIMIZER RATHER THAN A GLOBAL ONE.) ;
	 * THE PARAMETERS FOR SNOIT ARE THE SAME
	 * EXCEPT THAT CALCF, CALCG, 
	 * ARE OMITTED, AND A PARAMETER FX FOR THE OBJECTIVE FUNCTION ;
	 * VALUE AT X IS ADDED. INSTEAD OF CALLING CALCG TO OBTAIN THE ;
	 * GRADIENT OF THE OBJECTIVE FUNCTION AT X, SNOIT CALLS SGRAD2, ;
	 * WHICH COMPUTES AN APPROXIMATION TO THE GRADIENT BY FINITE ;
	 * (FORWARD AND CENTRAL) DIFFERENCES USING THE METHOD OF REF. 1. ;
	 * THE FOLLOWING INPUT COMPONENT IS OF INTEREST IN THIS REGARD ;
	 * V(ETA0)..... V(42) IS AN ESTIMATED BOUND ON THE RELATIVE ERROR IN THE ;
	 * OBJECTIVE FUNCTION VALUE COMPUTED BY CALCF... ;
	 * (TRUE VALUE) = (COMPUTED VALUE) * (1 + E), ;
	 * WHERE ABS(E) .LE. V(ETA0). DEFAULT = MACHEP * 10**3, ;
	 * WHERE MACHEP IS THE UNIT ROUNDOFF. ;
	 * THE OUTPUT VALUES IV(NFCALL) AND IV(NGCALL) HAVE DIFFERENT MEANINGS
	 * IV(NFCALL)... IV(6) IS THE NUMBER OF CALLS SO FAR MADE ON CALCF (I.E., ;
	 * FUNCTION EVALUATIONS) EXCLUDING THOSE MADE ONLY FOR ;
	 * COMPUTING GRADIENTS. THE INPUT VALUE IV(MXFCAL) IS A ;
	 * LIMIT ON IV(NFCALL). ;
	 * IV(NGCALL)... IV(30) IS THE NUMBER OF FUNCTION EVALUATIONS MADE ONLY ;
	 * FOR COMPUTING GRADIENTS. THE TOTAL NUMBER OF FUNCTION ;
	 * EVALUATIONS IS THUS IV(NFCALL) + IV(NGCALL). ;*/
	iv1 = iv[1];
	if (iv1 == 1) goto L10;
	if (iv1 == 2) goto L50;
	if (iv[1] == 0) deflt_(&c__2, &iv[1], liv, lv, &v[1]);
	iv[vneed] = iv[vneed] + (*n << 1) + 6;
	iv1 = iv[1];
	if (iv1 == 14) goto L10;
	if (iv1 > 2 && iv1 < 12)	goto L10;
	g1 = 1;
	if (iv1 == 12) iv[1] = 13;
	goto L20;
L10:
	g1 = iv[g];
L20:
	sumit_(&d[1], fx, &v[g1], &iv[1], liv, lv, n, &v[1], &x[1]);
	if ((i_1 = iv[1] - 2) < 0) goto L999;
	else if (i_1 == 0) goto L30;
	else goto L70;
	/* COMPUTE GRADIENT */
L30:
	if (iv[niter] == 0) vscopy_(n, &v[g1], &zero);
	j = iv[lmat];
	k = g1 -*n;
	i_1 = *n;
	for (i = 1; i <= i_1; ++i)
	{
		v[k] = sdot_(&i, &v[j], &c__1, &v[j], &c__1);
		++k;
		j += i;
	}
	/* UNDO INCREMENT OF IV(NGCALL) DONE BY SUMIT */
	--iv[ngcall];
	/* STORE RETURN CODE FROM SGRAD2 IN IV(SGIRC) */
	iv[sgirc] = 0;
	/* X MAY HAVE BEEN RESTORED, SO COPY BACK FX... */
	*fx = v[f];
	goto L60;
	/* GRADIENT LOOP */
L50:
	if (iv[toobig] == 0)	goto L60;
	iv[nfgcal] = 0;
	goto L10;
L60:
	g1 = iv[g];
	alpha = g1 -*n;
	w = alpha - 6;
	sgrad2_(&v[alpha], &d[1], &v[eta0], fx, &v[g1], &iv[sgirc], n, &v[w], &x[1]);
    /* trace for no derivative option */
//    if (iv[19] < 0)	traceOutput("Gradient", *n, &v[g1]);
    if (iv[sgirc] == 0) goto L10;
	++iv[ngcall];
    goto L999;
L70:
	if (iv[1] != 14)	goto L999;
	/* STORAGE ALLOCATION */
	iv[g] = iv[nextv] +*n + 6;
	iv[nextv] = iv[g] +*n;
	if (iv1 != 13) goto L10;
L999:
	return 0;
}


void chol(double *a, int n, double *p, int *rtn) { 
/* Given a positive-definite symmetric matrix a, this routine constructs its' 
   Choleski decomposition, A=L*t(L). On input, only the upper triangle of a 
   need be given; it is not modified.  the Choleski factor L is returned in the
   lower triangle of a, except for its diagonal elements which are returned in p.
   n gives the dimension of the matrix/length of the vector.
 */
int i, j, k;
double sum;

sum=0.;
for (i=0;i<n;i++) 
{
	for (j=i;j<n;j++) 
	{
		for (sum=a[i*n+j],k=i-1;k>=0;k--) sum-=a[i*n+k]*a[j*n+k];
		if (i==j) {
			if (sum<=0.) 
			{
				*rtn=1; 
				goto L999;
			}	
			else p[i]=sqrt(sum);
		} else a[j*n+i]=sum/p[i];	
	}
}
for (i=0;i<n;i++) a[i*n+i]=p[i];
for (i=0;i<n;i++) for (j=0;j<i;j++) a[j*n+i]=a[i*n+j];
for (i=0;i<n;i++) for (j=0;j<i;j++) a[i*n+j]=0.;
*rtn=0;
L999:;
}

int dgefa_(double *a,int *lda,int *n,int *ipvt,int *info)
{
    int a_dim1, a_offset, i_1, i_2, i_3;
    static int j, k, l;
    static double t;
    static int kp1, nm1;
	extern int idamax_();
    a_dim1 = *lda;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --ipvt;
/* ***PURPOSE  Factor a double precision matrix by Gaussian elimination.*/
/* ***DESCRIPTION */
/*     DGEFA factors a double precision matrix by Gaussian elimination. */
/*     DGEFA is usually called by DGECO, but it can be called */
/*     directly with a saving in time if  RCOND  is not needed. */
/*     (Time for DGECO) = (1 + 9/N)*(Time for DGEFA) . */
/*     On Entry */
/*        A       DOUBLE PRECISION(LDA, N) */
/*                the matrix to be factored. */
/*        LDA     int */
/*                the leading dimension of the array  A . */
/*        N       int */
/*                the order of the matrix  A . */
/*     On Return */
/*        A       an upper triangular matrix and the multipliers */
/*                which were used to obtain it. */
/*                The factorization can be written  A = L*U  where */
/*                L  is a product of permutation and unit lower */
/*                triangular matrices and  U  is upper triangular. */
/*        IPVT    int(N) */
/*                an int vector of pivot indices. */
/*        INFO    int */
/*                = 0  normal value. */
/*                = K  if  U(K,K) .EQ. 0.0 .  This is not an error */
/*                     condition for this subroutine, but it does */
/*                     indicate that DGESL or DGEDI will divide by zero */
/*                     if called.  Use  RCOND  in DGECO for a reliable */
/*                     indication of singularity. */
/*     GAUSSIAN ELIMINATION WITH PARTIAL PIVOTING */
    *info = 0; nm1 = *n - 1; if (nm1 < 1) goto L70; i_1 = nm1;
    for (k = 1; k <= i_1; ++k) {
		kp1 = k + 1;
/*        FIND L = PIVOT INDEX */
		i_2 = *n - k + 1;
		l = idamax_(&i_2, &a[k + k * a_dim1], &c__1) + k - 1;
		ipvt[k] = l;
/*        ZERO PIVOT IMPLIES THIS COLUMN ALREADY TRIANGULARIZED */
		if (a[l + k * a_dim1] == 0.) goto L40;
/*           INTERCHANGE IF NECESSARY */
		if (l == k) goto L10;
		t = a[l + k * a_dim1];
		a[l + k * a_dim1] = a[k + k * a_dim1];
		a[k + k * a_dim1] = t;
L10:
/*           COMPUTE MULTIPLIERS */
		if (fabs(a[k + k * a_dim1]) < DBL_EPSILON) goto L40; /* new line blj */
		t = -1. / a[k + k * a_dim1];
		i_2 = *n - k;
		dscal_(&i_2, &t, &a[k + 1 + k * a_dim1], &c__1);
/*           ROW ELIMINATION WITH COLUMN INDEXING */
		i_2 = *n;
		for (j = kp1; j <= i_2; ++j) {
			t = a[l + j * a_dim1];
			if (l == k) goto L20;
			a[l + j * a_dim1] = a[k + j * a_dim1];
			a[k + j * a_dim1] = t;
L20:
			i_3 = *n - k;
			daxpy_(&i_3, &t, &a[k + 1 + k * a_dim1], &c__1, &a[k + 1 + j * 
		    a_dim1], &c__1);	
		}
		goto L50;
L40:
		*info = k;
L50:
    ;}
L70:
    ipvt[*n] = *n;
    if (a[*n + *n * a_dim1] == 0.) *info = *n;
    return 0;
}

int dscal_(int *n,double *da,double *dx,int *incx)
{
    int i_1, i_2;
    static int i, m, ns, mp1;
    --dx;
/* ***PURPOSE  D.P. vector scale x = a*x */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       DA  double precision scale factor */
/*       DX  double precision vector with N elements */
/*     INCX  storage spacing between elements of DX */
/*     --Output-- */
/*       DX  double precision result (unchanged if N.LE.0) */
/*     Replace double precision DX by double precision DA*DX. */
/*     For I = 0 to N-1, replace DX(1+I*INCX) with  DA * DX(1+I*INCX) */
    if (*n <= 0) {
	return 0;
    }
    if (*incx == 1) {
	goto L20;
    }
/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	dx[i] = *da * dx[i];
    }
    return 0;
/*        CODE FOR INCREMENTS EQUAL TO 1. */
/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 5. */
L20:
    m = *n % 5;
    if (m == 0) {
	goto L40;
    }
    i_2 = m;
    for (i = 1; i <= i_2; ++i) {
	dx[i] = *da * dx[i];
    }
    if (*n < 5) {
	return 0;
    }
L40:
    mp1 = m + 1;
    i_2 = *n;
    for (i = mp1; i <= i_2; i += 5) {
	dx[i] = *da * dx[i];
	dx[i + 1] = *da * dx[i + 1];
	dx[i + 2] = *da * dx[i + 2];
	dx[i + 3] = *da * dx[i + 3];
	dx[i + 4] = *da * dx[i + 4];
    }
    return 0;
}

int idamax_(int *n,double *dx,int *incx)
{
    int ret_val, i_1, i_2;
    double d_1;
    static double dmax_, xmag;
    static int i, ii, ns;
    /* Parameter adjustments */
    --dx;
/* ***PURPOSE  Find largest component of d.p. vector */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       DX  double precision vector with N elements */
/*     INCX  storage spacing between elements of DX */
/*     --Output-- */
/*   IDAMAX  smallest index (zero if N .LE. 0) */
/*     Find smallest index of maximum magnitude of double precision DX. */
/*     IDAMAX =  first I, I = 1 to N, to minimize  ABS(DX(1-INCX+I*INCX) 
*/
    ret_val = 0;
    if (*n <= 0) {
	return ret_val;
    }
    ret_val = 1;
    if (*n <= 1) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L20;
    }
/*        CODE FOR INCREMENTS NOT EQUAL TO 1. */
    dmax_ = fabs(dx[1]);
    ns = *n * *incx;
    ii = 1;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	xmag = (d_1 = dx[i], fabs(d_1));
	if (xmag <= dmax_) {
	    goto L5;
	}
	ret_val = ii;
	dmax_ = xmag;
L5:
	++ii;
    }
    return ret_val;
/*        CODE FOR INCREMENTS EQUAL TO 1. */
L20:
    dmax_ = fabs(dx[1]);
    i_2 = *n;
    for (i = 2; i <= i_2; ++i) {
	xmag = (d_1 = dx[i], fabs(d_1));
	if (xmag <= dmax_) {
	    goto L30;
	}
	ret_val = i;
	dmax_ = xmag;
L30:
    ;}
    return ret_val;
} 

int daxpy_(int *n,double *da,double *dx,int *incx,double *dy,int *incy)
{
    int i_1, i_2;
    static int i, m, ix, iy, ns, mp1;
    --dx;
    --dy;
/* ***PURPOSE  D.P computation y = a*x + y */
/*     --Input-- */
/*        N  number of elements in input vector(s) */
/*       DA  double precision scalar multiplier */
/*       DX  double precision vector with N elements */
/*     INCX  storage spacing between elements of DX */
/*       DY  double precision vector with N elements */
/*     INCY  storage spacing between elements of DY */
/*     --Output-- */
/*       DY  double precision result (unchanged if N .LE. 0) */
/*     Overwrite double precision DY with double precision DA*DX + DY. */
/*     For I = 0 to N-1, replace  DY(LY+I*INCY) with DA*DX(LX+I*INCX) + */
/*       DY(LY+I*INCY), where LX = 1 if INCX .GE. 0, else LX = (-INCX)*N */
/*       and LY is defined in a similar way using INCY. */
    if (*n <= 0 || *da == 0.) {
	return 0;
    }
    if (*incx == *incy) {
	if ((i_1 = *incx - 1) < 0) {
	    goto L5;
	} else if (i_1 == 0) {
	    goto L20;
	} else {
	    goto L60;
	}
    }
L5:
/*        CODE FOR NONEQUAL OR NONPOSITIVE INCREMENTS. */
    ix = 1;
    iy = 1;
    if (*incx < 0) {
	ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
	iy = (-(*n) + 1) * *incy + 1;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i) {
	dy[iy] += *da * dx[ix];
	ix += *incx;
	iy += *incy;
    }
    return 0;
/*        CODE FOR BOTH INCREMENTS EQUAL TO 1 */
/*        CLEAN-UP LOOP SO REMAINING VECTOR LENGTH IS A MULTIPLE OF 4. */
L20:
    m = *n % 4;
    if (m == 0) {
	goto L40;
    }
    i_1 = m;
    for (i = 1; i <= i_1; ++i) {
	dy[i] += *da * dx[i];
    }
    if (*n < 4) {
	return 0;
    }
L40:
    mp1 = m + 1;
    i_1 = *n;
    for (i = mp1; i <= i_1; i += 4) {
	dy[i] += *da * dx[i];
	dy[i + 1] += *da * dx[i + 1];
	dy[i + 2] += *da * dx[i + 2];
	dy[i + 3] += *da * dx[i + 3];
    }
    return 0;
/*        CODE FOR EQUAL, POSITIVE, NONUNIT INCREMENTS. */
L60:
    ns = *n * *incx;
    i_1 = ns;
    i_2 = *incx;
    for (i = 1; i_2 < 0 ? i >= i_1 : i <= i_1; i += i_2) {
	dy[i] = *da * dx[i] + dy[i];
    }
    return 0;
}

double invlogit(double x)
{	
    if (x < -700.) return 0.;

	if (x > 700.) return 1.;
	
	return 1 / (1 + exp(-x));
}
