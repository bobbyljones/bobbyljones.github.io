/* 	
	Stata output processing for trajectory models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.	
*/

#include	 "ctraj.h"

void writeParmLine(int pGrp, int iflt, int df, double est, double prmSE, char* lbl) {

	char	hdr[90], w1_str[13], w2_str[13], w3_str[13], w4_str[13];	
	double	pValue, TScore, tProb;

	TScore = pValue = MACMISSING;
	*hdr = '\0';
	*w1_str = '\0';
	*w2_str = '\0';
	*w3_str = '\0';
	*w4_str = '\0';
	if (iflt == 0 && prmSE > MACEPS) 
	{
		TScore= est * pow(prmSE, -1.);
		tprob(fabs(TScore), df, &tProb);
		pValue = 2. * (1. - tProb); 
	}
	if (!IS_MISSING(est) && iflt == 0) 
	{
		if (fabs(est) >= 1e9) 
			snprintf(w4_str, 13, "%12.3e", est);
		else
			snprintf(w4_str, 13, "%12.5f", est);
	}
	if (!IS_MISSING(prmSE) && iflt == 0) 
	{
		if (fabs(prmSE) >= 1e7) 
			snprintf(w3_str, 13, "%12.3e", prmSE);
		else 
			snprintf(w3_str, 13, "%12.5f", prmSE);
	}
	if (!IS_MISSING(TScore) && iflt == 0) 
	{
		if (fabs(TScore) >= 1e11)
			snprintf(w1_str, 13, "%12.3e", TScore);
		else 
			snprintf(w1_str, 13, "%12.3f", TScore);
	}
	if (!IS_MISSING(pValue) && iflt == 0) sprintf(w2_str, "%8.4f", pValue);
	
	if (pGrp) 
	{
		sprintf(hdr, " %d       %-12s %s %-12s    %s     %s\n", pGrp, lbl, w4_str, w3_str, w1_str, w2_str);
	}
	else 
	{
		sprintf(hdr, "         %-12s %s %-12s    %s     %s\n", lbl, w4_str, w3_str, w1_str, w2_str);
	}
	SF_display(hdr);
}
