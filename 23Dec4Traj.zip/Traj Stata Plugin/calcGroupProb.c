/* 
	calculate group probabilities	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

void calcGroupProb(int obs, int os, double **risk, double *prm, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		j, ofs, r;
	double	d1;

	d1 = 1.;
	ofs = os;
	if (ts->multModel) 
	{
		ts->multGroupProb[(int)ts->referenceGroup[0]] = 0.;
		for (j = 0; j < ts->nMultGroups; j++) 
		{
			if (j != (int)ts->referenceGroup[0])
			{
				ts->multGroupProb[j] = prm[ofs++];
				for (r = 0; r < ts->nMultRisk; r++)
					ts->multGroupProb[j] += prm[ofs++] * risk[obs][r];
				ts->multGroupProb[j] = ts->multGroupProb[j] > MAXEXP ? 	MAXEXP : ts->multGroupProb[j];
				ts->multGroupProb[j] = ts->multGroupProb[j] < -MAXEXP ?	-MAXEXP : ts->multGroupProb[j];
				d1 += exp(ts->multGroupProb[j]);
			}
		}
		for (j = 0; j < ts->nMultGroups; j++)
			ts->multGroupProb[j] = exp(ts->multGroupProb[j]) / d1;
	} 
	else 
	{
		ts->groupProb[ts->mdl][(int)ts->referenceGroup[ts->mdl]] = 0.;
		for (j = 0; j < ts->nOrders[ts->mdl]; j++) 
		{
			if (j != (int)ts->referenceGroup[ts->mdl]) 
			{
				ts->groupProb[ts->mdl][j] = prm[ofs++];
				if (ts->mdl == 0 && ts->nRisk[0] > 0)
				{
					for (r = 0; r < ts->nRisk[0]; r++)
						ts->groupProb[0][j] += prm[ofs++] * risk[obs][r];
				}
				
				if (ts->mdl == 1 && ts->nRisk[1] > 0)
				{
					for (r = 0; r < ts->nRisk[1]; r++)
						ts->groupProb[1][j] += 
							prm[ts->riskOffset[1] + ts->nOrders[0] *
							(ts->nOrders[1] - 1) + r + (j - 1) * ts->nRisk[1]] * risk[obs][r];
				}
				ts->groupProb[ts->mdl][j] =	ts->groupProb[ts->mdl][j] > MAXEXP ? MAXEXP : ts->groupProb[ts->mdl][j];
				ts->groupProb[ts->mdl][j] = ts->groupProb[ts->mdl][j] < -MAXEXP ? -MAXEXP : ts->groupProb[ts->mdl][j];
				d1 += exp(ts->groupProb[ts->mdl][j]);
			}
		}
		for (j = 0; j < ts->nOrders[ts->mdl]; j++)
			ts->groupProb[ts->mdl][j] = exp(ts->groupProb[ts->mdl][j]) / d1;
	}
	return;
}
