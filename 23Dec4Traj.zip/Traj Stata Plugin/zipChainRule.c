/* 	
	chain rule zip model	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include	 "ctraj.h"

void zipChainRule(int n, int* mdl, int* obs, int* gp, int* wv, double* prm, int* os, double *w, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int  	ifault=0, j, ofs, zos;
	double	calcsv, lmb, rho, *tcovPtr, tmp, xb, zo;

	for (j = 0; j < n; j++) w[j] = 0.;
	if ((int)ts->order[*mdl][*gp] == -1 && *gp == 0) return; /* ts->all0Group */
	ofs = *os;
	zos = ts->zipParmOffset[*mdl];
	if (ts->likelihoodType == JOINT)
	{
		ofs = *mdl == 1 ? ts->jointOffset : 0;
		for (j = 0; j < *gp; j++)
		{
			ofs += (int)ts->order[*mdl][j] + 1 +
				((int)ts->order[*mdl][j] + 1 > 0) * ts->nTcovParms[*mdl];
		}
		zos = ts->zipParmOffset[1];
	}
	if (ts->iorderStmt[*mdl]) 
	{
		zo = (int)ts->iorder[*mdl][0];
		if (!ts->commonIorder[*mdl]) 
		{
			zo = (int)ts->iorder[*mdl][*gp];
			for (j = 0; j < *gp; j++) zos += (int)ts->iorder[*mdl][j] + 1;
		}
	}
	rho = 0.;
	calcsv = 1.;
	if (ts->iorderStmt[*mdl] && zo != -1) 
	{
		xb = prm[zos];
		for (j = 1; j <= zo; j++) 
			xb += prm[zos + j] * pow(ts->indep[*mdl][*obs][*wv], j);
		tmp = exp(xb);		
		calcsv = 1. + tmp;
		rho = zo == -1 ? 0. : tmp * pow(calcsv, -1.);
	}
	tcovPtr = 0;
	if (ts->nTcov[*mdl] > 0) tcovPtr = ts->tcov[*mdl][*obs];
	xb = linPred(prm, &ts->indep[*mdl][*obs][*wv], &ofs, wv, &ts->nIndep[*mdl], &ts->order[*mdl][*gp],
				 &ts->nTcovParms[*mdl], tcovPtr);
	lmb = exp(xb);
	if (ts->nExpos[*mdl] > 0) lmb *= ts->exposure[*mdl][*obs][*wv];
	for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++) 
		w[ofs + j] = -(1. - rho) * exp(-lmb) * lmb * pow(ts->indep[*mdl][*obs][*wv], j);
	if (ts->iorderStmt[*mdl] && zo != -1) 
	{
		for (j = 0; j <= zo; j++) 
			w[zos + j] = (1. - exp(-lmb)) * rho * pow(calcsv, -1.) * pow(ts->indep[*mdl][*obs][*wv], j);
	}
	if (ts->nTcov[*mdl] > 0) 
	{
		for (j = 0; j < ts->nTcovParms[*mdl]; j++) 
		{
			w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = -(1. - rho) * exp(-lmb) * lmb *
				ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]];
		}
	}
	if (ts->dep[*mdl][*obs][*wv] > 0.) 
	{
		for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++) 
		{
			w[ofs + j] = ts->varTrajLk[*mdl][*gp][*obs][*wv] *
				       (ts->dep[*mdl][*obs][*wv] - lmb) *
				        pow(ts->indep[*mdl][*obs][*wv], j);
		}
		if (ts->iorderStmt[*mdl]) 
		{
			tmp = -lmb + ts->dep[*mdl][*obs][*wv] * log(lmb) -
			  	   alogam(ts->dep[*mdl][*obs][*wv] + 1., &ifault);
			for (j = 0; j <= zo; j++) 
				w[zos + j] = -exp(tmp) * rho * pow(calcsv, -1.) * pow(ts->indep[*mdl][*obs][*wv], j);
		}
		if (ts->nTcov[*mdl] > 0)
			for (j = 0; j < ts->nTcovParms[*mdl]; j++)
				w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = ts->varTrajLk[*mdl][*gp][*obs][*wv] * 
					(ts->dep[*mdl][*obs][*wv] - lmb) * ts->tcov[*mdl][*obs][*wv + j * 
					ts->nIndep[*mdl]];
	}
	return;
}
