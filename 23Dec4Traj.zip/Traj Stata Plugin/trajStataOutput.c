/* 
	Stata output processing for trajectory models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.
*/
#include	 "ctraj.h"

int trajStataOutput(void *qinfo)
{
	struct	TRAJSTRUCT *ts = qinfo;
	char	hdr[100], l_str[33], parmLabel[13];
	int		i, j, prmPtr, r;
	double	d1, d2;

	sprintf(hdr, "\t\t\tMaximum Likelihood Estimates\n");  
	SF_display(hdr);
	if (ts->likelihoodType != JOINT && !ts->noprint)
	{
		switch (ts->modelType[0])
		{
		case m_cnorm:
			if (ts->rorderStmt[0])
				sprintf(hdr, "\t\tModel: Censored Normal (cnorm) Mixed Effects\n");
			else 
				sprintf(hdr, "\t\t\tModel: Censored Normal (cnorm)\n");				
			break;
		case m_logit:		
			sprintf(hdr,  "\t\t\tModel: Logistic (logit)\n");
			break;
		case m_zibeta:			
			sprintf(hdr,  "\t\t\tModel: Beta (beta)\n");
			break;
		case m_zip:
			sprintf(hdr, "\t\t\tModel: Zero Inflated Poisson (zip)\n");
			break;
		}
		SF_display(hdr);
	}
	if (ts->likelihoodType == JOINT && !ts->noprint)
	{
		sprintf(hdr, " \n");
		SF_display(hdr);
		switch (ts->modelType[0])
		{
		case m_cnorm:
			sprintf(hdr, "Model 1: Censored Normal (cnorm)\n");
			break;
		case m_logit:		
			sprintf(hdr, "Model 1: Logistic (logit)\n");
			break;
		case m_zip:
			sprintf(hdr, "Model 1: Zero Inflated Poisson (zip)\n");
			break;
		}
		SF_display(hdr);
	}
	if (ts->no_var)
	{
		sprintf(hdr, "Standard error calculations omitted by NOVAR option.\n");	
		SF_display(hdr);
	}
	else if (ts->iflt != 0)
	{
		sprintf(hdr, "Unable to calculate standard errors.  Check model.\n");
		SF_display(hdr);
	}
	sprintf(hdr, "\n\t\t\t       Standard       T for H0:\n");  
	SF_display(hdr);
	sprintf(hdr, " Group   Parameter        Estimate        Error     Parameter=0   Prob > |T|\n");
	SF_display(hdr);
	sprintf(hdr, " \n"); 
	SF_display(hdr);
	prmPtr = 0;
	for (i = 0; i < ts->nOrders[0]; i++)
	{	
		if (ts->order[0][i] == -1) sprintf(hdr, "\n %-d %s %s %s %s %s", i + 1, "N/A", ".", ".", ".", ".");
		for (j = 0; j <= ts->order[0][i]; j++)
		{
			switch (j)
			{
				case 0:
					writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Intercept   ");
					sprintf(l_str, "interc%-d", i + 1);
					break;			
				case 1:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Linear      ");
					sprintf(l_str, "linear%-d", i + 1);
					break;
				case 2:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Quadratic   ");
					sprintf(l_str, "quadra%-d", i + 1);
					break;
				case 3:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Cubic       ");

					sprintf(l_str, "cubic%-d", i + 1);
					break;
				case 4:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Quartic     ");
					sprintf(l_str, "quarti%-d", i + 1);
					break;
				case 5:
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Quintic     ");
					sprintf(l_str, "quinti%-d", i + 1);
					break;
			}
			strcat(ts->outestVarName, l_str) ;	
			strcat(ts->outestVarName, " ") ;	
			prmPtr++;
		}
		for (j = 0; j < ((int)ts->order[0][i] + 1 > 0) * ts->nTcovParms[0]; j++)
		{
			writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
				ts->stdErr[prmPtr], ts->tcovNames[0][j * ts->nIndep[0]]);
			sprintf(l_str, "%sG%-d", ts->tcovNames[0][j * ts->nIndep[0]], i + 1);
			strcat(ts->outestVarName, l_str) ;	
			strcat(ts->outestVarName, " ") ;	
			prmPtr++;
		}
		sprintf(hdr, " \n");  
		SF_display(hdr);
	}
	if (ts->dropoutStmt[0])
	{
		for (i = 0; i < ts->nDropout[0]; i++)
		{
			if (ts->nDropout[0] == 1)
			{
				writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
					ts->stdErr[prmPtr], "Drop0       ");
				sprintf(l_str, "drop0");
				prmPtr++;
				strcat(ts->outestVarName, l_str);
				strcat(ts->outestVarName, " ");	
			} 
			else 
			{
				if (ts->dOrd[0][i] != -1.)
				{
					writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Drop0       ");
					sprintf(l_str, "drop0G%-d", i + 1);
					prmPtr++;
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");	
				}
			}
			for (j = 1; j <= (int)ts->dOrd[0][i]; j++)
			{
				sprintf(parmLabel, "Drop%-d       ", j);
				writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr], ts->stdErr[prmPtr], parmLabel);
				sprintf(l_str, "drop%-dG%-d", j, i + 1);
				prmPtr++;
				strcat(ts->outestVarName, l_str);	
				strcat(ts->outestVarName, " ");	
			}
			for (r = 0; r < ts->nDcovPrm[0]; r++)
			{
				writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
					ts->stdErr[prmPtr], ts->dcovNames[0][r * ts->nIndep[0]]);
				sprintf(l_str, "%sG%-d_dcov", ts->dcovNames[0][r * ts->nIndep[0]], i + 1);
				strcat(ts->outestVarName, l_str);	
				strcat(ts->outestVarName, " ");	
				prmPtr++;
			}
			sprintf(hdr, " \n"); SF_display(hdr);
		}
	}
	if (ts->iorderStmt[0]) 
	{
		for (i = 0; i < MAX(1, ts->nIorder[0]); i++)
		{				
			if (ts->commonIorder[0])
			{
				if (ts->iorder[0][i]  != -1.)
				{
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr], 
						ts->stdErr[prmPtr], "Alpha0      ");
					sprintf(l_str, "alpha0");
					prmPtr++;
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
				}
			}
			else
			{
				if (ts->iorder[0][i] != -1.)
				{
					writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], "Alpha0      ");
					sprintf(l_str, "alpha0G%-d", i + 1);
					prmPtr++;
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
				}
			}

			for (j = 1; j <= (int)ts->iorder[0][i]; j++)
			{
				sprintf(parmLabel, "Alpha%-d      ", j);
				writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
					ts->stdErr[prmPtr], parmLabel);
				sprintf(l_str, "alpha%-d", i + 1);
				if (!ts->commonIorder[0]) sprintf(l_str, "alpha%-dG%-d", j, i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				prmPtr++;
			}
			if (ts->iorder[0][i] != -1.)
			{
				sprintf(hdr, " \n");
				SF_display(hdr);
			}
		}
	}
	if (ts->modelType[0] == m_zibeta)
	{
		for (i = 0; i < ts->nOrders[0]; i++)
		{
			writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[prmPtr]), 
						ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), "Phi         ");
			for (r = 0; r < ts->totalParms; r++)
			{
				ts->hessian[r * ts->totalParms + prmPtr] *= exp(ts->start[prmPtr]);
				ts->hessian[prmPtr * ts->totalParms + r] *= exp(ts->start[prmPtr]);
			}
			sprintf(l_str, "phi%-d", i + 1);
			strcat(ts->outestVarName, l_str) ;	
			strcat(ts->outestVarName, " ") ;	
			prmPtr++; 
		}
	}
	if (ts->modelType[0] == m_cnorm)
	{
		if (ts->sigmaByGroup)
		{
			for (i = 0; i < ts->nOrders[0]; i++)
			{
				if (!((int)ts->order[0][i] == -1 && i == 0)) /* ts->all0Group */
				{
					writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[prmPtr]), 
						ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), "Sigma       ");
					for (r = 0; r < ts->totalParms; r++)
					{
						ts->hessian[r * ts->totalParms + prmPtr] *= exp(ts->start[prmPtr]);
						ts->hessian[prmPtr * ts->totalParms + r] *= exp(ts->start[prmPtr]);
					}
					sprintf(l_str, "sigma%-d", i + 1);
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
					prmPtr++; 
				}
			}
		} 
		else 
		{
			writeParmLine(0, ts->iflt, ts->nData, exp(ts->start[prmPtr]), 
				ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), "Sigma       ");
			for (r = 0; r < ts->totalParms; r++)
			{
				ts->hessian[r * ts->totalParms + prmPtr] *= exp(ts->start[prmPtr]);
				ts->hessian[prmPtr * ts->totalParms + r] *= exp(ts->start[prmPtr]);
			}
			sprintf(l_str, "sigma");
			strcat(ts->outestVarName, l_str) ;	
			strcat(ts->outestVarName, " ") ;
			prmPtr++;
		}
		if (ts->ar1)
		{
			if (ts->rhoByGroup)
			{
				for (i = 0; i < ts->nOrders[0]; i++)
				{
					d1 = invlogit(ts->start[prmPtr]);
					d2 = ts->stdErr[prmPtr] * d1 * pow(ts->start[prmPtr], -.5);
					writeParmLine(i + 1, ts->iflt, ts->nData, d1, d2, "Rho         ");
					d2 = d1 * pow(ts->start[prmPtr], -.5);
					for (r = 0; r < ts->totalParms; r++)
					{
						ts->hessian[r * ts->totalParms + prmPtr] *= d2;
						ts->hessian[prmPtr * ts->totalParms + r] *= d2;
					}
					sprintf(l_str, "rho%-d", i + 1);
					strcat(ts->outestVarName, l_str);
					strcat(ts->outestVarName, " ");
					prmPtr++;
				}
			} 
			else 
			{
				d1 = invlogit(ts->start[prmPtr]);
				d2 = ts->stdErr[prmPtr] * d1 * pow(ts->start[prmPtr], -.5);
				writeParmLine(0, ts->iflt, ts->nData, d1, d2, "Rho         ");
				d2 = d1 * pow(ts->start[prmPtr], -.5);
				for (r = 0; r < ts->totalParms; r++)
				{
					ts->hessian[r * ts->totalParms + prmPtr] *= d2;
					ts->hessian[prmPtr * ts->totalParms + r] *= d2;
				}
				sprintf(l_str, "rho");
				strcat(ts->outestVarName, l_str);
				strcat(ts->outestVarName, " ");
				prmPtr++;
			}
		}
	}
	if (ts->rorderStmt[0])
	{
		sprintf(hdr, " \n");  
		SF_display(hdr);
		for (i = 0; i < MAX(1, ts->nRorder[0]); i++)
		{
			if (ts->commonRorder[0])
			{
				if (ts->rorder[0][i] != -1.)
				{
					writeParmLine(0, ts->iflt, ts->nData, exp(ts->start[prmPtr]), 
						ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), "r0Sigma     ");
					sprintf(l_str, "r0Sigma");
					strcat(ts->outestVarName, l_str) ;						
					strcat(ts->outestVarName, " ") ;	
				}
			}
			else
			{
				if (ts->rorder[0][i] != -1.)
				{
					writeParmLine(i + 1, ts->iflt, ts->nData, exp(ts->start[prmPtr]), 
						ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), "r0Sigma     ");
					sprintf(l_str, "r0SigmaG%-d", i + 1);
					strcat(ts->outestVarName, l_str) ;						
					strcat(ts->outestVarName, " ") ;	
				}
			}
			for (r = 0; r < ts->totalParms; r++)
			{
				ts->hessian[r * ts->totalParms + prmPtr] *= exp(ts->start[prmPtr]);
				ts->hessian[prmPtr * ts->totalParms + r] *= exp(ts->start[prmPtr]);
			}
			prmPtr++; 
			for (j = 1; j <= (int)ts->rorder[0][i]; j++)
			{
				sprintf(parmLabel, "r%-dSigma     ", j);
				writeParmLine(0, ts->iflt, ts->nData, exp(ts->start[prmPtr]),
					ts->stdErr[prmPtr] * exp(ts->start[prmPtr]), parmLabel);
				sprintf(l_str, "r%-dSigma", j);
				if (!ts->commonRorder[0]) sprintf(l_str, "r%-dSigmaG%-d", j, i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				for (r = 0; r < ts->totalParms; r++)
				{
					ts->hessian[r * ts->totalParms + prmPtr] *= exp(ts->start[prmPtr]);
					ts->hessian[prmPtr * ts->totalParms + r] *= exp(ts->start[prmPtr]);
				}
				prmPtr++;
			}
			sprintf(hdr, " \n");  
			SF_display(hdr);
		}
	}
	for (i = 0; i < ts->nOrders[0]; i++) ts->group_percent[i] = MACMISSING;
	sprintf(hdr, " \n");  
	SF_display(hdr);	
	SF_display("  Group membership \n");  
	if (ts->nRisk[0] != 0)
	{
		for (i = 0; i < ts->nOrders[0]; i++)
		{
			if (i == (int)ts->referenceGroup[0]) 
			{
				if (!ts->noprint)
				{			
					sprintf(hdr, " \n");  
					SF_display(hdr);	
					sprintf(hdr, " %-d       Baseline         (0.00000)           .               .            . \n", 
						(int)ts->referenceGroup[0] + 1); 
					SF_display(hdr);				
				}
			}
			else
			{
				sprintf(hdr, " \n");  
				SF_display(hdr);	
				writeParmLine(i + 1, ts->iflt, ts->nData, ts->start[prmPtr],
					ts->stdErr[prmPtr], "Constant    ");
				sprintf(l_str, "const%-d", i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				prmPtr++;
				for (r = 0; r < ts->nRisk[0]; r++)
				{
					writeParmLine(0, ts->iflt, ts->nData, ts->start[prmPtr],
						ts->stdErr[prmPtr], ts->riskNames[0][r]);
					sprintf(l_str, "%sG%-d", ts->riskNames[0][r], i + 1);
					strcat(ts->outestVarName, l_str) ;	
					strcat(ts->outestVarName, " ") ;	
					prmPtr++;
				}
			}
		} 
	}
	else		/* No Risk Factors		*/
	{
		d1 = 1.;
		for (i = 0; i < ts->nOrders[0] - 1; i++)
		{
			ts->start[prmPtr + i] = ts->start[prmPtr + i] > MAXEXP ? MAXEXP : ts->start[prmPtr + i];
			ts->start[prmPtr + i] = ts->start[prmPtr + i] < -MAXEXP ? -MAXEXP : ts->start[prmPtr + i];
			d1 += exp(ts->start[prmPtr + i]);
		}
		if (ts->iflt == 0) 
			mlogitDeltaMethod(prmPtr, ts->nOrders[0], ts); 
		for (i = 0; i < ts->nOrders[0]; i++)
		{
			ts->hpi[i * ts->nOrders[0] + i] = fabs(ts->hpi[i * ts->nOrders[0] + i]);
			ts->prdw[i] = 100. * sqrt(ts->hpi[i * ts->nOrders[0] + i]);
			if (i == 0) ts->group_percent[0] = 100. / d1;
			else
			{
				ts->start[prmPtr] = ts->start[prmPtr] > MAXEXP ? MAXEXP : ts->start[prmPtr];
				ts->start[prmPtr] = ts->start[prmPtr] < -MAXEXP ? -MAXEXP : ts->start[prmPtr];
				ts->group_percent[i] = exp(ts->start[prmPtr]) / d1 * 100.;
			}
			writeParmLine(i + 1, ts->iflt, ts->nData, ts->group_percent[i], ts->prdw[i], "(%)         ");				
			if (i > 0)
			{
				sprintf(l_str, "theta%-d", i + 1);
				strcat(ts->outestVarName, l_str) ;	
				strcat(ts->outestVarName, " ") ;	
				prmPtr++;
			}
		}
	}
	sprintf(hdr, " \n");
	SF_display(hdr);
	sharedStataOutput(prmPtr, ts);
	return 0;
}

