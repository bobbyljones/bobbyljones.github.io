#define MAINPROC 1
/* 
	main processing for trajectory models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	

*/
   
#include "ctraj.h"   

STDLL stata_call(int argc, char *argv[])
{
	struct	TRAJSTRUCT ts;
	char	buf[110];
	int		alpha, argCount, *B_outcBoundtype, csaveV=0, *csave=&csaveV, g1, i, isave[88],
			iseed = 32423, itmp, j, jj, liv, loopc, lsave[8], lv, mcorr,
			nmax, numStart, os, printLvl, r, r2, saveTP, taskV=0, *task=&taskV, w;
	double	*B_outcLower, *B_outcUpper, det2[2], dsave[58], ep, ep1, factr, fx, *g_save1,
			*g_save2, pgtol, *scale, *x_save;

	unsigned int *parmLoc[] = {	
		&ts.modelType[0],
		&ts.nIndep[0], 
		&ts.nRisk[0], 
		&ts.nWeight,
		&ts.nExpos[0],
		&ts.nTcov[0],   
		&ts.nOrders[0],  
		&ts.nIorder[0],   
		&ts.nRorder[0], 
		&ts.nDropout[0],   
		&ts.nDcov[0],  
		&ts.nObsmar,   
		&ts.outcModelType[0],
		&ts.nOcov[0],
		&ts.nOOS,
		&ts.modelType[1], &ts.nIndep[1], &ts.nRisk[1], &ts.nExpos[1], &ts.nTcov[1],
		&ts.nOrders[1], &ts.nIorder[1], &ts.nDropout[1], &ts.nDcov[1],
		&ts.modelType[2], &ts.nIndep[2], &ts.nOrders[2], &ts.nIorder[2], &ts.nExpos[2], &ts.nTcov[2],
		&ts.modelType[3], &ts.nIndep[3], &ts.nOrders[3], &ts.nIorder[3], &ts.nExpos[3], &ts.nTcov[3],
		&ts.modelType[4], &ts.nIndep[4], &ts.nOrders[4], &ts.nIorder[4], &ts.nExpos[4], &ts.nTcov[4],
		&ts.modelType[5], &ts.nIndep[5], &ts.nOrders[5], &ts.nIorder[5], &ts.nExpos[5], &ts.nTcov[5],
		&ts.nMultRisk,
	};
	int *stmtLoc[] = {	
		&ts.modelStmt[0], 
		&ts.indepStmt[0], 
		&ts.riskStmt[0], 
		&ts.weightStmt, 
		&ts.exposStmt[0], 
		&ts.tcovStmt[0], 
		&ts.orderStmt[0], 
		&ts.iorderStmt[0],
		&ts.rorderStmt[0],
		&ts.dropoutStmt[0], 
		&ts.dcovStmt[0], 
		&ts.obsmarStmt, 
		&ts.outcStmt[0],
		&ts.ocovStmt[0],
		&ts.oosStmt,
		&ts.modelStmt[1], &ts.indepStmt[1], &ts.riskStmt[1], &ts.exposStmt[1],
		&ts.tcovStmt[1], &ts.orderStmt[1], &ts.iorderStmt[1], &ts.dropoutStmt[1], &ts.dcovStmt[1],
		&ts.modelStmt[2], &ts.indepStmt[2], &ts.orderStmt[2], &ts.iorderStmt[2],&ts.exposStmt[2], &ts.tcovStmt[2],
		&ts.modelStmt[3], &ts.indepStmt[3], &ts.orderStmt[3], &ts.iorderStmt[3], &ts.exposStmt[3], &ts.tcovStmt[3],
		&ts.modelStmt[4], &ts.indepStmt[4], &ts.orderStmt[4], &ts.iorderStmt[4], &ts.exposStmt[4], &ts.tcovStmt[4],
		&ts.modelStmt[5], &ts.indepStmt[5], &ts.orderStmt[5], &ts.iorderStmt[5], &ts.exposStmt[5], &ts.tcovStmt[5],
		&ts.multRiskStmt,
	};

	memset(&ts, 0, sizeof(ts));
	memset(dsave, 0, sizeof(dsave));
	argCount = 0;
	while(argCount < argc)
	{
		*stmtLoc[argCount] = 0;
		i=sscanf(argv[argCount], "%d", parmLoc[argCount]);
		if ((int)*parmLoc[argCount] > 0) *stmtLoc[argCount] = 1;
		argCount++;
	}
	trajInitStata(&ts);
	parmPositions(&ts);
	numStart = ts.totalParms;
	liv = 100 + ts.totalParms;
	lv = 77 + ts.totalParms * (ts.totalParms + 19);						
	ts.iv = (int *) calloc(liv, sizeof(int));
	ts.v = (double *) calloc(lv, sizeof(double));
	if (ts.nOrders[0] > 1 && ts.nRisk[0] == 0 && ts.nMultRisk == 0) numStart = ts.totalParms + 1;
	if (!ts.multModel && ts.nOrders[1] > 0 && ts.nRisk[1] == 0) numStart += ts.nOrders[0];
	if (ts.startStmt && ts.numStartVal != numStart)
		WRITEERR("Incorrect number of start values, the correct number is %d.\n", numStart);
	if (ts.lowerStmt && ts.numLowerVal != ts.totalParms)
		WRITEERR("Incorrect number of lower values, the correct number is %d.\n", ts.totalParms);
	if (ts.upperStmt && ts.numUpperVal != ts.totalParms)
		WRITEERR("Incorrect number of upper values, the correct number is %d.\n", ts.totalParms);
	if (ts.ar1 && ts.all0Group[0]) WRITEERR("-1 ORDER is not valid with AR1 option.\n");
	if (ts.ar1 && ts.nIndep[0] < 2) WRITEERR("Need more than one time point with AR1 option.\n");
	ts.B_boundtype = (int *) calloc(ts.totalParms, sizeof(int));
	ts.B_lower = (double *) calloc(ts.totalParms, sizeof(double));
	ts.B_upper = (double *) calloc(ts.totalParms, sizeof(double));
	if (ts.lowerStmt) 
	{
		for (i = 0; i < ts.numLowerVal; i++) SF_mat_el("traj_lower", 1, i + 1, &ts.B_lower[i]);
	}
	else
	{
		for (i = 0; i < ts.totalParms; i++) ts.B_lower[i] = SV_missval;
	}
	if (ts.upperStmt) 
	{
		for (i = 0; i < ts.numUpperVal; i++) SF_mat_el("traj_upper", 1, i + 1, &ts.B_upper[i]);
	}
	else
	{
		for (i = 0; i < ts.totalParms; i++) ts.B_upper[i] = SV_missval;
	}
	for (i = 0; i < ts.numLowerVal; i++)
	{
		if (IS_MISSING(ts.B_lower[i])) ts.B_boundtype[i] = IS_MISSING(ts.B_upper[i]) ? 0 : 3;
		else ts.B_boundtype[i] = IS_MISSING(ts.B_upper[i]) ? 1 : 2;
	}
	/* l-bfgs-b outcome initialization	*/
	itmp = 10 * ts.totalParms;
	ts.outc_iwa = (int*)calloc(itmp, sizeof(int));
	mcorr = 20; 	
	itmp = (2 * mcorr + 5) * ts.totalParms + 11 * mcorr * mcorr + 8 * mcorr;
	ts.outc_wa = (double*)calloc(itmp, sizeof(double));
	itmp = ts.nOutcPrm[0] + 1;
	ts.outcStart = (double*)calloc(itmp, sizeof(double));
	ts.outcStdErr = (double*)calloc(itmp, sizeof(double));
	itmp = (ts.nOutcPrm[0] + 1) * (ts.nOutcPrm[0] + 1);
	ts.outc_hessian = (double*)calloc(itmp, sizeof(double));
	ts.liv_outc = 500;
	ts.iv_outc = (int *) calloc(ts.liv_outc, sizeof(int));
	ts.lv_outc = 77 + ts.totalParms * (ts.totalParms + 17);						
	ts.v_outc = (double *) calloc(ts.lv_outc, sizeof(double));
	/* *******************************	 */
	itmp = 2 * (numStart + 1);
	ts.iwork = (int*)calloc(itmp, sizeof(int));
	ts.start = (double *) calloc(numStart, sizeof(double));
	itmp = 2 * numStart;
	ts.initVal = (double*)calloc(itmp, sizeof(double));
	ts.workrslt = (double*)calloc(itmp, sizeof(double));
	if (ts.startStmt) 
		for (i = 0; i < ts.numStartVal; i++) SF_mat_el("traj_start", 1, i + 1, &ts.start[i]); 
	ts.worknp = (double *) calloc(ts.totalParms, sizeof(double));
	ts.score = (double*)calloc(ts.totalParms, sizeof(double));
	scale = (double*)calloc(ts.totalParms, sizeof(double));
	itmp = ts.totalParms * ts.totalParms;
	ts.xprod = (double*)calloc(itmp, sizeof(double));
	itmp = 33 * ts.totalParms;
	ts.outestVarName = (char*)calloc(itmp, sizeof(char));
	*ts.outestVarName = '\0';
	itmp = (ts.totalParms + 1) * (ts.totalParms + 1);
	ts.hessian = (double*)calloc(itmp, sizeof(double));
	ts.saveHessian = (double*)calloc(itmp, sizeof(double));
	ts.hw = (double*)calloc(itmp, sizeof(double));
	ts.hw2 = (double*)calloc(itmp, sizeof(double));
	ts.hpi = (double*)calloc(itmp, sizeof(double));
	itmp = ts.totalParms + 1;
	ts.stdErr = (double*)calloc(itmp, sizeof(double));
	ts.outestStart = (double*)calloc(itmp, sizeof(double));
	x_save = (double*)calloc(itmp, sizeof(double));
	g_save1 = (double*)calloc(itmp, sizeof(double));
	g_save2 = (double*)calloc(itmp, sizeof(double));
	if (ts.rorderStmt[0] || ts.ar1)
	{
		nmax = NMAX;
		itmp = ts.totalParms * ts.nIndep[0];
		ts.zmtrx1 = (double*)calloc(itmp, sizeof(double));
		ts.zmtrx2 = (double*)calloc(itmp, sizeof(double));
		itmp = ts.nIndep[0] * ts.nIndep[0];
		ts.smtrx = (double*)calloc(itmp, sizeof(double));
		ts.smtrxC = (double*)calloc(itmp, sizeof(double));
		ts.V = (double*)calloc(itmp, sizeof(double));
		ts.smtrx11 = (double*)calloc(itmp, sizeof(double));
		ts.smtrx21 = (double*)calloc(itmp, sizeof(double));
		ts.smtrx22 = (double*)calloc(itmp, sizeof(double));
		ts.simtrx2 = (double*)calloc(itmp, sizeof(double));
		itmp = ts.totalParms * ts.nIndep[0] * ts.nIndep[0];
		ts.smtrx12 = (double*)calloc(itmp, sizeof(double));
		ts.simtrx1 = (double*)calloc(itmp, sizeof(double));
	}
	getStataData(&ts);	
	if (ts.bicnobs == 0) WRITEERR("No observations with trajectory data.\n");
	if (ts.startStmt)
	{																
		for (i = 0; i < ts.numStartVal; i++) ts.initVal[i] = ts.start[i];
		if (ts.multModel) 
			adjustMultStartValues(&numStart, &ts);
		else 
			adjustStartValues(&numStart, &ts);	
	} 
	else															
		defaultStart(&ts);
	for (i = 0; i < numStart; i++) ts.start[i] = ts.initVal[i];
	loopc = 2;
	for (i = 0; i < ts.totalParms; i++) scale[i] = 1.;
	ts.iv[31] = 0;
	itmp = 2;
	deflt_(&itmp, ts.iv, &liv, &lv, ts.v);
	if (ts.itdetail)
	{
		ts.iv[18] = -1;
		SF_display("Start"); 
		parmTransform(&ts);
		printParmsToLog(numStart, ts.totalParms, ts.start, 1, &ts);	
		SF_display("              Neg. Log       Percent\n");
		SF_display("              Likelihood     Decrease\n\n");
		SF_display(" \n");
	}
	if (ts.convergenceTol != 0.) ts.v[31] = ts.convergenceTol;
	ts.iv[0] = 12;
	ts.mdl = 0;
	saveTP = ts.totalParms;
	if (ts.outcStmt[0] && ts.twoStep) ts.totalParms -= ts.nOutcPrm[0];
	if (ts.outcStmt[0] && !ts.twoStep) ts.nderiv = 1;
	if (ts.rorderStmt[0] || ts.ar1) ts.nderiv = 1;
	if (ts.dropoutStmt[0])
	{
		itmp = (int)ts.dOrd[0][0];
		for (i = 1; i < ts.nDropout[0]; i++) if (ts.dOrd[0][i] != itmp) ts.nderiv = 1;
	}
	if (ts.dropoutStmt[1]) ts.nderiv = 1;
	if (ts.dropoutStmt[0] &&(ts.multModel ||  ts.likelihoodType == JOINT)) ts.nderiv = 1;
	if (ts.iorderStmt[0] && ts.modelType[0] == m_zibeta) ts.nderiv = 1;
L3000:
	ts.vstOs = ts.stataOutputVarsPtr;
	if (ts.nderiv) 
	{
		switch (ts.likelihoodType)
		{
			case SINGLE:
			calcMLE_no_derivative_(&ts.totalParms, scale, ts.start, singleModelnll,
									ts.iv, &liv, &lv, ts.v, &ts);
			break;
			case JOINT:
			calcMLE_no_derivative_(&ts.totalParms, scale, ts.start, jointModelnll,
									ts.iv, &liv, &lv, ts.v, &ts);
			break;
			case MULTI:
			calcMLE_no_derivative_(&ts.totalParms, scale, ts.start, multModelnll,
									ts.iv, &liv, &lv, ts.v, &ts);
			break;
		}
		goto L3005;
	} 
	else 
	{
		switch (ts.likelihoodType)
		{
			case SINGLE:
			calcMLE_(&ts.totalParms, scale, ts.start, singleModelnll, 
					 singleModelDerivative, ts.iv, &liv, &lv, ts.v, &ts);
			break;
			case JOINT:
			calcMLE_(&ts.totalParms, scale, ts.start, jointModelnll, 
					 jointModelDerivative, ts.iv, &liv, &lv, ts.v, &ts);
			break;
			case MULTI:
			calcMLE_(&ts.totalParms, scale, ts.start, multModelnll,
					 multModelDerivative, ts.iv, &liv, &lv, ts.v, &ts);
			break;
		}
		goto L3005;
	}
L3005:
	if (ts.iv[0] == 8 && loopc >= 0) 
	{
		loopc--;
		ts.iv[0] = 12;
		goto L3000;
	}
	switch (ts.iv[0]) {
		case 3:	
		case 4:	 
		case 5:	
		case 6:	
			break;
		case 7:	
			WRITELOG("***** WARNING: Singular convergence *****\n"); 
			break;
		case 8:	
			WRITELOG("***** WARNING: False convergence *****\n"); 
			break;
/* errors 9 and up terminate traj */
		case 9:	
			WRITEERR("Function evaluation limit\n");  
		case 10:  
			WRITEERR("Function iteration limit\n");  
		case 63:  
			WRITEERR("Likelihood could not be computed at start values\n");  
		case 65:  
			WRITEERR("Gradient could not be computed\n");  
		default:  
			WRITEERR("Return code from minimizer: %d\n", ts.iv[0]); 
	}
/* derivative */
	g1 = ts.iv[27];
	alpha = g1 - ts.totalParms;
	w = alpha - 6;
	os = 0;
	for (i = 0; i < ts.totalParms; i++) ts.stdErr[i] = MACMISSING;
	ts.iflt = 0;
	ep1 = pow(DBL_EPSILON, 1. / 3.);
	for (i = 0; i < ts.totalParms; i++) x_save[i] = ts.start[i];
	if (ts.no_var) 
	{
		ts.iflt = 1;
		ts.outc_iflt = 1;		
		goto L3500;
	} 
	else if (ts.nderiv) 
	{
		for (j = 0; j < ts.totalParms; j++) 
		{
			for (i = 0; i < ts.totalParms; i++) ts.start[i] = x_save[i];
			ep = ep1 * (fabs(ts.start[j]) + ep1);
			ts.start[j] -= ep;
			ts.iv[56] = 0;
L3100:
			switch (ts.likelihoodType)
			{
			case SINGLE:
				singleModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			case JOINT:
				jointModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			case MULTI:
				multModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			}
			sgrad2_(&ts.v[alpha - 1], scale, &ts.v[41], &fx, &ts.v[g1 - 1], 
				    &ts.iv[56], &ts.totalParms, &ts.v[w - 1], ts.start);
			if (ts.iv[56] != 0) 
			{
				switch (ts.likelihoodType)
				{
				case SINGLE:
					singleModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				case JOINT:
					jointModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				case MULTI:
					multModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				}
				goto L3100;
			}		
			for (i = 0; i < ts.totalParms; i++) 
			{
				g_save1[i] = ts.v[g1 - 1 + i];
				ts.start[i] = x_save[i];
			}
			ts.start[j] += ep;
			ts.iv[56] = 0;
L3110:
			switch (ts.likelihoodType)
			{
			case SINGLE:
				singleModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			case JOINT:
				jointModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			case MULTI:
				multModelnll(ts.totalParms, ts.start, &fx, &ts);
				break;
			}
			sgrad2_(&ts.v[alpha - 1], scale, &ts.v[41], &fx, &ts.v[g1 - 1], &ts.iv[56], 
					&ts.totalParms, &ts.v[w - 1], ts.start);
			if (ts.iv[56] != 0)
			{
				switch (ts.likelihoodType)
				{
				case SINGLE:
					singleModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				case JOINT:
					jointModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				case MULTI:
					multModelnll(ts.totalParms, ts.start, &fx, &ts);
					break;
				}
				goto L3110;
			}
			for (i = 0; i < ts.totalParms; i++) 
				ts.hessian[os++] = (ts.v[g1 - 1 + i] - g_save1[i]) * 0.5 * pow (ep, -1.);
		}
	} 
	else 
	{
		for (j = 0; j < ts.totalParms; j++) {
			for (i = 0; i < ts.totalParms; i++) ts.start[i] = x_save[i];
			ep = ep1 * (fabs(ts.start[j]) + ep1);
			ts.start[j] -= ep;
			switch (ts.likelihoodType)
			{
			case SINGLE:
				singleModelnll(ts.totalParms, ts.start, &fx, &ts);
				singleModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
			case JOINT:
				jointModelnll(ts.totalParms, ts.start, &fx, &ts);
				jointModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
			case MULTI:
				multModelnll(ts.totalParms, ts.start, &fx, &ts);
				multModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
			}
			for (i = 0; i < ts.totalParms; i++)
			{
				ts.start[i] = x_save[i];
			}
			ts.start[j] += ep;
			switch (ts.likelihoodType)
			{
			case SINGLE:
				singleModelnll(ts.totalParms, ts.start, &fx, &ts);
				singleModelDerivative(ts.totalParms, ts.start, &itmp, g_save2, &ts);
				break;
			case JOINT:
				jointModelnll(ts.totalParms, ts.start, &fx, &ts);
				jointModelDerivative(ts.totalParms, ts.start, &itmp, g_save2, &ts);
				break;
			case MULTI:
				multModelnll(ts.totalParms, ts.start, &fx, &ts);
				multModelDerivative(ts.totalParms, ts.start, &itmp, g_save2, &ts);
				break;
			}
			for (i = 0; i < ts.totalParms; i++) ts.hessian[os++] = 
				(g_save2[i] - g_save1[i]) * 0.5 * pow (ep, -1.);
		}
	}
	for (i = 0; i < ts.totalParms; i++) ts.start[i] = x_save[i];
	if (ts.hessian[0] < 0.) 
		for (i = 0; i < ts.totalParms * ts.totalParms; i++) 
			ts.hessian[i] = -ts.hessian[i];
	dgefa_(ts.hessian, &ts.totalParms, &ts.totalParms, ts.iwork, &ts.iflt);
	if (ts.iflt) 
	{
		sprintf(buf, "ctraj iflt %d\n", ts.iflt);
		SF_display(buf);
		goto L3500;
	} 
	else 
	{
		itmp = 1;
		dgedi_(ts.hessian, &ts.totalParms, &ts.totalParms, ts.iwork, det2, ts.worknp, &itmp);
	}
	if (!ts.weightStmt) 
	{
		for (i = 0; i < ts.totalParms * ts.totalParms; i++) 
			ts.hessian[i] *= (double)ts.nData * pow((double)ts.nData - (double)ts.totalParms + 1., -1.);
		for (i = 0; i < ts.totalParms; i++) ts.stdErr[i] = sqrt(fabs(ts.hessian[i * ts.totalParms + i]));
	}
	/* Calc sandwich cov estimator for weight option */
	if (ts.weightStmt) 
	{
		switch (ts.likelihoodType) 
		{
			case SINGLE: 
				singleModelnll(ts.totalParms, ts.start, &fx, &ts);
				singleModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
			case JOINT:
				jointModelnll(ts.totalParms, ts.start, &fx, &ts);
				jointModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
			case MULTI:
				multModelnll(ts.totalParms, ts.start, &fx, &ts);
				multModelDerivative(ts.totalParms, ts.start, &itmp, g_save1, &ts);
				break;
		}
		for (jj = 0; jj < ts.totalParms; jj++) {
			for (r = 0; r < ts.totalParms; r++) {
				ts.hw[jj * ts.totalParms + r] = 0.;
				for (r2 = 0; r2 < ts.totalParms; r2++) {
					ts.hw[jj * ts.totalParms + r] += ts.hessian[jj * ts.totalParms + r2] *
													 ts.xprod[r2 * ts.totalParms + r];
				}
			}
		}
		for (jj = 0; jj < ts.totalParms; jj++) {
			for (r = 0; r < ts.totalParms; r++) {
				ts.hw2[jj * ts.totalParms + r] = 0.;
				for (r2 = 0; r2 < ts.totalParms; r2++) {
					ts.hw2[jj * ts.totalParms + r] += ts.hw[jj * ts.totalParms + r2] *
													  ts.hessian[r2 * ts.totalParms + r];
				}
			}
		}
		for (i = 0; i < ts.totalParms * ts.totalParms; i++) ts.hessian[i] = ts.hw2[i];
		for (i = 0; i < ts.totalParms; i++)
		{
			ts.hessian[i * ts.totalParms + i] = fabs(ts.hessian[i * ts.totalParms + i]);
			ts.stdErr[i] = sqrt(fabs(ts.hessian[i * ts.totalParms + i]));
		}
	}
L3500:
	if (ts.outcStmt[0] && ts.iv[0] < 7 && !ts.twoStep) 
	{
		for (i = 0; i < ts.nOutcPrm[0]; i++) 
		{
			ts.outcStart[i] = ts.start[ts.outcOffset + i];
			ts.outcStdErr[i] = sqrt(fabs(ts.hessian[i * ts.outcOffset + i]));
		}
	}
	calcs(&ts);
	if (ts.outcStmt[0] && ts.twoStep && ts.iv[0] > 6) 
		WRITEERR("Traj Model Problem - Skipping Outcome Model\n");
	/* OUTCOME MODEL 2S l-bfgs-b ****** */
	if (ts.outcStmt[0] && ts.iv[0] < 7 && ts.twoStep) 
	{
		for (i = 0; i < ts.totalParms * ts.totalParms; i++) ts.saveHessian[i] = ts.hessian[i];
		for (i = 0; i < ts.nOutcPrm[0]; i++) ts.outcStart[i] = ts.start[ts.totalParms + i];
		ts.totalParms = ts.nOutcPrm[0];
		B_outcLower = ts.B_lower + ts.outcOffset;
		B_outcUpper = ts.B_upper + ts.outcOffset;
		B_outcBoundtype = ts.B_boundtype + ts.outcOffset;
		factr = 1.0e3; 
		pgtol = 6.0e-6; 
		printLvl = -1; 	
		if (ts.itdetail) printLvl = 1; 		
		if (ts.trace) printLvl = 101;
		if (printLvl>0) WRITELOG("Outcome model\n")
		*task = (int)START;
L4001:
		setulb(&ts.totalParms, &mcorr, ts.outcStart, B_outcLower, B_outcUpper, B_outcBoundtype, &fx,
			g_save1, &factr, &pgtol, ts.outc_wa, ts.outc_iwa, task, &printLvl, csave, lsave, isave, dsave);
		if (IS_FG(*task)) 
		{
			outc_nll_2S(ts.nOutcPrm[0], ts.outcStart, &fx, &ts);
			outcDeriv2S(ts.nOutcPrm[0], ts.outcStart, &itmp, g_save1, &ts); 
			goto L4001;
		}
		if (*task==NEW_X) goto L4001;
		if (*task==CONV_F) WRITELOG("Outcome Model - False Convergence\n");
		if (IS_ERROR(*task)) WRITEERR("Outcome Model Not Fit - Convergence Problem\n");
		g1 = ts.iv_outc[27]; /* for nderiv */
		alpha = g1 - ts.nOutcPrm[0];
		w = alpha - 6; 
		/* total parms includes outcome parms for one and two step models */ 
		ts.totalParms = saveTP;
		/* save outcome model results in start vector after traj parameters */
		for (i = ts.totalParms - ts.nOutcPrm[0]; i < ts.totalParms; i++) 
		{
			ts.start[i] = ts.outcStart[i - (ts.totalParms - ts.nOutcPrm[0])];
			ts.stdErr[i] = MACMISSING;
		}
		os = ts.outc_iflt = 0;
		for (i = 0; i < ts.nOutcPrm[0]; i++) 
		{
			ts.outcStdErr[i] = MACMISSING;
			x_save[i] = ts.outcStart[i];
		}
		if (ts.no_var) 
		{
			ts.outc_iflt = 1;		
			goto L4500;
		}
		ep1 = pow(DBL_EPSILON, 1. / 3.);
		for (j = 0; j < ts.nOutcPrm[0]; j++) 
		{
			for (i = 0; i < ts.nOutcPrm[0]; i++) ts.outcStart[i] = x_save[i];
			ep = ep1 * (fabs(ts.outcStart[j]) + ep1);
			ts.outcStart[j] -= ep;
			outc_nll_2S(ts.nOutcPrm[0], ts.outcStart, &fx, &ts);				
			outcDeriv2S(ts.nOutcPrm[0], ts.outcStart, &itmp, g_save1, &ts); 
			for (i = 0; i < ts.nOutcPrm[0]; i++) ts.outcStart[i] = x_save[i];
			ts.outcStart[j] += ep;
			outc_nll_2S(ts.nOutcPrm[0], ts.outcStart, &fx, &ts);
			outcDeriv2S(ts.nOutcPrm[0], ts.outcStart, &itmp, g_save2, &ts); 
			for (i = 0; i < ts.nOutcPrm[0]; i++) 
				ts.outc_hessian[os++] = (g_save2[i] - g_save1[i]) * 0.5 * pow(ep, -1.);
		}
		for (i = 0; i < ts.nOutcPrm[0]; i++) ts.outcStart[i] = x_save[i];
		dgefa_(ts.outc_hessian, &ts.nOutcPrm[0], &ts.nOutcPrm[0], ts.iwork, &ts.outc_iflt);
		if (ts.outc_iflt) 
		{
			WRITELOG("outc iflt %d\n", ts.outc_iflt);
			goto L4500;
		} 
		else 
		{
			itmp = 1;				
			dgedi_(ts.outc_hessian, &ts.nOutcPrm[0], &ts.nOutcPrm[0], ts.iwork, det2, ts.worknp, &itmp);
		}
		if (!ts.weightStmt) 
		{
			for (i = 0; i < ts.nOutcPrm[0] * ts.nOutcPrm[0]; i++) 
			{
				ts.outc_hessian[i] *= pow((double)ts.bicnobs - (double)ts.nOutcPrm[0] + 1., -1.) * 
									  ts.bicnobs;
			}
		}
/*	if (ts.weightStmt) {
			outcDeriv2S(ts.nOutcPrm[0], ts.outcStart, &itmp, g_save1, &ts); 
			for (jj = 0; jj < ts.totalParms; jj++)
				for (r = 0; r < ts.totalParms; r++) {
					ts.hw[jj * ts.totalParms + r] = 0.;
					for (r2 = 0; r2 < ts.totalParms; r2++) 
						ts.hw[jj * ts.totalParms + r] += 
							ts.outc_hessian[jj * ts.totalParms + r2] * ts.xprod[r2 * ts.totalParms + r];
				}
			for (jj = 0; jj < ts.totalParms; jj++)
				for (r = 0; r < ts.totalParms; r++) {
					ts.hw2[jj * ts.totalParms + r] = 0.;
					for (r2 = 0; r2 < ts.totalParms; r2++) 
						ts.hw2[jj * ts.totalParms + r] += 
							ts.hw[jj * ts.totalParms + r2] * ts.outc_hessian[r2 * ts.totalParms + r];
				}
for (i = 0; i < ts.totalParms * ts.totalParms; i++) ts.outc_hessian[i] = ts.hw2[i];}  */
		for (i = 0; i < ts.nOutcPrm[0] - 1; i++)
			for (j = 1; j < ts.nOutcPrm[0]; j++) 
				ts.outc_hessian[i * ts.nOutcPrm[0] + j] = ts.outc_hessian[j * ts.nOutcPrm[0] + i];
		for (i = 0; i < ts.totalParms - ts.nOutcPrm[0]; i++) 
			for (j = 0; j < ts.totalParms; j++) 
			{
				ts.hessian[i * ts.totalParms + j] = ts.saveHessian[i * (ts.totalParms - ts.nOutcPrm[0]) + j];
				if (j >= ts.totalParms - ts.nOutcPrm[0]) ts.hessian[i * ts.totalParms + j] = 0.;
			}
		r = r2 = 0;
		for (i = ts.totalParms - ts.nOutcPrm[0]; i < ts.totalParms; i++) 
		{
			for (j = 0; j < ts.totalParms; j++) 
			{
				if (j < ts.totalParms - ts.nOutcPrm[0]) ts.hessian[i * ts.totalParms + j] = 0.;
				else 
				{
					ts.hessian[i * ts.totalParms + j] = ts.outc_hessian[r * ts.nOutcPrm[0] + r2];
					r2++;
				}
			}
			r2 = 0;
			r++;
		}	
		for (i = 0; i < ts.nOutcPrm[0]; i++) 
			ts.stdErr[ts.totalParms - ts.nOutcPrm[0] + i] = 
			ts.outcStdErr[i] = pow(fabs(ts.outc_hessian[i * ts.nOutcPrm[0] + i]), .5);
L4500:;   
	}	
	/* END TWO-STEP DISTAL OUTCOME MODEL ****** */
	ts.outcMdlfit[0] = -dsave[1] - .5 * log(ts.bicnobs) * (double)ts.nOutcPrm[0];
	ts.outcMdlfit[1] = -dsave[1] - (double)ts.nOutcPrm[0];
	ts.outcMdlfit[2] = -dsave[1];
	ts.mdlFit[0] = -ts.v[9] - .5 * log((double)ts.bicnobs) * ((double)ts.totalParms - (double)ts.nOutcPrm[0]);
	if (ts.twoStep) ts.mdlFit[0] += .5 * log((double)ts.bicnobs) * (double)ts.nOutcPrm[0];
	ts.mdlFit[0] = -ts.v[9] - .5 * log((double)ts.bicnobs) * ((double)ts.totalParms - (ts.twoStep ? (double)ts.nOutcPrm[0] : 0.));
	ts.mdlFit[1] = -ts.v[9] - .5 * log((double)ts.nData) * ((double)ts.totalParms - (ts.twoStep ? (double)ts.nOutcPrm[0] : 0.));
	ts.mdlFit[2] = -ts.v[9] - ((double)ts.totalParms - (ts.twoStep ? (double)ts.nOutcPrm[0] : 0.));
	ts.mdlFit[4] = -ts.v[9];
	if (ts.outcStmt[0]) 
	{
		itmp = 0;
		i = 0;
		expectedOutc(&itmp, 0, &i, &ts, 1);
		writeOutc(&ts);
	}
	if (ts.multModel) multTrajStataOutput(&ts); 
	else trajStataOutput(&ts); 
	if (ts.scoreCIOpt) scoreCI(ts.start, &ts);
	parmTransform(&ts);
	returnResultsToStata(&ts);
	if (ts.itdetail) 
	{
		parmTransform(&ts);
		printParmsToLog(numStart, ts.totalParms, ts.start, 0, &ts);	
	}
	free(x_save);
	free(g_save1);
	free(g_save2);
	free(scale);
	trajCleanUpStata(&ts);
	return(0);
}
