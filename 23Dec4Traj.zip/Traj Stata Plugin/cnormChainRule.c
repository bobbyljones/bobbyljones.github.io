/* 
	chain rule cnorm model	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 	
*/

#include "ctraj.h"

void cnormChainRule(int n, int* mdl, int* obs, int* gp, int* wv, double* prm, int* os, double *w, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		j, lSig, ofs;
	double	sgi, *tcovPtr, tmp, x, xb;

	for (j = 0; j < n; j++) w[j] = 0.;
	if ((int)ts->order[*mdl][*gp] == -1 && *gp == 0) return;  /* ts->all0Group, return */
	ofs = *os;
	lSig = ts->riskOffset[*mdl] - 1;
	if (ts->sigmaByGroup) lSig = ts->riskOffset[*mdl] - ts->nOrders[*mdl] + *gp;
	ts->sigma[0][*gp] = exp(prm[lSig]);
	sgi = pow(ts->sigma[0][*gp], -1.);
	if (ts->likelihoodType == JOINT)
	{
		ofs = *mdl == 1 ? ts->jointOffset : 0;
		for (j = 0; j < *gp; j++)
		{
			ofs += (int)ts->order[*mdl][j] + 1 +
				((int)ts->order[*mdl][j] + 1 > 0) * ts->nTcovParms[*mdl];
		}
	}
	tcovPtr = 0;
	if (ts->nTcov[*mdl] > 0) tcovPtr = ts->tcov[*mdl][*obs];
	xb = linPred(prm, &ts->indep[*mdl][*obs][*wv], &ofs, wv, &ts->nIndep[*mdl], &ts->order[*mdl][*gp],
				 &ts->nTcovParms[*mdl], tcovPtr);
	if (ts->dep[*mdl][*obs][*wv] <= ts->varMin[*mdl]) 
	{
		x = (ts->varMin[*mdl] - xb) * sgi;
		tmp = exp(-.5 * x * x) * RSQRT2PI * sgi;
		w[lSig] = -x * tmp;
		if (ts->nTcov[*mdl] > 0)
			for (j = 0; j < ts->nTcovParms[*mdl]; j++)
				w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = 
					-tmp * ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]];
		for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++) 
			w[ofs + j] = -tmp * pow(ts->indep[*mdl][*obs][*wv], j);
		
	}
	else if (ts->dep[*mdl][*obs][*wv] < ts->varMax[*mdl]) 
	{
		x = (ts->dep[*mdl][*obs][*wv] - xb) * sgi;
		w[lSig] = -(1. - x * x) * sgi * ts->varTrajLk[*mdl][*gp][*obs][*wv];
		if (ts->nTcov[*mdl] > 0)
			for (j = 0; j < ts->nTcovParms[*mdl]; j++)
				w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = 
					x * ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]] * 
					sgi * ts->varTrajLk[*mdl][*gp][*obs][*wv];
		for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++)
			w[ofs + j] = x * pow(ts->indep[*mdl][*obs][*wv], j) * 
						 sgi * ts->varTrajLk[*mdl][*gp][*obs][*wv];
	} 
	else
	{
		x = (ts->varMax[*mdl] - xb) * sgi;
		tmp = exp(-.5 * x * x) * RSQRT2PI * sgi;
		w[lSig] = x * tmp;	
		if (ts->nTcov[*mdl] > 0)
			for (j = 0; j < ts->nTcovParms[*mdl]; j++)
				w[ofs + j + (int)ts->order[*mdl][*gp] + j] = 
					tmp * ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]];
		for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++) 
			w[ofs + j] = tmp * pow(ts->indep[*mdl][*obs][*wv], j);
	}
}
