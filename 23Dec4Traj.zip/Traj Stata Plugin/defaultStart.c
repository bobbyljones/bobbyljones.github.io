/*  
	default start values	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/ 

#include "ctraj.h"

void defaultStart(void *qinfo)
{
	struct	TRAJSTRUCT *ts = qinfo;
	int		i, j, m, os, os2;
	double	mu, phi_start;

	os = 0;
	for (m = 0; m < ts->nModels; m++) 
	{
		if (m == 1 && ts->likelihoodType == JOINT) os = ts->jointOffset;
		for (i = 0; i < ts->nOrders[m]; i++) 
		{
			ts->initVal[os] = mu = ts->varMinObserved[m] + 
								  (ts->varMaxObserved[m] - ts->varMinObserved[m]) *
							      (i + 1.) / (ts->nOrders[m] + 1.);
			switch(ts->modelType[m]) 
			{	
				case m_logit:
					ts->initVal[os] = DEFLTMIN;
					if (mu > DBL_MIN && mu < 1.) ts->initVal[os] = logit(mu);
					break;
				case m_zibeta:
					mu = (i + 1.) / (ts->nOrders[m] + 1.);
					ts->initVal[os] = logit(mu);
					break;
				case m_zip:
					ts->initVal[os] = mu > DBL_MIN ? log(mu) : DEFLTMIN;
					break;
			}
			os += (int)ts->order[m][i] + 1 + ((int)ts->order[m][i] + 1 > 0) * ts->nTcovParms[m];
		}
		if (ts->dropoutStmt[m] && m < 2)
		{
			os = ts->dLoc[m];
			for (i = 0; i < ts->nDropout[m]; i++)
			{
				ts->initVal[os] = ts->dOrd[m][i] == -1. ? ts->initVal[os] : -3.;
				os += (int)ts->dOrd[m][i] + 1 + ts->nDcovPrm[m];
			}
		}
		switch(ts->modelType[m]) 
		{
			case m_cnorm: 
				os2 = ts->ar1 ? 2 + (ts->sigmaByGroup + ts->rhoByGroup) * (ts->nOrders[m] - 1) :
								1 + ts->sigmaByGroup * (ts->nOrders[m] - 1 - ts->all0Group[m]);
				os = (ts->rorderStmt[m]) ? ts->rorderOffset : ts->riskOffset[m];
				os -= os2;
				if (ts->sigmaByGroup)
				{
					for (i = ts->all0Group[m]; i < ts->nOrders[m]; i++)
						ts->initVal[os++] = ts->startSigma[m] > DBL_MIN ? log(ts->startSigma[m]) : 0.;
				} 
				else ts->initVal[os++] = ts->startSigma[m] > DBL_MIN ? log(ts->startSigma[m]) : 0.;
				if (ts->ar1)
				{
					if (ts->rhoByGroup)
					{
						for (i = 0; i < ts->nOrders[m]; i++) 
							ts->initVal[os++] = logit(ts->startRho[m]);
					} 
					else ts->initVal[os++] = logit(ts->startRho[m]);
				} 
				if (ts->rorderStmt[m]) 
					for (j = 0; j < ts->nRorderPrm; j++) ts->initVal[os + j] = -1.;
				break;
		case m_zibeta:
			phi_start = 0.;
			if (ts->startSigma[m] > DBL_MIN) 
				phi_start = 0.25 / ts->startSigma[m] / ts->startSigma[m] - 1.;
			os = ts->riskOffset[m] - ts->nOrders[m];
			for (i = 0; i < ts->nOrders[m]; i++) 
				ts->initVal[os++] = phi_start > DBL_MIN ? log(phi_start) : .5;
			break;
		case m_zip: 
			if (ts->iorderStmt[m]) 
			{	
				ts->initVal[os] = ts->iorder[m][0] == -1. ? ts->initVal[os] : -3.;
				os += (int)ts->iorder[m][0] + 1;
			} 
			if (!ts->commonIorder[m])
			{
				for (i = 1; i < ts->nOrders[m]; i++)
				{
					if (ts->iorderStmt[m]) 
					{
						ts->initVal[os] = ts->iorder[m][i] == -1. ? ts->initVal[os] : -3.;
						os += (int)ts->iorder[m][i] + 1;
					}
				}
			}
			break;
		}
	}
	switch(ts->likelihoodType) 
	{
		case MULTI:
			if (ts->nMultRisk == 0)
				for (i = 0; i < ts->nOrders[0]; i++) ts->group_percent[i] = 100. / ts->nOrders[0];
		break;
		case JOINT:
			if (ts->nRisk[1] == 0)
				for (i = 0; i < ts->nOrders[1]; i++) ts->group_percent[i] = 100. / ts->nOrders[1];
		case SINGLE:
			if (ts->nRisk[0] == 0) 
				for (i = 0; i < ts->nOrders[0]; i++) ts->group_percent[i] = 100. / ts->nOrders[0];
	}
	os = ts->outcOffset;
	if (ts->outcStmt[0])
	{
		if (ts->outcModelType[0] == m_mlogit)
		{
			for (j = 0; j < (ts->nOutcLevels[0] - 1) * ts->nOrders[0]; j++) ts->initVal[os++] = 0.;
		}
		else
		{
			for (i = 0; i < ts->nOrders[0]; i++)
			{
				ts->initVal[os] = mu = ts->outcMinObserved[0] +
					(ts->outcMaxObserved[0] - ts->outcMinObserved[0]) *
					((double)i + 1.) * pow((double)ts->nOrders[0] + 1., -1.);
				if (ts->outcModelType[0] == m_logit)
				{
					ts->initVal[os] = 0.;
					if (mu > DBL_MIN && mu < 1.) ts->initVal[os] = logit(mu);
				}
				if (ts->outcModelType[0] == m_zip) ts->initVal[os] = mu > DBL_MIN ? log(mu) : DEFLTMIN;
				os++;
			}
			if (ts->outcModelType[0] == m_cnorm)
				ts->initVal[os] = ts->ostsg > DBL_MIN ? log(ts->ostsg) : 0.;
		}
	}
}
