/* 
	Free memory allocation

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

void trajCleanUpStata(void *qi)
{
	struct TRAJSTRUCT *ts = qi;
	int	i, m;

	free(ts->iv);
	free(ts->v);
	free(ts->iwork);
	free(ts->start);
	free(ts->initVal);
	free(ts->workrslt);
	free(ts->worknp);
	free(ts->xprod);
	free(ts->score);
	free(ts->outestVarName);
	free(ts->hessian);
	free(ts->saveHessian);
	free(ts->outc_hessian);
	free(ts->outcStdErr);
	free(ts->outc_iwa);
	free(ts->outc_wa);
	free(ts->outcStart);
	free(ts->B_lower);
	free(ts->B_upper);
	free(ts->hw);
	free(ts->hw2);
	free(ts->stdErr);
	free(ts->outestStart);
	free(ts->B_boundtype);
	free(ts->iv_outc);
	free(ts->v_outc);
	free(ts->writeObs);
	free(ts->obsmar);
	free(ts->oos);
	free(ts->weight);
	free(ts->skip);
	free(ts->outc);
	free(ts->outcLk);
	free(ts->group_percent);
	free(ts->vr);
	free(ts->ymxb1);
	free(ts->ymxb2);
	free(ts->intlimit);
	free(ts->phi[0]);
	free(ts->sigma[0]);
	free(ts->sigmaSq[0]);
	free(ts->rho[0]);
	free(ts->hpi);
	free(ts->prdw);
	freeMat2d(ts->nOrders[0], ts->plotWork); 
	if (ts->rorderStmt[0] || ts->ar1)
	{
		//		free(ts->rnd);
		free(ts->zmtrx1);
		free(ts->zmtrx2);
		free(ts->smtrx);
		free(ts->smtrxC);
		free(ts->V);
		free(ts->smtrx11);
		free(ts->smtrx12);
		free(ts->smtrx21);
		free(ts->smtrx22);
		free(ts->simtrx1);
		free(ts->simtrx2);
	}
	if (ts->outcStmt[0])
	{
		free(ts->meanOutc);
		free(ts->linkfMeanOutc);
		free(ts->meanOutcL95);
		free(ts->meanOutcU95);
		if (ts->outcModelType[0] == m_mlogit)
		{
			if (ts->nOutcLevels[0] > 0.)
			{
				freeMat2d(ts->maxInputObs, ts->mlogitOutcProb[0]);
				free(ts->mlogitOutcLevel[0]);
			}
			freeMat2d(ts->nOutcLevels[0], ts->probOutc);
			freeMat2d(ts->nOrders[0], ts->linkfMeanMlogitOutc);
			freeMat2d(ts->nOrders[0], ts->meanMlogitOutc);
			freeMat2d(ts->nOrders[0], ts->meanMlogitOutcL95);
			freeMat2d(ts->nOrders[0], ts->meanMlogitOutcU95);
			if (ts->probupdates) freeMat3d(ts->nOutcLevels[0], ts->maxInputObs, ts->probOutc_T);
		}
	}
	if (ts->multModel)
	{
		if (ts->probupdates) freeMat3d(ts->nMultGroups, ts->maxInputObs, ts->obsMultTrajLk_T);
		freeMat2d(ts->nMultGroups, ts->obsMultTrajLk);
		free(ts->multGroupProb);
		free(ts->obsMultModelLk);
	}

	if (ts->likelihoodType == JOINT)
	{
		free(ts->pv_jk);
		free(ts->pv_2);
		freeMat3d(ts->nOrders[0], ts->nOrders[1], ts->obsJointTrajLk);
	}
	switch (ts->likelihoodType) 
	{
		case JOINT: 
		{	
			free(ts->phi[1]);
			free(ts->sigma[1]);
			free(ts->sigmaSq[1]);
			free(ts->rho[1]);
			free(ts->groupProbSum[1]);
			free(ts->dataStartTime[1]);
			free(ts->posteriorProb[1]);
		}
		case MULTI:
		case SINGLE: 
		{
			free(ts->groupProbSum[0]);
			free(ts->dataStartTime[0]);
			free(ts->posteriorProb[0]);
			if (ts->probupdates)
			{
				freeMat2d(ts->nOrders[0], ts->groupProbSum_T[0]);
				freeMat2d(ts->nOrders[0], ts->posteriorProb_T[0]);
			}
		}
	}
	for (m = 0; m < ts->nModels; m++) 
	{
		for (i = 0; i < ts->maxInputObs; i++) free(ts->missV[m][i]);
		free(ts->missV[m]);
		if (ts->nTcov[m] > 0)
		{
			freeMat2d(ts->maxInputObs, ts->tcov[m]);
			freeMat2dc(ts->nTcov[m], ts->tcovNames[m]);
			free(ts->plotTcov[m]);
		}
		if (ts->probupdates) freeMat3d(ts->nOrders[m], ts->maxInputObs, ts->obsTrajLk_T[m]);
		if (ts->nExpos[m] > 0) freeMat2d(ts->maxInputObs, ts->exposure[m]);
		freeMat2d(ts->maxInputObs, ts->indep[m]);
		freeMat2d(ts->maxInputObs, ts->dep[m]);
		freeMat2d(ts->nIndep[m], ts->varSumByGroupTime[m]);
		freeMat2d(ts->nIndep[m], ts->expectedTrajByGroupTime[m]);
		freeMat2d(ts->nIndep[m], ts->varianceSum[m]);
		freeMat2d(ts->nIndep[m], ts->probSumByGroupTime[m]);
		free(ts->groupProb[m]);		
		free(ts->indepCount[m]);		
		free(ts->averageIndep[m]);		
		free(ts->plotData[m]);
		freeMat3d(ts->nOrders[m], ts->maxInputObs, ts->varTrajLk[m]);
		freeMat3d(ts->nOrders[m], ts->maxInputObs, ts->varGradient[m]);
		freeMat2d(ts->nOrders[m], ts->obsTrajLk[m]);
	}
	for (m = 0; m < 2; m++)
	{
		free(ts->dropoutTime[m]);
		if (ts->dropoutStmt[m])
		{
			//free(ts->obsMultModelLkByModel);
			freeMat2d(ts->nIndep[m], ts->dropoutSumByGroupTime[m]);
			freeMat2d(ts->nIndep[m], ts->dropoutCountByGroupTime[m]);
			freeMat3d(ts->nOrders[m], ts->maxInputObs, ts->varDropoutLk[m]);
			freeMat2d(ts->nOrders[m], ts->dropoutProb[m]);
			freeMat2d(ts->nOrders[m], ts->obsDropoutLk[m]);
		}
		if (ts->nRisk[m] != 0)
		{
			freeMat2d(ts->maxInputObs, ts->risk[m]);
			freeMat2dc(ts->nRisk[m], ts->riskNames[m]);
		}
		if (ts->nDcov[m] != 0)
		{
			freeMat2d(ts->maxInputObs, ts->dcov[m]);
			freeMat2dc(ts->nDcov[m], ts->dcovNames[m]);
		}
	}
	if (ts->nMultRisk != 0)
	{
		freeMat2d(ts->maxInputObs, ts->multRisk);
		freeMat2dc(ts->nMultRisk, ts->multRiskNames);
	}
	if (ts->nOcov[0] != 0)
	{
		freeMat2d(ts->maxInputObs, ts->ocov[0]);
		freeMat2dc(ts->nOcov[0], ts->ocovNames[0]);
	}
}

void freeMat2d(int rows, double** mat)
{
	int i;

	for (i = 0; i < rows; i++) free(mat[i]);
	free(mat);
}

void freeMat2dc(int rows, char** mat)
{
	int i;

	for (i = 0; i < rows; i++) free(mat[i]);
	free(mat);
}

void freeMat3d(int rows, int cols, double*** mat)
{
	int i, j;

	for (j = 0; j < rows; j++)
	{
		for (i = 0; i < cols; i++) free(mat[j][i]);
		free(mat[j]);
	}
	free(mat);
}
