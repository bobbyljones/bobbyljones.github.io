/* 
	Calculate CI for multinomial outcome using Sison and Glaz method

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

void mlogitCI(double *rslt, void *qi)
{
	struct	TRAJSTRUCT *ts = qi;
	int		i;
	double	c=5., cc, delta, pold, pp=0., sum;

	pold = 0.;
	sum = 0.;
	for (i = 0; i < ts->nOutcLevels[0]; i++) sum += ts->mlogitX[i];
	for (cc = 5.; cc < (int)sum; cc++)
	{
		pp = truncpoi(cc, sum, qi);
		c = cc; 
		if (pp > 0.95)
			if (pold < 0.95)
				break;
		pold = pp;
	}
	delta = (1. - 0.05 - pold) / (pp - pold);
	c-- ;
	for (i = 0; i < ts->nOutcLevels[0]; i++)
	{	
		rslt[2 * i] = ts->mlogitX[i] / sum - c / sum;
		rslt[2 * i + 1] = ts->mlogitX[i] / sum + c / sum + 2. * delta / sum;
		if (rslt[2 * i] < 0.) rslt[2 * i] = 0.;
		if (rslt[2 * i + 1] > 1.) rslt[2 * i + 1] = 1.;
	}
}


