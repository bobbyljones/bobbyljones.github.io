#include "ctraj.h"

int daxpyRef(int *n, double *da, double *dx, 
	int *incx, double *dy, int *incy)
{
    int i__1;

    static int i, m, ix, iy, mp1;

/*     constant times a vector plus a vector.   
       uses unrolled loops for increments equal to one.   
       jack dongarra, linpack, 3/11/78.   
       modified 12/3/93, array(1) declarations changed to array(*)   
*/
#define DY(I) dy[(I)-1]
#define DX(I) dx[(I)-1]

    if (*n <= 0) {
        return 0;
    }
    if (*da == 0.) {
        return 0;
    }
    if (*incx == 1 && *incy == 1) {
        goto L20;
    }

    /*        code for unequal increments or equal increments   
              not equal to 1 */

    ix = 1;
    iy = 1;
    if (*incx < 0) {
        ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
        iy = (-(*n) + 1) * *incy + 1;
    }
    i__1 = *n;
    for (i = 1; i <= *n; ++i) {
        DY(iy) += *da * DX(ix);
        ix += *incx;
        iy += *incy;
        /* L10: */
    }
    return 0;

    /*        code for both increments equal to 1   

              clean-up loop */

L20:
    m = *n % 4;
    if (m == 0) {
        goto L40;
    }
    i__1 = m;
    for (i = 1; i <= m; ++i) {
        DY(i) += *da * DX(i);
    }
    if (*n < 4) {
        return 0;
    }
L40:
    mp1 = m + 1;
    i__1 = *n;
    for (i = mp1; i <= *n; i += 4) {
        DY(i) += *da * DX(i);
        DY(i + 1) += *da * DX(i + 1);
        DY(i + 2) += *da * DX(i + 2);
        DY(i + 3) += *da * DX(i + 3);
    }
    return 0;
} 


int dcopyRef(int *n, double *dx, int *incx, 
        double *dy, int *incy)
{
    int i__1;

    static int i, m, ix, iy, mp1;

    /*     copies a vector, x, to a vector, y.   
           uses unrolled loops for increments equal to one.   
           jack dongarra, linpack, 3/11/78.   
           modified 12/3/93, array(1) declarations changed to array(*)   
 */
#define DY(I) dy[(I)-1]
#define DX(I) dx[(I)-1]

    if (*n <= 0) {
        return 0;
    }
    if (*incx == 1 && *incy == 1) {
        goto L20;
    }

    /*        code for unequal increments or equal increments   
              not equal to 1 */
    ix = 1;
    iy = 1;
    if (*incx < 0) {
        ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
        iy = (-(*n) + 1) * *incy + 1;
    }
    i__1 = *n;
    for (i = 1; i <= *n; ++i) {
        DY(iy) = DX(ix);
        ix += *incx;
        iy += *incy;
    }
    return 0;

    /*        code for both increments equal to 1   

              clean-up loop */

L20:
    m = *n % 7;
    if (m == 0) {
        goto L40;
    }
    i__1 = m;
    for (i = 1; i <= m; ++i) {
        DY(i) = DX(i);
    }
    if (*n < 7) {
        return 0;
    }
L40:
    mp1 = m + 1;
    i__1 = *n;
    for (i = mp1; i <= *n; i += 7) {
        DY(i) = DX(i);
        DY(i + 1) = DX(i + 1);
        DY(i + 2) = DX(i + 2);
        DY(i + 3) = DX(i + 3);
        DY(i + 4) = DX(i + 4);
        DY(i + 5) = DX(i + 5);
        DY(i + 6) = DX(i + 6);
    }
    return 0;
} 

double ddotRef(int *n, double *dx, int *incx, double *dy, 
        int *incy)
{
    int i__1;
    double ret_val;

    static int i, m;
    static double dtemp;
    static int ix, iy, mp1;

    /*     forms the dot product of two vectors.   
           uses unrolled loops for increments equal to one.   
           jack dongarra, linpack, 3/11/78.   
           modified 12/3/93, array(1) declarations changed to array(*)   
*/
#define DY(I) dy[(I)-1]
#define DX(I) dx[(I)-1]

    ret_val = 0.;
    dtemp = 0.;
    if (*n <= 0) {
        return ret_val;
    }
    if (*incx == 1 && *incy == 1) {
        goto L20;
    }

    /*        code for unequal increments or equal increments   
              not equal to 1 */

    ix = 1;
    iy = 1;
    if (*incx < 0) {
        ix = (-(*n) + 1) * *incx + 1;
    }
    if (*incy < 0) {
        iy = (-(*n) + 1) * *incy + 1;
    }
    i__1 = *n;
    for (i = 1; i <= *n; ++i) {
        dtemp += DX(ix) * DY(iy);
        ix += *incx;
        iy += *incy;
    }
    ret_val = dtemp;
    return ret_val;

    /*        code for both increments equal to 1   

              clean-up loop */

L20:
    m = *n % 5;
    if (m == 0) {
        goto L40;
    }
    i__1 = m;
    for (i = 1; i <= m; ++i) {
        dtemp += DX(i) * DY(i);
    }
    if (*n < 5) {
        goto L60;
    }
L40:
    mp1 = m + 1;
    i__1 = *n;
    for (i = mp1; i <= *n; i += 5) {
        dtemp = dtemp + DX(i) * DY(i) + DX(i + 1) * DY(i + 1) + DX(i + 2) * 
            DY(i + 2) + DX(i + 3) * DY(i + 3) + DX(i + 4) * DY(i + 4);
    }
L60:
    ret_val = dtemp;
    return ret_val;
} 

int dscalRef(int *n, double *da, double *dx, 
        int *incx)
{
    int i__1, i__2;

    static int i, m, nincx, mp1;

    /*     scales a vector by a constant.   
           uses unrolled loops for increment equal to one.   
           jack dongarra, linpack, 3/11/78.   
           modified 3/93 to return if incx .le. 0.   
           modified 12/3/93, array(1) declarations changed to array(*)   
*/
#define DX(I) dx[(I)-1]

    if (*n <= 0 || *incx <= 0) {
        return 0;
    }
    if (*incx == 1) {
        goto L20;
    }

    /*        code for increment not equal to 1 */

    nincx = *n * *incx;
    i__1 = nincx;
    i__2 = *incx;
    for (i = 1; *incx < 0 ? i >= nincx : i <= nincx; i += *incx) {
        DX(i) = *da * DX(i);
    }
    return 0;

    /*        code for increment equal to 1   

              clean-up loop */

L20:
    m = *n % 5;
    if (m == 0) {
        goto L40;
    }
    i__2 = m;
    for (i = 1; i <= m; ++i) {
        DX(i) = *da * DX(i);
    }
    if (*n < 5) {
        return 0;
    }
L40:
    mp1 = m + 1;
    i__2 = *n;
    for (i = mp1; i <= *n; i += 5) {
        DX(i) = *da * DX(i);
        DX(i + 1) = *da * DX(i + 1);
        DX(i + 2) = *da * DX(i + 2);
        DX(i + 3) = *da * DX(i + 3);
        DX(i + 4) = *da * DX(i + 4);
    }
    return 0;
}
