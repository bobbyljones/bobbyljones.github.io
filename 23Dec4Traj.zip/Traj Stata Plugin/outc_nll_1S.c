/*	
	Distal outcome nll - 1S

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	

	GLM of outcome ~ P(gp1) + ... + P(gpK) + covariates
	No intercept model.
*/

#include "ctraj.h"
		
void outc_nll_1S(double *prm, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		ifault=0, j, jj, L, los, obs,
			wrkOS;		/* work offset for position calculations */	
	double	d1, lmb, **trajLk, oSg, tmp, xb;
	
	trajLk = ts->obsTrajLk[0];
	if (ts->likelihoodType == MULTI) trajLk = ts->obsMultTrajLk;
	if (ts->outcModelType[0] == m_cnorm) 
	{	
		wrkOS = ts->outcOffset + ts->nOrders[0] + ts->nOcov[0];
		oSg = exp(prm[wrkOS]);
	}
	for (obs = 0; obs < ts->nObs; obs++)
	{
		ts->outcLk[obs] = 0.;
		if (ts->skip[obs]) continue;
		xb = 0.;
		if (ts->outcModelType[0] != m_mlogit) 
		{
			for (j = 0; j < ts->nOrders[0]; j++) 
			{
				wrkOS = ts->outcOffset + j;
				xb += prm[wrkOS] * trajLk[j][obs];
				if (ts->nOcov[0] > 0) 
				{
					for (jj = 0; jj < ts->nOcov[0]; jj++) 
						xb += prm[ts->outcOffset + ts->nOrders[0] + jj] * 
							  ts->ocov[0][obs][jj] * trajLk[j][obs];
				}
			}
		}			
		switch (ts->outcModelType[0]) 
		{
			case m_cnorm:
				ts->outcLk[obs] = dnorm(&ts->outc[obs], &xb, &oSg);
				break;
			case m_logit:
				ts->outcLk[obs] = ts->outc[obs] == 0. ? 1. - invlogit(xb) : invlogit(xb);
				break;
			case m_mlogit:
				d1 = 1.;
				los = ts->nOutcLevels[0] + ts->nOcov[0];
				for (L = 0; L < ts->nOutcLevels[0]; L++)
				{
					if ((int)ts->mlogitOutcLevel[0][L] == ts->baseOutc[0])
						ts->mlogitOutcProb[0][obs][L] = 1.;
					else
					{
						xb = 0.;
						for (j = 0; j < ts->nOrders[0]; j++)
						{
							wrkOS = ts->outcOffset + los * (L - 1);
							xb += prm[wrkOS + j] * trajLk[j][obs];
							if (ts->nOcov[0] > 0)
							{
								for (jj = 0; jj < ts->nOcov[0]; jj++)
								{
									xb += prm[wrkOS + ts->nOrders[0] + jj] * ts->ocov[0][obs][jj] * 
										  trajLk[j][obs];
								}
							}
						}
						d1 += exp(xb);
						ts->mlogitOutcProb[0][obs][L] = exp(xb);
					}
				}
				for (L = 0; L < ts->nOutcLevels[0]; L++) 
				{
					if ((int)ts->outc[obs] == (int)ts->mlogitOutcLevel[0][L]) 
						ts->outcLk[obs] = ts->mlogitOutcProb[0][obs][L] * pow(d1, -1.);
				}
				break;
			case m_zip:	
				lmb = exp(xb);
				if (ts->outc[obs] == 0.) ts->outcLk[obs] = exp(-lmb);
				else
				{
					tmp = -lmb + ts->outc[obs] * log(lmb) - alogam(ts->outc[obs] + 1., &ifault);
					ts->outcLk[obs] = exp(tmp);
				}
				break;
		}
	}
}
