/* 	
	processing for traj models	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include "ctraj.h"

void calcs(void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		grp, j, k, m, noWrite, obs, svOs, vstOs, wave;
	double	dOrd, exposure, fx, temp, **trajLk, ***trajLk_T;

	if (ts->probupdates) 
	{
		ts->nPrUpdt = 1;
		switch (ts->likelihoodType) 
		{
			case MULTI: 
				multModelnll(ts->totalParms, ts->start, &fx, qi);
				break;
			case JOINT:
				break;
			case SINGLE:
				if (ts->modelType[0] == m_cnorm && ts->ar1) 
				{
					for (j = 1; j < ts->nIndep[0]; j++) 
					{
						ts->nPrUpdt = j;
						singleModelnll(ts->totalParms, ts->start, &fx, qi);
					}
				}
				else
					singleModelnll(ts->totalParms, ts->start, &fx, qi);
				break;
		}
	}
	noWrite = 0;
	switch (ts->likelihoodType)
	{
	case JOINT:
		for (j = 1; j < ts->nOrders[1]; j++)
			ts->groupProbSum[1][j] = 0.;
	case MULTI:
	case SINGLE:
		for (j = 0; j < ts->nOrders[0]; j++)
			ts->groupProbSum[0][j] = 0.;
		break;
	}
	ts->numModelObs = 0;
	svOs = ts->vstOs;
	for (obs = 0; obs < SF_nobs(); obs++) 
	{	
		vstOs = svOs;
		if (!ts->writeObs[noWrite] || ts->skip[noWrite]) goto L5900;
		trajLk = ts->obsTrajLk[0];
		trajLk_T = ts->obsTrajLk_T[0];
		if (ts->likelihoodType == MULTI) 
		{
				trajLk = ts->obsMultTrajLk; 
				trajLk_T = ts->obsMultTrajLk_T;
		}
		if (ts->likelihoodType != JOINT) 
		{
			temp = 0.;
			for (j = 0; j < ts->nOrders[0]; j++)
				temp += trajLk[j][obs];
			for (j = 0; j < ts->nOrders[0]; j++)
				trajLk[j][obs] = trajLk[j][obs] / temp;
		}
		if (ts->probupdates && !ts->skip[obs]) 
		{
			for (wave = 0; wave < ts->probUpdateWaves; wave++) 
			{
				temp = 0.;
				for (j = 0; j < ts->nOrders[0]; j++) temp += trajLk_T[j][obs][wave];
				for (j = 0; j < ts->nOrders[0]; j++) 
					trajLk_T[j][obs][wave] = trajLk_T[j][obs][wave] / temp;
			}
		}
		calcClassifications(&noWrite, qi);
		for (m = 0; m < 2; m++)
		{
			if (ts->dropoutStmt[m])
			{
				for (grp = 0; grp < ts->nOrders[m]; grp++)
				{
					dOrd = ts->nDropout[m] > 1 ? ts->dOrd[m][grp] : ts->dOrd[m][0];
					for (k = 0; k < ts->nIndep[m]; k++)
					{
						ts->dropoutProb[m][grp][k] = MACMISSING;
						if (k < ts->dropoutTime[m][noWrite] &&
							k >= (ts->dataStartTime[m][noWrite] + dOrd) &&
							!IS_MISSING(ts->varDropoutLk[m][grp][noWrite][k]))
							ts->dropoutProb[m][grp][k] = 1. - ts->varDropoutLk[m][grp][noWrite][k];
						if (k == ts->dropoutTime[m][noWrite] &&
							k >= (ts->dataStartTime[m][noWrite] + dOrd) &&
							!IS_MISSING(ts->varDropoutLk[m][grp][noWrite][k]))
							ts->dropoutProb[m][grp][k] = ts->varDropoutLk[m][grp][noWrite][k];
					}
				}
			}
		}
		if (!ts->oos[noWrite]) 
		{
			for (m = 0; m < ts->nModels; m++) 
			{
				if (!ts->plotTcovStmt[m] && ts->nTcov[m] > 0) 
				{
					for (j = 0; j < ts->nTcov[m]; j++) 
					{
						if (!IS_MISSING(ts->tcov[m][noWrite][j])) 
							ts->plotTcov[m][j] = ts->tcov[m][noWrite][j];
					}			
				}
				for (wave = 0; wave < ts->nIndep[m]; wave++) 
				{
					for (k = 0; k < ts->nOrders[m]; k++) 
					{
						if (ts->dropoutStmt[m] && m < 2) 
						{
							if (!IS_MISSING(ts->dropoutProb[m][k][wave]) && 
								ts->dropoutProb[m][k][wave] > DBL_EPSILON && 
								(int) ts->classifiedGroup[m] == k + 1) 
							{
								ts->dropoutSumByGroupTime[m][wave][k] += ts->dropoutProb[m][k][wave];
								ts->dropoutCountByGroupTime[m][wave][k]++;
							}
						}
					}
					if (ts->missV[m][noWrite][wave]) continue;
					ts->mdl = m;
					exposure = ts->nExpos[m] > 0 ? ts->exposure[m][noWrite][wave] : 1.;
					expectedTraj(&wave, &ts->averageIndep[m][wave], &exposure, ts->prdw, ts->vr, qi);
					if (!IS_MISSING(ts->weight[obs])) 
					{
						for (k = 0; k < ts->nOrders[m]; k++) 
						{
							switch (ts->likelihoodType) 
							{
								case JOINT:
									ts->probSumByGroupTime[m][wave][k] += 
										ts->posteriorProb[m][k] * ts->weight[obs];
									ts->varSumByGroupTime[m][wave][k] += ts->dep[m][noWrite][wave] *
										ts->posteriorProb[m][k] * ts->weight[obs];
									break; 
								case MULTI: 
								case SINGLE: 
									ts->probSumByGroupTime[m][wave][k] += 
										ts->posteriorProb[0][k] * ts->weight[obs];
									ts->varSumByGroupTime[m][wave][k] += ts->dep[m][noWrite][wave] * 
										ts->posteriorProb[0][k] * ts->weight[obs];
									break;
							}
							ts->expectedTrajByGroupTime[m][wave][k] = ts->prdw[k];
							ts->varianceSum[m][wave][k] = !ts->iflt && !ts->no_var ? ts->vr[k] : 0.;
						}
					}
				}
			}
		}		
L5900:;
		if (ts->skip[obs]) 
		{
			ts->classifiedGroup[0] = MACMISSING;
			for (k = 0; k < ts->nOrders[0]; k++) ts->posteriorProb[0][k] = MACMISSING;
			if (!ts->multModel && ts->nOrders[1] > 0) 
			{
				ts->classifiedGroup[1] = MACMISSING;
				for (k = 0; k < ts->nOrders[1]; k++) ts->posteriorProb[1][k] = MACMISSING;
			} 
		}
		if (!ts->oos[obs] && !ts->skip[obs]) ts->numModelObs++;
		SF_vstore(vstOs++, noWrite + 1, ts->classifiedGroup[0]);
		for (k = 0; k < ts->nOrders[0]; k++) 
		{
			SF_vstore(vstOs++, noWrite + 1, ts->posteriorProb[0][k]);
			if (!IS_MISSING(ts->posteriorProb[0][k]) && 
				!IS_MISSING(ts->weight[obs]) &&
				!ts->oos[obs] && !ts->skip[obs]) 
					ts->groupProbSum[0][k] += ts->posteriorProb[0][k] * ts->weight[obs];
		}
		if (ts->likelihoodType == JOINT) 
		{
			SF_vstore(vstOs++, noWrite + 1, ts->classifiedGroup[1]);
			for (k = 0; k < ts->nOrders[1]; k++) 
			{
				SF_vstore(vstOs++, noWrite + 1, ts->posteriorProb[1][k]);
				if (!IS_MISSING(ts->posteriorProb[1][k]) && 
					!IS_MISSING(ts->weight[obs]) &&
					!ts->oos[obs] && !ts->skip[obs]) 
						ts->groupProbSum[1][k] += ts->posteriorProb[1][k] * ts->weight[obs]; 
			}
		}
		if (!ts->skip[obs]) ts->vstOs = vstOs;
		if (ts->probupdates && !ts->skip[obs]) calcClassUpdates(&noWrite, qi);
		noWrite++; 
	}
}
