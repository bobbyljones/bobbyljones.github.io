/* 
	=========================================================================================================
	Expected trajectory for cnorm AR1 model	
	=========================================================================================================

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/
#include "ctraj.h"

static int c__1 = 1;

int mvnexp_(int *n, double *lower, double *upper, int *infin, double *correl, int *maxpts, double *abseps, 
	double *releps, double *error, double *value, int *inform, void *qi)
{
    int iseed=123,i__1, i__2;

    static int ivls, i;
    extern int dkbvrc_();
    static int infrmi;
    extern double mvvdfn_();
    extern double mvvdnt_();

/*     A subroutine for computing expected values for MVN variables. */
/*     This subroutine uses an algorithm given in the paper */
/*     "Numerical Computation of Multivariate Normal Probabilities", in */
/*     J. of Computational and Graphical Stat., 1(1992), pp. 141-149, by 
*/
/*          Alan Genz */
/*          Department of Mathematics */
/*          Washington State University */
/*          Pullman, WA 99164-3113 */
/*          Email : alangenz@wsu.edu */

/*  Parameters */

/*     N      int, the number of variables. */
/*     LOWER  REAL, array of lower integration limits. */
/*     UPPER  REAL, array of upper integration limits. */
/*     INFIN  int, array of integration limits flags: */
/*            if INFIN(I) = 0, Ith limits are (-infinity, UPPER(I)]; */
/*            if INFIN(I) = 1, Ith limits are [LOWER(I), infinity); */
/*            if INFIN(I) = 2, Ith limits are [LOWER(I), UPPER(I)]. */
/*     CORREL REAL, array of correlation coefficients; the correlation */
/*            coefficient in row I column J of the correlation matrix */
/*           should be stored in CORREL(J + ((I-2)*(I-1))/2), for J < I.
*/
/*     MAXPTS int, maximum number of function values allowed. This */
/*            parameter can be used to limit the time. A sensible */
/*            strategy is to start with MAXPTS = 1000*N, and then */
/*            increase MAXPTS if ERROR is too large. */
/*     ABSEPS    REAL absolute error tolerance. */
/*     RELEPS    REAL relative error tolerance. */
/*    ERROR  REAL array(0:N) of estimated abs errors, with 99% confidence.
*/
/*            ERROR(I) is estimated error for VALUE(I). */
/*     VALUE  REAL array(0:N) of estimated values for the integrals */
/*            VALUE(0) is just the MVN value. */
/*            VALUE(I) is the expected value for variable I. */
/*     INFORM int, termination status parameter: */
/*            if INFORM = 0, normal completion with ERROR < EPS; */
/*            if INFORM = 1, completion with ERROR > EPS and MAXPTS */
/*                           function vaules used; increase MAXPTS to */
/*                           decrease ERROR; */
/*            if INFORM = 2, N > 100 or N < 1. */

    /* Parameter adjustments */
    --correl;
    --infin;
    --upper;
    --lower;

    /* Function Body */
    if (*n > 100 || *n < 1) {
	*inform = 2;
	i__1 = *n;
	for (i = 0; i <= i__1; ++i) {
	    value[i] = 0.;
	    error[i] = 1.;
	}
    } else {
	MVN_Pr_(n, &lower[1], &upper[1], &infin[1], &correl[1], maxpts, 
		abseps, releps, error, value, inform, &iseed, &qi);
	if (*n == 1) {
	    value[1] = mvvdnt_(&c__1, &c__1, &correl[1], &lower[1], &upper[1],
		     &infin[1]);
	    error[1] = 1e-16;
	} else {
	    i__1 = *n;
	    for (i = 1; i <= i__1; ++i) {
		infrmi = (int) mvvdnt_(&i, n, &correl[1], &lower[1], &
			upper[1], &infin[1]);

/*              Call the lattice rule integration subroutine 
*/

		ivls = 0;
		i__2 = *n - 1;
		dkbvrc_(&i__2, &ivls, maxpts, mvvdfn_, abseps, releps, &error[
			i], &value[i], &infrmi);
		*inform = MAX(infrmi,*inform);
	    }
	}
	i__1 = *n;
	for (i = 1; i <= i__1; ++i) {
	    error[i] /= value[0];
	    value[i] /= value[0];
	}
    }
	return 0;
}

double mvvdfn_0_(n__, n, w, iv, correl, lower, upper, infin)
int n__;
int *n;
double *w;
int *iv;
double *correl, *lower, *upper;
int *infin;
{
    int i__1, i__2;
    double ret_val, d__1;

    static int infi[100];
    static double prod, a[100], b[100];
    static int i, j;
    static double y[100];
    static int infis;
    static double d1, e1, ai, bi, di, ei;
    static int ij;
    extern double phinvs_();
    extern int mvnlms_(), covsrt_();
    static double cov[5050], sum;
/*     Integrand subroutine */

    /* Parameter adjustments */
    if (w) {
	--w;
	}
    if (correl) {
	--correl;
	}
    if (lower) {
	--lower;
	}
    if (upper) {
	--upper;
	}
    if (infin) {
	--infin;
	}

    /* Function Body */
    switch(n__) {
	case 1: goto L_mvvdnt;
	}

    di = d1;
    ei = e1;
    prod = ei - di;
    ij = 1;
    i__1 = *n;
    for (i = 1; i <= i__1; ++i) {
	d__1 = di + w[i] * (ei - di);
	y[i - 1] = phinvs_(&d__1);
	sum = 0.;
	i__2 = i;
	for (j = 1; j <= i__2; ++j) {
	    ++ij;
	    sum += cov[ij - 1] * y[j - 1];
	}
	++ij;
	if (infi[i] != 0) {
	    ai = a[i] - sum;
	}
	if (infi[i] != 1) {
	    bi = b[i] - sum;
	}
	mvnlms_(&ai, &bi, &infi[i], &di, &ei);
	prod *= ei - di;
    }
    ret_val = prod * y[0];
    return ret_val;

/*     Entry point for intialization. */


L_mvvdnt:

/*     Initialization and computation of covariance Cholesky factor. */

    i = infin[*iv];
    ai = lower[*iv];
    bi = upper[*iv];
    di = 0.;
    ei = 0.;
    if (i != 0) {
/* Computing 2nd power */
	d__1 = ai;
	di = -exp(-(d__1 * d__1) / 2) / 2.506628274631001;
    }
    if (i != 1) {
/* Computing 2nd power */
	d__1 = bi;
	ei = -exp(-(d__1 * d__1) / 2) / 2.506628274631001;
    }
    if (*n == 1) {
	ret_val = ei - di;
    } else {
	ret_val = 0.;
	mvnlms_(&ai, &bi, &i, &d1, &e1);
	y[*iv - 1] = (ei - di) / (e1 - d1);
	lower[*iv] = y[*iv - 1];
	upper[*iv] = y[*iv - 1];
	infin[*iv] = 2;
	covsrt_(n, &lower[1], &upper[1], &correl[1], &infin[1], y, &infis, a, 
		b, cov, infi);
	lower[*iv] = ai;
	upper[*iv] = bi;
	infin[*iv] = i;
    }
    return ret_val;
} /* mvvdfn_ */

double mvvdfn_(n, w)
int *n;
double *w;
{
    return mvvdfn_0_(0, n, w, (int *)0, (double *)0, (double *)0, 
	    (double *)0, (int *)0);
    }

double mvvdnt_(iv, n, correl, lower, upper, infin)
int *iv, *n;
double *correl, *lower, *upper;
int *infin;
{
    return mvvdfn_0_(1, n, (double *)0, iv, correl, lower, upper, infin);
}