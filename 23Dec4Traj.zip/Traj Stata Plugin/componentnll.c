/*	
	traj component negative log-likelihood

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>

	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include	 "ctraj.h"

void componentnll(int nos, double* prm, void* qi)
{
	struct	TRAJSTRUCT* ts = qi;
	int		dLoc, dOrd, i, ifault = 0, j, jj, k, os, zo, zos;
	double	a, b, dat, lmb, rho, * tcovPtr, sgi, tmp, x, xb;

	if (ts->modelType[ts->mdl] == m_zip) zos = nos - ts->nZipParms[ts->mdl];
	if (ts->modelType[ts->mdl] == m_cnorm) 
	{
		if (ts->sigmaByGroup) 
		{
			for (k = ts->all0Group[ts->mdl]; k < ts->nOrders[ts->mdl]; k++)
				ts->sigma[0][k] = exp(prm[nos - ts->nOrders[ts->mdl] + k]);
		} 
		else 
			for (k = 0; k < ts->nOrders[ts->mdl]; k++) ts->sigma[0][k] = exp(prm[nos - 1]);
	}
	if (ts->modelType[ts->mdl] == m_zibeta) 
	{
		/* No all0Group for beta */
		for (k = 0; k < ts->nOrders[ts->mdl]; k++) 
			ts->phi[0][k] = exp(prm[nos - ts->nOrders[ts->mdl] + k]);
		zos = nos - ts->nZipParms[ts->mdl] - ts->nOrders[ts->mdl];
	}
	os = 0;
	zo = -1;
	if (ts->iorderStmt[ts->mdl]) zo = (int)ts->iorder[ts->mdl][0];
	if (ts->dropoutStmt[0] && ts->mdl == 0) dLoc = ts->dLoc[0];
	for (k = 0; k < ts->nOrders[ts->mdl]; k++) 
	{
		if (ts->iorderStmt[ts->mdl] && !ts->commonIorder[ts->mdl]) zo = (int)ts->iorder[ts->mdl][k];
		if (ts->dropoutStmt[0] && ts->mdl == 0) 
		{
			dOrd = (int)ts->dOrd[0][0];
			if (ts->nDropout[0] > 1) dOrd = (int)ts->dOrd[0][k];
		}
		sgi = pow(ts->sigma[0][k], -1.);
		for (i = 0; i < ts->nObs; i++)
		{
			ts->obsTrajLk[ts->mdl][k][i] = 1.;
			if (ts->dropoutStmt[0] && ts->mdl == 0) ts->obsDropoutLk[0][k][i] = 1.;
			if (ts->skip[i]) goto L200;
			for (j = 0; j < ts->nIndep[ts->mdl]; j++) 
			{
				ts->varTrajLk[ts->mdl][k][i][j] = 1.;
				if (ts->probupdates) ts->obsTrajLk_T[ts->mdl][k][i][j] = 1.;
				if (ts->missV[ts->mdl][i][j]) goto L100;
				if (ts->all0Group[ts->mdl] && k == 0) 
				{
					ts->varTrajLk[ts->mdl][k][i][j] = ts->dep[ts->mdl][i][j] == 0. ? 1. : 0.;
					goto L50;
				}
				rho = 0.;
				if (ts->iorderStmt[ts->mdl] && zo != -1) 
				{
					xb = prm[zos];
					for (jj = 1; jj <= zo; jj++) xb += prm[zos + jj] * pow(ts->indep[ts->mdl][i][j], jj);
					rho = invlogit(xb);
				}
				tcovPtr = 0;
				if (ts->nTcov[ts->mdl] > 0) tcovPtr = ts->tcov[ts->mdl][i];
				xb = linPred(prm, &ts->indep[ts->mdl][i][j], &os, &j, &ts->nIndep[ts->mdl],
							 &ts->order[ts->mdl][k], &ts->nTcovParms[ts->mdl], tcovPtr);
				switch (ts->modelType[ts->mdl]) 
				{
				case m_zibeta:
					xb = invlogit(xb);
					a = xb * ts->phi[0][k];
					b = ts->phi[0][k] * (1. - xb);
					dat = ts->dep[ts->mdl][i][j];
					if (dat == 0.) dat = 0.5 / ts->bicnobs;
					if (dat == 1.) dat = (ts->bicnobs - 0.5) / ts->bicnobs;
					ts->varTrajLk[ts->mdl][k][i][j] = dbeta(&dat, &a, &b, &ts->phi[0][k], ifault);
					break;
				case m_cnorm:
					if (ts->dep[ts->mdl][i][j] <= ts->varMin[ts->mdl]) 
					{
						x = (ts->varMin[ts->mdl] - xb) * sgi;
						ts->varTrajLk[ts->mdl][k][i][j] = mvnphi_(&x);
					}
					else if (ts->dep[ts->mdl][i][j] < ts->varMax[ts->mdl]) 
					{
						ts->varTrajLk[ts->mdl][k][i][j] =
							dnorm(&ts->dep[ts->mdl][i][j], &xb, &ts->sigma[0][k]);
					}
					else 
					{
						x = (ts->varMax[ts->mdl] - xb) * sgi;
						ts->varTrajLk[ts->mdl][k][i][j] = 1. - mvnphi_(&x);
					}
					break;
				case m_logit:
					xb = invlogit(xb);
					ts->varTrajLk[ts->mdl][k][i][j] = ts->dep[ts->mdl][i][j] == 0 ? 1. - xb : xb;
					break;
				case m_zip:
					xb = xb < -MAXEXP ? -MAXEXP : xb;
					xb = xb > MAXEXP ? MAXEXP : xb;
					lmb = exp(xb);
					if (ts->nExpos[ts->mdl] > 0)
						lmb *= ts->exposure[ts->mdl][i][j];
					if (ts->dep[ts->mdl][i][j] == 0.) 
					{
						lmb = lmb < -MAXEXP ? -MAXEXP : lmb;
						lmb = lmb > MAXEXP ? MAXEXP : lmb;
						ts->varTrajLk[ts->mdl][k][i][j] = rho + (1. - rho) * exp(-lmb);
					}
					else 
					{
						tmp = -lmb + ts->dep[ts->mdl][i][j] * log(lmb) -
							  alogam(ts->dep[ts->mdl][i][j] + 1., &ifault);
						tmp = tmp < -MAXEXP ? -MAXEXP : tmp;
						tmp = tmp > MAXEXP ? MAXEXP : tmp;
						ts->varTrajLk[ts->mdl][k][i][j] = (1. - rho) * exp(tmp);
					}
					break;
				}
			L50:;
				ts->obsTrajLk[ts->mdl][k][i] *= ts->varTrajLk[ts->mdl][k][i][j];
			L100:;
				if (ts->probupdates && ts->nPrUpdt > 0)
				{
					ts->obsTrajLk_T[ts->mdl][k][i][j] *= j > 0 ?
						ts->obsTrajLk_T[ts->mdl][k][i][j - 1] * ts->varTrajLk[ts->mdl][k][i][j] :
						ts->varTrajLk[ts->mdl][k][i][j];
				}
				if (ts->dropoutStmt[0] && ts->mdl == 0) 
				{
					ts->varDropoutLk[0][k][i][j] = dropoutLk(&i, &k, &j, prm, &dOrd, &dLoc, qi);
					ts->obsDropoutLk[0][k][i] *= ts->varDropoutLk[0][k][i][j];
				}
			}
		L200:;
		}
		os += (int)ts->order[ts->mdl][k] + 1 + ((int)ts->order[ts->mdl][k] + 1 > 0) * ts->nTcovParms[ts->mdl];
		if (ts->dropoutStmt[0] && ts->mdl == 0) 
		{
			if (ts->nDropout[0] > 1) dLoc += (int)ts->dOrd[0][k] + 1 + ts->nDcovPrm[0];
		}
		if (ts->iorderStmt[ts->mdl] && !ts->commonIorder[ts->mdl]) zos += (int)ts->iorder[ts->mdl][k] + 1;
	}
	return;
}

double dnorm(double* x, double* mu, double* sigma) 
{
	double z;
	z = fabs(*x - *mu) * pow(*sigma, -1);
	return exp(-.5 * z * z) * RSQRT2PI * pow(*sigma, -1);
}

double dbeta(double* x, double* a, double* b, double* phi, int ifault) 
{
	return pow(*x, *a - 1.) * pow(1. - *x, *b - 1.) * exp(alogam(*phi, &ifault) - alogam(*a, &ifault) - alogam(*b, &ifault));
}

double dropoutLk(int* obs, int* gp, int* wv, double* prm, int *ord, int* dl, void* qi) {

	struct	TRAJSTRUCT* ts = qi;
	int		jj;
	double	pr, xb;

	pr = 1.;
	if (*wv < ts->dataStartTime[ts->mdl][*obs] + ts->completeDataLen[ts->mdl] &&
		*wv > ts->dataStartTime[ts->mdl][*obs])
	{
		if (*ord != -1 && *wv >= ts->dataStartTime[ts->mdl][*obs] + (*ord) &&
			*wv <= ts->dropoutTime[ts->mdl][*obs])
		{
			xb = prm[*dl];
			if (*ord > 0)
			{
				for (jj = 1; jj <= *ord; jj++)
				{
					if (!IS_MISSING(ts->dep[ts->mdl][*obs][*wv - jj]))
						xb += prm[*dl + jj] * ts->dep[ts->mdl][*obs][*wv - jj];
					else return(pr);
				}
			}
			if (ts->nDcov[ts->mdl] > 0)
			{
				for (jj = 0; jj < ts->nDcov[ts->mdl] / ts->nIndep[ts->mdl]; jj++)
				{
					if (!IS_MISSING(ts->dcov[ts->mdl][*obs][*wv + jj * ts->nIndep[ts->mdl] - 1]))
					{
						xb += prm[*dl + jj + (*ord) + 1] * ts->dcov[ts->mdl][*obs][*wv + jj *
							  ts->nIndep[ts->mdl] - 1];
					}
					else return(pr);
				}
			}
			xb = invlogit(xb);
			if (*wv < ts->dropoutTime[ts->mdl][*obs] || ts->obsmar[*obs]) pr = 1. - xb;
			if (*wv == ts->dropoutTime[ts->mdl][*obs] && !ts->obsmar[*obs]) pr = xb;
		}
	}
	return(pr);
}

double linPred(double* prm, double* ind, int* os, int* wv, int* ni, double* order, int* ntp, double* tcovTyp) {
/*	--tcovType tcov[mdl][obs] or plotTcov[mdl] */
	int jj;
	double xb;

	xb = prm[*os];
	for (jj = 1; jj <= (int)*order; jj++) xb += prm[*os + jj] * pow(*ind, jj);
	if (*ntp > 0 && tcovTyp != 0)
	{
		for (jj = 0; jj < *ntp; jj++)
			xb += prm[*os + 1 + (int)*order + jj] * tcovTyp[*wv + jj * (*ni)];
	}
	return xb;
}