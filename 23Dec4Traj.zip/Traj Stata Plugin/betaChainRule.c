/* 	
	chain rule beta model	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 	*/

#include "ctraj.h"

void betaChainRule(int n, int* mdl, int* obs, int* gp, int* wv, double* prm, int* os, double *w, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		ifault=0, j, logPhiPrm, ofs;	
	double	a, b, dat, da, db, dp, mu, phk, rho, *tcovPtr, xb;

	for (j = 0; j < n; j++) w[j] = 0.;
	if ((int)ts->order[*mdl][*gp] == -1 && *gp == 0) return; /* ts->all0Group */
	ofs = *os;
	rho = 0.;
	logPhiPrm = ts->riskOffset[*mdl] - ts->nOrders[*mdl] + *gp;
	phk = ts->phi[0][*gp] = exp(prm[logPhiPrm]);
	if (ts->multModel) 
		for (j = 0; j < *mdl; j++) ofs += ts->nModelParm[j];
	tcovPtr = 0;
	if (ts->nTcov[*mdl] > 0) tcovPtr = ts->tcov[*mdl][*obs];
	xb = linPred(prm, &ts->indep[*mdl][*obs][*wv], &ofs, wv, &ts->nIndep[*mdl], &ts->order[*mdl][*gp],
		         &ts->nTcovParms[*mdl], tcovPtr);
	mu = invlogit(xb);
	dat = ts->dep[*mdl][*obs][*wv];
	if (dat == 0.) dat = 0.5 / ts->bicnobs;
	if (dat == 1.) dat = (ts->bicnobs - 0.5) / ts->bicnobs;
	a = mu * phk;
	b = (1. - mu) * phk;
	da = digamma(a, &ifault);
	db = digamma(b, &ifault);
	dp = digamma(phk, &ifault);
	w[logPhiPrm] = (1. - mu) * log(1. - dat) + mu * log(dat) + dp - mu * da - (1. - mu) * db;
	w[logPhiPrm] *= ts->varTrajLk[*mdl][*gp][*obs][*wv]; 
	if (ts->nTcov[*mdl] > 0) 
	{
		for (j = 0; j < ts->nTcovParms[*mdl]; j++) 
		{
			w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] = log(dat) - log(1. - dat) - da + db;
			w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] *= phk * ts->varTrajLk[*mdl][*gp][*obs][*wv];
			w[ofs + 1 + (int)ts->order[*mdl][*gp] + j] *= mu * (1. - mu) * 
														  ts->tcov[*mdl][*obs][*wv + j * ts->nIndep[*mdl]];
		}
	}
	for (j = 0; j <= (int)ts->order[*mdl][*gp]; j++) 
	{
		w[ofs + j] = log(dat) - log(1. - dat) - da + db;
		w[ofs + j] *= phk * ts->varTrajLk[*mdl][*gp][*obs][*wv];
		w[ofs + j] *= mu * (1. - mu) * pow(ts->indep[*mdl][*obs][*wv], j);
	}
	return;
}
