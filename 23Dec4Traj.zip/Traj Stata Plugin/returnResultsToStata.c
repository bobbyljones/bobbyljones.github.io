/* 
	=======================================================================================================================
	return results to Stata	
	=======================================================================================================================

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/
#include	 "ctraj.h"

int returnResultsToStata(void *qinfo)
{
	struct	TRAJSTRUCT *ts = qinfo;
	char	l_str[33];
	int		gp, i, j, m, nm, os, rowCount;
	double	intervalWidth, rc, size;


	SF_scal_save("BIC_n", ts->mdlFit[0]);
	
	SF_scal_save("BIC_N", ts->mdlFit[1]);
	
	SF_scal_save("aic", ts->mdlFit[2]);
	
	SF_scal_save("loglike", ts->mdlFit[4]);

	rc = 0.;
	
	if (ts->mdlFit[3] > 6) rc = ts->mdlFit[3];
	
	SF_scal_save("rc", rc);
	
	for (i = 0; i < ts->totalParms; i++) 
		SF_mat_store("parmData", 1, i + 1, ts->outestStart[i]);
	
	for (i = 0; i < ts->totalParms; i++) for (j = 0; j < ts->totalParms; j++)
		SF_mat_store("varData", i + 1, j + 1, ts->hessian[i * ts->totalParms + j]);

	nm = (ts->likelihoodType == JOINT) ? 1 : 0;

	for (m = 0; m <= nm; m++)
	{
		sprintf(l_str, "groupPct%d", m + 1);

		for (gp = 0; gp < ts->nOrders[m]; gp++)
		{
			size = 100. * ts->groupProbSum[m][gp] / ts->numModelObs;

			SF_mat_store(l_str, 1, gp + 1, size);
		}	
	}

	for (m = 0; m < ts->nModels; m++) 
	{
		rowCount = 1;
		
		ts->mdl = m;

		for (i = 0; i < ts->nIndep[m]; i++)
		{
			ts->plotData[m][0] = ts->averageIndep[m][i];
		
			for (gp = 0; gp < ts->nOrders[m]; gp++)
			{
				os = 2 * ts->nOrders[m] + 1 + 2 * gp;
		
				ts->plotData[m][1 + gp] = ts->plotData[m][ts->nOrders[m] + 1 + gp] = ts->plotData[m][os] =
					ts->plotData[m][os + 1] = MACMISSING;

				ts->plotData[m][2 * ts->nOrders[m] + 2 * ts->nOrders[m] + 1 + gp] = MACMISSING;

				if (ts->probSumByGroupTime[m][i][gp] > 0.5)
				{
					ts->plotData[m][1 + gp] = ts->varSumByGroupTime[m][i][gp] / ts->probSumByGroupTime[m][i][gp];
					
					ts->plotData[m][ts->nOrders[m] + 1 + gp] = ts->expectedTrajByGroupTime[m][i][gp];

					intervalWidth = 1.96 * sqrt(ts->varianceSum[m][i][gp] > 0. ? ts->varianceSum[m][i][gp] : 0.);

					ts->plotData[m][os] = ts->plotData[m][ts->nOrders[m] + 1 + gp] - intervalWidth;

					ts->plotData[m][os + 1] = ts->plotData[m][ts->nOrders[m] + 1 + gp] + intervalWidth;

					if (ts->modelStmt[m] && ts->plotData[m][os] < 0. &&
						(ts->modelType[m] == m_zibeta || ts->modelType[m] == m_logit || ts->modelType[m] == m_zip)) 
						ts->plotData[m][os] = 0.;

					if (ts->modelStmt[m]  && ts->plotData[m][os + 1] > 1. &&
						(ts->modelType[m] == m_logit || ts->modelType[m] == m_zibeta)) 
							ts->plotData[m][os + 1] = 1.;

					if (ts->modelStmt[m] && ts->modelType[m] == m_cnorm && ts->plotData[m][os] < ts->varMin[m])
						ts->plotData[m][os] = ts->varMin[m];

					if (ts->modelStmt[m] && ts->modelType[m] == m_cnorm && ts->plotData[m][os + 1] > ts->varMax[m]) 
						ts->plotData[m][os + 1] = ts->varMax[m];
				}
				
				if (m < 2 && ts->dropoutStmt[m])
				{
					ts->plotData[m][2 * ts->nOrders[m] + 1 + 2 * ts->nOrders[m] + gp] = MACMISSING;

					if (ts->nDropout[m] > 1)
					{
						if (ts->dropoutCountByGroupTime[m][i][gp] > DBL_EPSILON )
						{
							ts->plotData[m][2 * ts->nOrders[m] + 1 + 2 * ts->nOrders[m] + gp] = 
								ts->dropoutSumByGroupTime[m][i][gp] / ts->dropoutCountByGroupTime[m][i][gp];
						}
					}
					else
						if (ts->dropoutCountByGroupTime[m][i][0] > DBL_EPSILON )
							ts->plotData[m][2 * ts->nOrders[m] + 1 + 2 * ts->nOrders[m] + gp] = 
								ts->dropoutSumByGroupTime[m][i][0] / ts->dropoutCountByGroupTime[m][i][0];
				}	
			}	

			sprintf(l_str, "outPlot%d", m + 1);

			SF_mat_store(l_str, rowCount, 1, ts->plotData[m][0]);

			for (gp = 0; gp < 4 * ts->nOrders[m]; gp++) 
				SF_mat_store(l_str, rowCount, gp + 2, ts->plotData[m][gp + 1]);

			if (ts->dropoutStmt[m] && m < 2  && i > 0)
				for (gp = 0; gp < ts->nOrders[m]; gp++) 
					SF_mat_store(l_str, rowCount, 2 + 4 * ts->nOrders[m] + gp, 
						ts->plotData[m][2 * ts->nOrders[m] + 1 + 2 * ts->nOrders[m] + gp]);

			rowCount++;
		}
	}

	return 0;
}