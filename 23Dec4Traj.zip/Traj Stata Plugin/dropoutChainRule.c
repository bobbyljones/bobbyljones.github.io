/*	
	chain rule dropout model	

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 	
*/

#include "ctraj.h"

void dropoutChainRule(int n, int* obs, int* gp, int* wv, double *prm, int* dOrd, int* dLoc, double *w, void *qi)
{	
	struct	TRAJSTRUCT *ts = qi;
	int		j;
	double	wsign;

	for (j = 0; j < n; j++) w[j] = 0.;
	wsign = 0.;
	if ((*wv < ts->dropoutTime[0][*obs] || ts->obsmar[*obs]) && j > ts->dataStartTime[0][*obs]) wsign = -1.;
	if (*wv == ts->dropoutTime[0][*obs] && !ts->obsmar[*obs] && j > ts->dataStartTime[0][*obs]) wsign = 1.;
	w[*dLoc] = wsign * ts->varDropoutLk[0][*gp][*obs][*wv] * (1. - ts->varDropoutLk[0][*gp][*obs][*wv]);
	for (j = 1; j <= *dOrd; j++) 
		w[*dLoc + j] = wsign * ts->varDropoutLk[0][*gp][*obs][*wv] * ts->dep[0][*obs][*wv - j] *
					   (1. - ts->varDropoutLk[0][*gp][*obs][*wv]);
	for (j = 0; j < ts->nDcov[0] / ts->nIndep[0]; j++) 
		w[*dLoc + j + *dOrd + 1] = wsign * ts->varDropoutLk[0][*gp][*obs][*wv] * 
								   (1. - ts->varDropoutLk[0][*gp][*obs][*wv]) * 
								   ts->dcov[0][*obs][*wv + j * ts->nIndep[0] - 1];
}
