/* 
	Derivative distal outcome model 2S 

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

int outcDeriv2S( int n, double *prm, int *nf, double *g, void *qi )
{
	struct	TRAJSTRUCT *ts = qi;	
	int		i, ifault=0, j, jj, L, Lvl, oneStep, os, oSgOs, 
			wrkOffset;		/* work offset for position calculations */
	double	d1, normPdf, lmb, L1, **trajLk, oSg = 1., tmp, tmp2, tmp3, W, x, xb;

	if(ts->trace) traceOutput( "outc Deriv", n, prm );
	oneStep = 1 - ts->twoStep;
	trajLk = ts->obsTrajLk[0];
	if (ts->likelihoodType == MULTI) trajLk = ts->obsMultTrajLk;
	if (ts->outcModelType[0] == m_cnorm) 
	{
		oSgOs = ts->outcOffset * oneStep + ts->nOrders[0] + ts->nOcov[0];
		oSg = exp(prm[oSgOs]); 
	}
	for (i = 0; i < n; i++) g[i] = 0.;
	for (i = 0; i < ts->nObs; i++)
	{		
		if (ts->skip[i] || ts->oos[i]) continue;
		L1 = ts->outcLk[i];
		W = ts->weight[i];
		for (j = 0; j < ts->nOrders[0]; j++) 
		{
			if (ts->outcModelType[0] != m_mlogit)
			{
				wrkOffset = ts->outcOffset * oneStep + j;
				xb = prm[wrkOffset];
				if (ts->nOcov[0] > 0)
				{
					for( jj = 0; jj < ts->nOcov[0]; jj++ )
						xb += prm[ ts->nOrders[0] + jj ] * ts->ocov[0][i][jj];
				}
			}
			switch( ts->outcModelType[0] ) 
			{					
				case m_cnorm:
						
					x = (ts->outc[i] - xb) / oSg;
				
					normPdf = dnorm(&ts->outc[i], &xb, &oSg);

					g[wrkOffset] -= W * trajLk[j][i] * x * normPdf / oSg / L1;

					if( ts->nOcov[0] > 0 )
					{
						for( jj = 0; jj < ts->nOcov[0]; jj++ )
							g[ ts->outcOffset * oneStep +
								ts->nOrders[0] + jj ] -=
									W * trajLk[j][i] * x *
									ts->ocov[0][i][jj] * normPdf / oSg / L1;
					}
					
					g[oSgOs] -= -W * trajLk[j][i] * normPdf * (1. - x * x) / L1;
				
					break;
			
				case m_logit:
				
					tmp = W * trajLk[j][i] / L1;	

					tmp *= invlogit(xb) * (1. - invlogit(xb));	

					g[wrkOffset] -= ts->outc[i] == 0. ? -tmp : tmp;

					if( ts->nOcov[0] > 0 )
					{
						for( jj = 0; jj < ts->nOcov[0]; jj++ )
							g[ ts->outcOffset * oneStep +
								ts->nOrders[0] + jj ] -=
									ts->outc[i] == 0. ?
									-tmp * ts->ocov[0][i][jj] : 
									tmp * ts->ocov[0][i][jj];
					}
				
					break;	
			
				case m_mlogit:
					
					d1 = 0.;

					for( L = 0; L < ts->nOutcLevels[0]; L++ ) 
						d1 += ts->mlogitOutcProb[0][i][L];
					
					for( Lvl = 0; Lvl < ts->nOutcLevels[0]; Lvl++ )
					{
						if ((int)ts->outc[i] ==	(int)ts->mlogitOutcLevel[0][Lvl])
						{
							if( (int)ts->outc[i] == (int)ts->baseOutc[0] )
							{								
								for( L = 1; L < ts->nOutcLevels[0]; L++ )
								{
									os = ts->outcOffset * oneStep + 
										 j * (ts->nOutcLevels[0] - 1) + (L - 1);
									
									tmp2 = - W * ts->mlogitOutcProb[0][i][L];
									
									tmp = trajLk[j][i] * tmp2;
											
									g[os] -= tmp;
													
									if( ts->nOcov[0] > 0 )
									{
										for( jj = 0; jj < ts->nOcov[0]; jj++ )
										{
											os = ts->outcOffset * oneStep + 
												 j * (ts->nOutcLevels[0] - 1) +
												 (L - 1) + jj + 1;
												g[os] -= tmp * ts->ocov[0][i][jj] * trajLk[j][i];
											}

										for( jj = 0; jj < ts->nOcov[0]; jj++ )
											g[ ts->outcOffset * oneStep + ts->nOrders[0] *
											  (ts->nOutcLevels[0] - 1) +
											  (L - 1) * ts->nOcov[0] + jj] -= 
													tmp2 * ts->ocov[0][i][jj];
									}
								}
							}
							else
							{
								for( L = 1; L < ts->nOutcLevels[0]; L++ )
								{
									os = ts->outcOffset * oneStep + 
										 j * ( ts->nOutcLevels[0] - 1 ) + (L - 1);
								
									tmp2 = W * (1. - ts->mlogitOutcProb[0][i][L]);
							
									if( (int)ts->outc[i] != 
										(int)ts->mlogitOutcLevel[0][L] )
											tmp2 = - W * ts->mlogitOutcProb[0][i][L];							

									tmp = tmp2 * trajLk[j][i];

									g[os] -= tmp;

									if( ts->nOcov[0] > 0 )
									{
										for( jj = 0; jj < ts->nOcov[0]; jj++ )
											g[ ts->outcOffset * oneStep + 
											j * ( ts->nOutcLevels[0] - 1 ) + 
											(L - 1) + jj + 1] -= 
												tmp * ts->ocov[0][i][jj];

										for( jj = 0; jj < ts->nOcov[0]; jj++ )
											g[ ts->outcOffset * oneStep +
												ts->nOrders[0] * 
												( ts->nOutcLevels[0] - 1 ) + 
												(L - 1) * ts->nOcov[0] + jj ] -= 
													tmp2 * ts->ocov[0][i][jj];
									}
								}
							}
						}
					}
					
					break;

				case m_zip:
				
					lmb = tmp3 = exp(xb);
			
					if( ts->outc[i] == 0. )
						tmp3 = exp( -lmb + ts->outc[i] * log(lmb) - 
							alogam( ts->outc[i] + 1., &ifault ) );

					tmp2 = W * ts->outc[i] == 0. ? exp(-lmb) : ts->outc[i] - lmb;

					tmp = ts->outc[i] == 0. ? 0. : -lmb + ts->outc[i] * log(lmb) - 
							alogam( ts->outc[i] + 1., &ifault );
					
					g[j] -= tmp3 * exp(tmp) * trajLk[j][i] / L1;

					if( ts->nOcov[0] > 0 )
					{
						for( jj = 0; jj < ts->nOcov[0]; jj++ )
							g[j + jj + 1 ] -= 
								tmp * ts->ocov[0][i][jj] * trajLk[j][i];

						for( jj = 0; jj < ts->nOcov[0]; jj++ )
							g[ts->nOrders[0] + jj] -=
								tmp * ts->ocov[0][i][jj];
					}
				
					break;
			}
		}
	}

	if( ts->trace ) traceOutput( "Gradient", n, g );

	return 0;
}