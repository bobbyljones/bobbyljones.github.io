/* 
	Print parameter estimates

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include	 "ctraj.h"

int  printParmsToLog(int numPrint, int numParms, double *params, int parmOnly, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		os, i, j, k;	
	char	buf[100], l_str[13];	
	double	d1, *parms, *prmPrt;

	parms = (double *) calloc(2 * numParms, sizeof(double));
	prmPrt = (double *) calloc(2 * numPrint, sizeof(double));
	for (i = 0; i < numParms; i++) parms[i] = params[i];
	for (i = 0; i < numPrint; i++) prmPrt[i] = ts->outestStart[i];
	if ((ts->nOrders[0] > 1 && ts->nRisk[0] == 0 && !ts->multModel) || 
		(ts->nOrders[1] > 1 && ts->nRisk[1] == 0 && !ts->multModel) ||
		(ts->nOrders[0] > 1 && ts->nMultRisk == 0 && ts->multModel)) 
	{
		if (ts->itdetail && !parmOnly) 
		{
			WRITELOG (" \n");
			WRITELOG(" \n");
			WRITELOG (" Parameter estimates for adding risk factors\n"); 
			for (i = 0; i < (numPrint / 6) + 1; i++) 
			{
				*buf = '\0';
				for (j = i * 6; j < (i + 1) * 6 && j < numParms; j++) 
				{
					*l_str = '\0';
					if (fabs (prmPrt[j]) >= 1e7) 
					{
						if (j != (numParms - 1)) snprintf(l_str, 13, "%11.3e,", prmPrt[j]);
						else snprintf(l_str, 13, "%11.3e", prmPrt[j]); 
					} 
					else 
					{
						if (j != numParms - 1) snprintf(l_str, 13, "%11.5f,", prmPrt[j]);
						else snprintf(l_str, 13, "%11.5f", prmPrt[j]); 
					}
					strcat (buf, l_str);	
				}
				WRITELOG ("%s", buf);
				WRITELOG (" \n");
			}
		}
	}
	if (ts->nOrders[1] > 1 && ts->nRisk[1] == 0  && !ts->multModel) 
	{
		os = ts->riskOffset[1];
		if (ts->nOrders[0] > 1 && ts->nRisk[0] == 0)
			for (i = 1; i <= (numPrint - ts->jointOffset); i++) 
				prmPrt[numPrint - i] = prmPrt[numPrint - i - 1];
		for (k = 0; k < ts->nOrders[0]; k++) 
		{
			d1 = 1.;
			for (i = 0; i < ts->nOrders[1] - 1; i++)
			{
				parms[os + i] = parms[os + i] > MAXEXP ? MAXEXP : parms[os + i];
				parms[os + i] = parms[os + i] < -MAXEXP ? -MAXEXP : parms[os + i];
				d1 += exp(parms[os + i]);
			}
			prmPrt[os + k + 1] = 1. / d1 * 100.;
			for (i = 1; i < ts->nOrders[1]; i++) 
				prmPrt[os + i + k + 1] = exp(parms[os + i - 1]) / d1 * 100.;
			os = os + ts->nOrders[1] - 1;
		}
	}
	if (ts->nOrders[0] > 1 && ts->nRisk[0] == 0  && !ts->multModel) 
	{
		if (ts->outcStmt[0]) for (i = 0; i < ts->nOutcPrm[0]; i++) 
			prmPrt[ts->outcOffset + ts->nOutcPrm[0] - i] = 
				prmPrt[ts->outcOffset + ts->nOutcPrm[0] - i - 1];
		prmPrt[ts->riskOffset[0]] = ts->group_percent[0];
		for (i = 1; i < ts->nOrders[0]; i++) prmPrt[ts->riskOffset[0] + i] = ts->group_percent[i];
	}
	if (ts->nOrders[0] > 1 && ts->nMultRisk == 0 && ts->multModel) 
	{
		if (ts->outcStmt[0]) for (i = 0; i < ts->nOutcPrm[0]; i++) 
			prmPrt[ts->outcOffset + ts->nOutcPrm[0] - i] = 
				prmPrt[ts->outcOffset + ts->nOutcPrm[0] - i - 1];
		prmPrt[ts->multRiskOffset] = ts->group_percent[0];
		for (i = 1; i < ts->nOrders[0]; i++) prmPrt[ts->multRiskOffset + i] = ts->group_percent[i];
	}
	if (ts->itdetail) 
	{
		WRITELOG(" \n");
		WRITELOG(" Parameter estimates\n"); 		
		for (i = 0; i < (numPrint / 6) + 1; i++) 
		{
			*buf = '\0' ;
			for (j = i * 6; j < ((i + 1) * 6) && j < numPrint ; j++) 
			{
				*l_str = '\0';
				if (fabs(prmPrt[j]) >= 1e7) 
				{
					if (j != (numPrint - 1)) snprintf(l_str, 13, "%11.3e,", prmPrt[j]);
					else snprintf(l_str, 13, "%11.3e", prmPrt[j]); 
				} 
				else 
				{
					if (j != (numPrint - 1)) snprintf(l_str, 13, "%11.5f,", prmPrt[j]);
					else snprintf(l_str, 13, "%11.5f", prmPrt[j]); 
				}
				strcat(buf, l_str);	
			}
			WRITELOG("%s", buf);
			WRITELOG(" \n");
		}
	}
	free(parms);
	free(prmPrt);
	return 0;
}
