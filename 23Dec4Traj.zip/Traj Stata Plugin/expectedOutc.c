/* 
	Expected distal outcome (group or observation level)

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	

	overall = 1 generates overall group level means and CI 
	overall = 0 gives individual group means without CI

	multinomial logit returns result in TRAJSTRUCT **meanMlogitOutc
*/

#include "ctraj.h"

void expectedOutc(int *obs, int pUpd, int *wv, void *qi, int overall) {

	struct	TRAJSTRUCT *ts = qi;	
	double	ci[2], dWork, eff_n, **trajLk, ***trajLk_T,	norm, p_hat, stdErr, xb;
	int		j, jj, L, lvlos, oneStep, stepOS;				

	oneStep = 1 - ts->twoStep;
	trajLk = ts->obsTrajLk[0];
	trajLk_T = ts->obsTrajLk_T[0];
	if (ts->likelihoodType == MULTI)
	{
		trajLk = ts->obsMultTrajLk;
		trajLk_T = ts->obsMultTrajLk_T;
	}
	if (!overall) 
	{
		if (ts->skip[*obs] ||
			(!pUpd && trajLk[0][*obs] <= 0.) ||
			(pUpd && trajLk_T[0][*obs][*wv] <= 0.)) 
			return;
	}
	xb = 0.;
	for (j = 0; j < ts->nOrders[0]; j++) 
	{
		stepOS = ts->outcOffset * oneStep + j;
		xb = oneStep ? ts->start[stepOS] : ts->outcStart[stepOS];
		stdErr = oneStep ? ts->stdErr[stepOS] : ts->outcStdErr[stepOS];
		if (ts->nOcov[0] > 0) 
		{
			for (jj = 0; jj < ts->nOcov[0]; jj++) 
			{
				dWork = oneStep ? ts->start[ts->outcOffset + ts->nOrders[0] + jj] : 
								  ts->outcStart[ts->nOrders[0] + jj];
				xb += dWork * ts->ocov[0][*obs][jj];
			}
		}
		switch(ts->outcModelType[0]) 
		{
			case m_cnorm: 
				ts->linkfMeanOutc[j] = ts->meanOutc[j] = xb;
				if (overall)
				{
					ts->meanOutcL95[j] = xb - 1.96 * stdErr;
					ts->meanOutcU95[j] = xb + 1.96 * stdErr; 
				}
				break;
			case m_mlogit: 
				norm = xb = 0.; 
				lvlos = 0;
				for (L = 0; L < ts->nOutcLevels[0]; L++) 
				{
					if ((int)ts->mlogitOutcLevel[0][L] == (int)ts->baseOutc[0]) 
						ts->meanMlogitOutc[j][L] = ts->linkfMeanMlogitOutc[j][L] = 0.;
					else 
					{
						stepOS = ts->outcOffset * oneStep + j * (ts->nOutcLevels[0] - 1) + lvlos;
						xb = oneStep ? ts->start[stepOS] : ts->outcStart[stepOS];
						ts->meanMlogitOutc[j][L] = ts->linkfMeanMlogitOutc[j][L] = xb;
						lvlos++;
						if (ts->nOcov[0] > 0) 
						{
							for (jj = 0; jj < ts->nOcov[0]; jj++) 
							{
								dWork = oneStep ? 
										ts->start[ts->outcOffset + ts->nOrders[0] + jj] :
										ts->outcStart[ts->nOrders[0] + jj];
								xb += dWork * ts->ocov[0][*obs][jj];
							}
						}
					}
					norm += exp(xb);
				}
				for (L = 0; L < ts->nOutcLevels[0]; L++) 
					ts->meanMlogitOutc[j][L] = exp(ts->linkfMeanMlogitOutc[j][L]) / norm;
				break;
			case m_logit:
				eff_n = ts->groupProbSum[0][j];
				ts->linkfMeanOutc[j] = xb;
				p_hat = ts->meanOutc[j] = invlogit(xb);
				if (overall) 
				{
					logitCI(eff_n, p_hat, ci);
					ts->meanOutcL95[j] = ci[0];
					ts->meanOutcU95[j] = ci[1];
				}
				break;
			case m_zip:
				ts->linkfMeanOutc[j] = xb;
				ts->meanOutc[j] = exp(xb); 
				if (overall)
				{
					dWork = xb - 1.96 * stdErr;					
					ts->meanOutcL95[j] = exp(dWork);				
					if (ts->meanOutcL95[j] < 0.) ts->meanOutcL95[j] = 0.;
					dWork = xb + 1.96 * stdErr;					
					ts->meanOutcU95[j] = exp(dWork);
				}
				break;
		}
	}
}
