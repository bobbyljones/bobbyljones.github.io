/* 
	trace parameters

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 
*/

#include	 "ctraj.h"

int traceOutput(char *fn, int nprms, double *prm) {

	int	i, j, nacross = 6;
	char buf[100], l_str[33];

	WRITELOG("%s\n", fn);
	for (i = 0; i < (nprms / nacross) + 1; i++) 
	{
		*buf = '\0';
		for (j = i * nacross; j < (i + 1) * nacross; j++) 
		{
			*l_str = '\0';
			if (j < nprms) sprintf(l_str, "%7.4e ", prm[j]);
			if (j == nprms - 1) sprintf(l_str, "%7.4e\n", prm[j]);
			strcat(buf, l_str);	
		}
		SF_display(buf);
		SF_display(" \n");
	}
	return 0;
}
