/* 
	Adjust start values for multi-trajectory model	

	Copyright (C) 2022 Bobby L Jones <bobbyljones@gmail.com>
		
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  	
*/

#include "ctraj.h"

int adjustMultStartValues(int *ns, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
 	int		i, m, os, outcSigmaOffset;
	double	dt;
	char	buf[80];

	for (m = 0; m < ts->nModels; m++) 
	{
		if (ts->modelType[m] == m_cnorm) 
		{
			if (ts->sigmaByGroup) 
			{
				for (i = 0; i < ts->nOrders[m] - ts->all0Group[m]; i++) 
				{
					ts->initVal[ts->riskOffset[m] - i - 1] = 
						ts->initVal[ts->riskOffset[m] - i - 1] > DBL_MIN ? 
						log(ts->initVal[ts->riskOffset[m] - i - 1]) : 0.;
				}
			} 
			else 
			{
				ts->initVal[ts->riskOffset[m] - 1] = 
					ts->initVal[ts->riskOffset[m] - 1] > DBL_MIN ? 
					log(ts->initVal[ts->riskOffset[m] - 1]) : 0.;
			}
		}
		if (ts->modelType[m] == m_zibeta) 
		{
			os = ts->riskOffset[m] - ts->nOrders[m];
			for (i = 0; i < ts->nOrders[m]; i++)
			{
				ts->initVal[os] = ts->initVal[os] > DBL_MIN ? log(ts->initVal[os]) : 0.;
				os++;
			}
		}
	}
	os = ts->multRiskOffset;
	if (ts->nOrders[0] > 1 && ts->nMultRisk == 0) 
	{
		for (i = 0; i < ts->nOrders[0]; i++) 
		{
			if (ts->initVal[os + i] <= 0. || ts->initVal[os + i] >= 100.)
				WRITELOG("Starting group size, %10.4f is not between 0 - 100.\n", ts->initVal[os + i]);
			ts->group_percent[i] = ts->initVal[os + i];
		}

		dt = 1. - ts->initVal[os + 1] / 100.;
		for (i = 2; i < ts->nOrders[0]; i++) 
			dt -= ts->initVal[os + i] / 100.;
		if (dt - ts->initVal[os] / 100. <= -FLT_EPSILON)
			WRITELOG("Starting percentages add to more than 100.\n");
		
		for (i = 0; i < ts->nOrders[0] - 1; i++) 
			ts->initVal[os + i] = log(ts->initVal[os + i + 1] / dt / 100.);
	}
	if (ts->outcModelType[0] == m_cnorm) 
	{
		outcSigmaOffset = ts->nOrders[0] + ts->nOcov[0];
		
		ts->initVal[os + outcSigmaOffset] = 
			ts->initVal[os + outcSigmaOffset] > DBL_MIN ? 
			log(ts->initVal[os + outcSigmaOffset]) : 0.;
	}
	return 0;
}
