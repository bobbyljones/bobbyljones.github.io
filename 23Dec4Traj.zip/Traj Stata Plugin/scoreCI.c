/* 
	CI for posterior probabilities, logit and mlogit outcomes
	using Wilson method Sison-Glaz for multinomial probabilities

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause.  
*/

#include "ctraj.h"

void scoreCI(double *paramEst, void *qi) 
{
	struct TRAJSTRUCT *ts = qi;
	int	gp, lvl, obs, os, vOs=0, wave;
	double ci[2], eff_n, **trajLk, ***trajLk_T, p_hat, xb;

	trajLk = ts->obsTrajLk[0];
	trajLk_T = ts->obsTrajLk_T[0];
	if (ts->likelihoodType == MULTI)
	{
		trajLk = ts->obsMultTrajLk; 
		trajLk_T = ts->obsMultTrajLk_T;
	}
	for (obs = 0; obs < SF_nobs(); obs++)
	{
		if (!ts->writeObs[obs] || ts->skip[obs]) continue;
		vOs = ts->vstOs + 2 * (int)ts->nOrders[0];
		if (ts->outcStmt[0])
			vOs += ts->outcModelType[0] == m_mlogit ? 2 * ts->nOutcLevels[0] : 2;
		for (gp = 0; gp < ts->nOrders[0]; gp++)
		{
			eff_n = ts->groupProbSum[0][gp];
			p_hat = trajLk[gp][obs];
			logitCI(eff_n, p_hat, ci);
			SF_vstore(vOs++, obs + 1, ci[0]);
			SF_vstore(vOs++, obs + 1, ci[1]);
		}
		if (ts->outcStmt[0]) 
		{
			switch (ts->outcModelType[0]) 
			{		
				case m_logit:
					os = ts->outcOffset;
					p_hat = eff_n = xb = 0.;
					for (gp = 0; gp < ts->nOrders[0]; gp++)
					{
						eff_n += ts->groupProbSum[0][gp] * trajLk[gp][obs];
						xb += paramEst[os] * trajLk[gp][obs];
						os++;
					}
					p_hat = invlogit(xb);
					logitCI(eff_n, p_hat, ci);
					SF_vstore(vOs++, obs + 1, ci[0]);
					SF_vstore(vOs++, obs + 1, ci[1]);	
					break;
				case m_mlogit:
					for (lvl = 0; lvl < ts->nOutcLevels[0]; lvl++) 
					{
						ts->mlogitX[lvl] = 0;
						for (gp = 0; gp < ts->nOrders[0]; gp++) 
						{
							ts->mlogitX[lvl] += ts->meanMlogitOutc[gp][lvl] * ts->groupProbSum[0][gp] * 
												trajLk[gp][obs];
						}
						ts->mlogitX[lvl] = floor(ts->mlogitX[lvl] + 0.5);
					}
					mlogitCI(ts->mlogitOutcCIRslt, qi);
					for (lvl = 0; lvl < ts->nOutcLevels[0]; lvl++)
					{	
						SF_vstore(vOs++, obs + 1, ts->mlogitOutcCIRslt[2 * lvl]);
						SF_vstore(vOs++, obs + 1, ts->mlogitOutcCIRslt[2 * lvl + 1]);	
					}
					break;
			}
		}
		if (ts->probupdates)
		{			
			for (wave = 0; wave < ts->probUpdateWaves; wave++)
			{
				for (gp = 0; gp < ts->nOrders[0]; gp++) 
				{					
					eff_n = ts->groupProbSum_T[0][gp][wave];
					p_hat = trajLk_T[gp][obs][wave];
					logitCI(eff_n, p_hat, ci);
					SF_vstore(vOs++, obs + 1, ci[0]);
					SF_vstore(vOs++, obs + 1, ci[1]);
				}	
				if (ts->outcStmt[0]) 
				{
					switch (ts->outcModelType[0]) 
					{		
						case m_logit:	
							os = ts->outcOffset;
							p_hat = eff_n = xb = 0.;
							for (gp = 0; gp < ts->nOrders[0]; gp++)
							{
								eff_n += ts->groupProbSum_T[0][gp][wave] * trajLk_T[gp][obs][wave];
								xb += paramEst[os] * trajLk_T[gp][obs][wave];
								os++;
							}
							p_hat = invlogit(xb);
							logitCI(eff_n, p_hat, ci);
							SF_vstore(vOs++, obs + 1, ci[0]);
							SF_vstore(vOs++, obs + 1, ci[1]);
							break;
						case m_mlogit:
							for (lvl = 0; lvl < ts->nOutcLevels[0]; lvl++)
							{
								ts->mlogitX[lvl] = 0;
								for (gp = 0; gp < ts->nOrders[0]; gp++)
								{
									ts->mlogitX[lvl] += ts->meanMlogitOutc[gp][lvl] *
										ts->groupProbSum[0][gp] * trajLk_T[gp][obs][wave];
								}
								ts->mlogitX[lvl] = floor(ts->mlogitX[lvl] + 0.5);				
							}
							mlogitCI(ts->mlogitOutcCIRslt, qi);
							for (lvl = 0; lvl < ts->nOutcLevels[0]; lvl++)
							{	
								SF_vstore(vOs++, obs + 1, ts->mlogitOutcCIRslt[2 * lvl]);
								SF_vstore(vOs++, obs + 1, ts->mlogitOutcCIRslt[2 * lvl + 1]);
							}
							break;
					}
				}
			}
		}
	}
	ts->vstOs = vOs;
}
