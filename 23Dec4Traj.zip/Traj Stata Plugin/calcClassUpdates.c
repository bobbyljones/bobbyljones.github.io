/* 	
	All period posterior probabilities and classifications

	Copyright (C) 2023 Bobby L Jones <bobbyljones@gmail.com>
	
	This source code is subject to the terms of the 3-Clause
	BSD License (Open Source Initiative). The license can be
	obtained from https://opensource.org/licenses/BSD-3-Clause. 

	input:  Count - observation number
			traj likelihood (single, multi)
			number of groups (single, multi, joint)
	output: ts->classifiedGroup_T[0]: t = 1...T
			ts->posteriorProb[0][j][t]: j = 1...K, t = 1...T
			output stored in Stata data file
*/

#include "ctraj.h"

void calcClassUpdates(int *Count, void *qi) {

	struct	TRAJSTRUCT *ts = qi;
	int		j, k, vstoreOffset, wave;
	double	***trajLk_T, highProb;

	vstoreOffset = ts->vstOs;
	trajLk_T = ts->obsTrajLk_T[0];
	if (ts->likelihoodType == MULTI) trajLk_T = ts->obsMultTrajLk_T;
	for (wave = 0; wave < ts->probUpdateWaves; wave++) 
	{
		highProb = 0.;
		ts->classifiedGroup_T[0] = 1.;
		for (j = 0; j < ts->nOrders[0]; j++) 
		{
			if (trajLk_T[j][*Count][wave] > highProb) 
			{
				ts->classifiedGroup_T[0] = j + 1.;
				highProb = trajLk_T[j][*Count][wave];
			}
		}	
		SF_vstore(vstoreOffset++, *Count + 1, ts->classifiedGroup_T[0]);
		for (k = 0; k < ts->nOrders[0]; k++) 
		{
			SF_vstore(vstoreOffset++, *Count + 1, trajLk_T[k][*Count][wave]);
			if (!IS_MISSING(trajLk_T[k][*Count][wave]) && !ts->oos[*Count]) 
				ts->groupProbSum_T[0][k][wave] += trajLk_T[k][*Count][wave];
		}
	}
	ts->vstOs = vstoreOffset;
}
